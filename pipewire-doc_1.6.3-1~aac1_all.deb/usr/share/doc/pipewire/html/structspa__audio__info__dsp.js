var structspa__audio__info__dsp =
[
    [ "format", "structspa__audio__info__dsp.html#ab59df8be3387df377c8b698346aa234f", null ]
];