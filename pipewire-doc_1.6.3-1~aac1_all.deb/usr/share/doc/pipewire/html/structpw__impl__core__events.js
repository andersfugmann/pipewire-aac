var structpw__impl__core__events =
[
    [ "version", "structpw__impl__core__events.html#a53a597c0d67497f0fd3661c6d0518686", null ],
    [ "destroy", "structpw__impl__core__events.html#a3189bc6a80618c55e8320da100edf0c4", null ],
    [ "free", "structpw__impl__core__events.html#a7fa1d92430edc18d7d8fb645b8879cbf", null ],
    [ "initialized", "structpw__impl__core__events.html#a9ac4ac7169ad8ea008945360c63ad1a3", null ]
];