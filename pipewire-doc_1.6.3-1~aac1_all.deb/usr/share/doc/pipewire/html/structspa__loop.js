var structspa__loop =
[
    [ "iface", "structspa__loop.html#a6cd472082b361bc90f66c41b0dccea96", null ]
];