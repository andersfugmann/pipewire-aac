var structspa__debug__context =
[
    [ "log", "structspa__debug__context.html#af9f0b4808459f1701213a4dbac14601f", null ]
];