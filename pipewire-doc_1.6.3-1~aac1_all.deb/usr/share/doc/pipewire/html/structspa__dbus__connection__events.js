var structspa__dbus__connection__events =
[
    [ "version", "structspa__dbus__connection__events.html#a2ae8b95b36226127853160f1779260e0", null ],
    [ "destroy", "structspa__dbus__connection__events.html#a1e35b4f490157dd9c4194b4a03490fc6", null ],
    [ "disconnected", "structspa__dbus__connection__events.html#a481b39049a46ec7d8519c8d2c9318968", null ]
];