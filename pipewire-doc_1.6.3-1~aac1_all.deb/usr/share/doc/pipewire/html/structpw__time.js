var structpw__time =
[
    [ "now", "structpw__time.html#ad817da21bea1591d70f837c251a73468", null ],
    [ "rate", "structpw__time.html#a41d793c390eefc6aee165e16e0d7c898", null ],
    [ "ticks", "structpw__time.html#a99e3d7963e24fbf410afa03c73465328", null ],
    [ "delay", "structpw__time.html#a1ea3fa77ce4221df0d5ac3ad8fd1f6c7", null ],
    [ "queued", "structpw__time.html#a91dafbb38397328f8705e2bb20b7625a", null ],
    [ "buffered", "structpw__time.html#a4ad8ba0afa44dc283d8ecd5ea1e9d0ff", null ],
    [ "queued_buffers", "structpw__time.html#a92d7a1849d4dc044d2fa64bd35a7a57d", null ],
    [ "avail_buffers", "structpw__time.html#aebd42745267531bc23e1ee34dd759607", null ],
    [ "size", "structpw__time.html#ab2eccb212c23d1138aabcdc959c875ff", null ]
];