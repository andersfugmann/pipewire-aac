var page_programs =
[
    [ "pipewire", "page_man_pipewire_1.html", [
      [ "RUNTIME SETTINGS", "page_man_pipewire_1.html#pipewire__runtime_settings", null ],
      [ "ENVIRONMENT VARIABLES", "page_man_pipewire_1.html#pipewire-env__environment_variables", null ]
    ] ],
    [ "pipewire-pulse", "page_man_pipewire-pulse_1.html", null ],
    [ "pw-cat", "page_man_pw-cat_1.html", null ],
    [ "pw-cli", "page_man_pw-cli_1.html", null ],
    [ "pw-config", "page_man_pw-config_1.html", null ],
    [ "pw-container", "page_man_pw-container_1.html", null ],
    [ "pw-dot", "page_man_pw-dot_1.html", null ],
    [ "pw-dump", "page_man_pw-dump_1.html", null ],
    [ "pw-jack", "page_man_pw-jack_1.html", null ],
    [ "pw-link", "page_man_pw-link_1.html", null ],
    [ "pw-loopback", "page_man_pw-loopback_1.html", null ],
    [ "pw-metadata", "page_man_pw-metadata_1.html", null ],
    [ "pw-mididump", "page_man_pw-mididump_1.html", null ],
    [ "pw-mon", "page_man_pw-mon_1.html", null ],
    [ "pw-profiler", "page_man_pw-profiler_1.html", null ],
    [ "pw-reserve", "page_man_pw-reserve_1.html", null ],
    [ "pw-top", "page_man_pw-top_1.html", null ],
    [ "pw-v4l2", "page_man_pw-v4l2_1.html", null ],
    [ "spa-acp-tool", "page_man_spa-acp-tool_1.html", null ],
    [ "spa-inspect", "page_man_spa-inspect_1.html", null ],
    [ "spa-json-dump", "page_man_spa-json-dump_1.html", null ],
    [ "spa-monitor", "page_man_spa-monitor_1.html", null ],
    [ "spa-resample", "page_man_spa-resample_1.html", null ]
];