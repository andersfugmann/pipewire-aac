var structspa__meta__busy =
[
    [ "flags", "structspa__meta__busy.html#afa6284c360957925babd30c58fdd4807", null ],
    [ "count", "structspa__meta__busy.html#af5a282aa87b7c7b44900c00155ea77f4", null ]
];