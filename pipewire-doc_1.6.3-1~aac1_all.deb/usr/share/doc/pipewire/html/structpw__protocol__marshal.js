var structpw__protocol__marshal =
[
    [ "type", "structpw__protocol__marshal.html#a42d1730a083b2ddfef273c875f5a8da9", null ],
    [ "version", "structpw__protocol__marshal.html#a84d23417562653ce0c3f833914745b4b", null ],
    [ "flags", "structpw__protocol__marshal.html#a3b6e60e3abd02c572dc9717ea6128837", null ],
    [ "n_client_methods", "structpw__protocol__marshal.html#a050ca46939a55d57319f7fe60630088e", null ],
    [ "n_server_methods", "structpw__protocol__marshal.html#a9082278f0db2ef7b0fab5ac315d5d4e6", null ],
    [ "client_marshal", "structpw__protocol__marshal.html#a630f0a301e4fbf67698cf05b24179b30", null ],
    [ "server_demarshal", "structpw__protocol__marshal.html#a1d2f780d6b77da347a46af7bf6577c4a", null ],
    [ "server_marshal", "structpw__protocol__marshal.html#ade451b0a49d73a98a1c3cee60f6f9c8d", null ],
    [ "client_demarshal", "structpw__protocol__marshal.html#ab3d180b20e34b70959086148d1b6c9c5", null ]
];