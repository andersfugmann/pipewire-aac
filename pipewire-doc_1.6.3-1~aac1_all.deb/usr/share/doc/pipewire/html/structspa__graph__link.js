var structspa__graph__link =
[
    [ "link", "structspa__graph__link.html#ab1f910424f6a5ea5a34b52695536f53d", null ],
    [ "state", "structspa__graph__link.html#a15313bfb8509b74448784ebf30f191c6", null ],
    [ "signal", "structspa__graph__link.html#ab7c807f9aaa9242cf8573b13212de674", null ],
    [ "signal_data", "structspa__graph__link.html#abf9a5059f5b888cf3a331832830f7373", null ]
];