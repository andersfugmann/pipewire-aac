var group__spa__thread =
[
    [ "thread.h", "spa_2include_2spa_2support_2thread_8h.html", null ],
    [ "spa_thread_utils", "structspa__thread__utils.html", [
      [ "iface", "structspa__thread__utils.html#add4d911915f7c8e76b9c646389facf70", null ]
    ] ],
    [ "spa_thread_utils_methods", "structspa__thread__utils__methods.html", [
      [ "version", "structspa__thread__utils__methods.html#a68878e9b02ee15f3590d4c871a97d74a", null ],
      [ "create", "structspa__thread__utils__methods.html#aa0c4c049d9406510ff457400df373ceb", null ],
      [ "join", "structspa__thread__utils__methods.html#ab1126024161570f88d077ecee01066e8", null ],
      [ "get_rt_range", "structspa__thread__utils__methods.html#aa5a251e895f44dd6f48ee3014f0546e4", null ],
      [ "acquire_rt", "structspa__thread__utils__methods.html#adaa8eb3e63f991d91dbb6246fd4f6c3e", null ],
      [ "drop_rt", "structspa__thread__utils__methods.html#a3324347184f8b1caa930012817982c41", null ]
    ] ],
    [ "spa_thread", "structspa__thread.html", null ],
    [ "SPA_TYPE_INFO_Thread", "group__spa__thread.html#ga36d6661f31950920b85cd0c48fc68a33", null ],
    [ "SPA_TYPE_INTERFACE_ThreadUtils", "group__spa__thread.html#ga6680e7f42845ca460cdaa93abd568e02", null ],
    [ "SPA_VERSION_THREAD_UTILS", "group__spa__thread.html#ga4f716da417d838544df4e82f4670b79c", null ],
    [ "SPA_VERSION_THREAD_UTILS_METHODS", "group__spa__thread.html#ga7454dd6c4ac2967b5c53936dc6ec00b5", null ],
    [ "SPA_KEY_THREAD_NAME", "group__spa__thread.html#gaa3418c60a3ab55c44596d0c37ff0fe1b", null ],
    [ "SPA_KEY_THREAD_STACK_SIZE", "group__spa__thread.html#ga5d2d0635caeef22aaa5a63681255219d", null ],
    [ "SPA_KEY_THREAD_AFFINITY", "group__spa__thread.html#gadce83b9aff787efe920bf4c56483ec1d", null ],
    [ "SPA_KEY_THREAD_CREATOR", "group__spa__thread.html#ga2e071854fee504304c1b169336d54dfa", null ],
    [ "SPA_KEY_THREAD_RESET_ON_FORK", "group__spa__thread.html#gaf3f97c9f483a2b401901b3020bb07cbc", null ],
    [ "spa_thread_utils_create", "group__spa__thread.html#gab1bd4e6c1e9826bd04cc56f950264104", null ],
    [ "spa_thread_utils_join", "group__spa__thread.html#gacf8469d3b96859e7ff33f14e755c58fa", null ],
    [ "spa_thread_utils_get_rt_range", "group__spa__thread.html#ga8456ea86a0e648da9373a707675b7317", null ],
    [ "spa_thread_utils_acquire_rt", "group__spa__thread.html#ga5cf5f2326b0190db4f3af375dd444e74", null ],
    [ "spa_thread_utils_drop_rt", "group__spa__thread.html#ga1eb0a5eb7dac0280bc61fe683dbb9a44", null ]
];