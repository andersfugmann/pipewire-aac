var structspa__cpu__methods =
[
    [ "version", "structspa__cpu__methods.html#afc8c065c16934356a464235e38aae666", null ],
    [ "get_flags", "structspa__cpu__methods.html#a705910a6b831fd551b298ad64182598f", null ],
    [ "force_flags", "structspa__cpu__methods.html#a52a1db59dcb261cd6348733232932a66", null ],
    [ "get_count", "structspa__cpu__methods.html#a700fe283edbd95218d18e6c5cac7f327", null ],
    [ "get_max_align", "structspa__cpu__methods.html#a269e1e0cff0d3674d92b9d4935089aa8", null ],
    [ "get_vm_type", "structspa__cpu__methods.html#acd636f83ca2db246adfc92fc7d669204", null ],
    [ "zero_denormals", "structspa__cpu__methods.html#ac728f1a2d9783599229e2e55cc6b0902", null ]
];