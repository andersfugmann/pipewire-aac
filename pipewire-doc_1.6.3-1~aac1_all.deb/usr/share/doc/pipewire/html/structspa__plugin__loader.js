var structspa__plugin__loader =
[
    [ "iface", "structspa__plugin__loader.html#a17501870cdaf04804cde83d541a31a61", null ]
];