var structspa__graph__port =
[
    [ "link", "structspa__graph__port.html#af25d08a94327c7642abd9d22c1f00dee", null ],
    [ "node", "structspa__graph__port.html#a2010d31b7d56fef0f5a8eeb4188e7ff6", null ],
    [ "direction", "structspa__graph__port.html#ac60bcc3482ad354bc5ae32d3cade3a02", null ],
    [ "port_id", "structspa__graph__port.html#a6a077a5cc2c1115b43d05208bb072208", null ],
    [ "flags", "structspa__graph__port.html#a8ee1612c0aaef539c9270761f3d6d8b6", null ],
    [ "peer", "structspa__graph__port.html#a7139cc16698356c2fc915149d45a741f", null ]
];