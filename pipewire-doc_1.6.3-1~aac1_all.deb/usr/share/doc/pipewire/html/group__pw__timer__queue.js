var group__pw__timer__queue =
[
    [ "timer-queue.h", "timer-queue_8h.html", null ],
    [ "pw_timer", "structpw__timer.html", [
      [ "link", "structpw__timer.html#a832ec552d3fe6f869b3dca787063cdbb", null ],
      [ "queue", "structpw__timer.html#acf4006a9ae001df2816065aa1020330e", null ],
      [ "timeout", "structpw__timer.html#a83f4874becb6e73bf2a73a7ffec4e4fc", null ],
      [ "callback", "structpw__timer.html#a76ef18abe65958167e39bf879abb3430", null ],
      [ "data", "structpw__timer.html#a200b8df57bbb5c594db0d44fa642de54", null ],
      [ "padding", "structpw__timer.html#aba742fb172356034566569bce63191fe", null ]
    ] ],
    [ "pw_timer_callback", "group__pw__timer__queue.html#ga8299c4da01df7fd7f6e26d47c9467007", null ],
    [ "pw_timer_queue_new", "group__pw__timer__queue.html#ga7f78ace9ffd5e5685814d5b6f9591dbc", null ],
    [ "pw_timer_queue_destroy", "group__pw__timer__queue.html#ga4804427acbe7ca67418ce4458368dcd1", null ],
    [ "pw_timer_queue_add", "group__pw__timer__queue.html#ga7dbc93f67ae52f467d8888385fc0237e", null ],
    [ "pw_timer_queue_cancel", "group__pw__timer__queue.html#gadf90bc3fe35b836b12f3009e9339288a", null ]
];