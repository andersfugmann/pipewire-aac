var structpw__core__methods =
[
    [ "version", "structpw__core__methods.html#af1831e5a0a805bf3ed47e48dbd09ee3a", null ],
    [ "add_listener", "structpw__core__methods.html#a05db653bcc20405f5b6ce5ccbe215703", null ],
    [ "hello", "structpw__core__methods.html#a47721985e4d0b24474f5598d0d94b6c5", null ],
    [ "sync", "structpw__core__methods.html#ab64487c2ddac4c7d315cc54a4d5b7176", null ],
    [ "pong", "structpw__core__methods.html#a23e319c72a886a40464d74e2e19f27f9", null ],
    [ "error", "structpw__core__methods.html#aa5ee0b92d1e85c741adcaa93a04622fa", null ],
    [ "get_registry", "structpw__core__methods.html#a570886edc43416b3dcd10b48016493af", null ],
    [ "create_object", "structpw__core__methods.html#a7e70c82277387a47a953d64b0ba82cce", null ],
    [ "destroy", "structpw__core__methods.html#a460ee1de46fe6e281c576cbe54841309", null ]
];