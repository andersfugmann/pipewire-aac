var group__pw__gettext =
[
    [ "i18n.h", "src_2pipewire_2i18n_8h.html", null ],
    [ "_", "group__pw__gettext.html#ga32a3cf3d9dd914f5aeeca5423c157934", null ],
    [ "N_", "group__pw__gettext.html#ga75278405e7f034d2b1af80bfd94675fe", null ],
    [ "pw_gettext", "group__pw__gettext.html#gabf6ee6e384737da44f6fda594637c7d0", null ],
    [ "pw_ngettext", "group__pw__gettext.html#ga6e203b8f9c2893556d0f223817591afc", null ]
];