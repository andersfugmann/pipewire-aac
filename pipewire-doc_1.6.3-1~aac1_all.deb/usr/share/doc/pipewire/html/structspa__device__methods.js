var structspa__device__methods =
[
    [ "version", "structspa__device__methods.html#a232006e407b2abdb2450a440172186ee", null ],
    [ "add_listener", "structspa__device__methods.html#aac8a0ceced3319473ab3edd4271e1d64", null ],
    [ "sync", "structspa__device__methods.html#a25f49777c2e75988cd5fd7fc490479c8", null ],
    [ "enum_params", "structspa__device__methods.html#a3c9741ff5de62f38f2e3eca50ae24a10", null ],
    [ "set_param", "structspa__device__methods.html#aa5bfc95e88b2f018dddc55fb64899215", null ]
];