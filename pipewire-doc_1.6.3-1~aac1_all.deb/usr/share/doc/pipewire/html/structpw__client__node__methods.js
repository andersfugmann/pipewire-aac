var structpw__client__node__methods =
[
    [ "version", "structpw__client__node__methods.html#acf64a3bd71fd790592e41458a4793c62", null ],
    [ "add_listener", "structpw__client__node__methods.html#a05968e322e128af7d58f1598ad61af7e", null ],
    [ "get_node", "structpw__client__node__methods.html#a0d45045558276d9594008b5ac39ad404", null ],
    [ "update", "group__pw__client__node.html#ga3472e36b6ef5e4d2267b86272ba5b1a6", null ],
    [ "port_update", "group__pw__client__node.html#ga8f467593dff291edaac0f46531c23aed", null ],
    [ "set_active", "structpw__client__node__methods.html#ae7a71dd91cda53767aa31aa10c050244", null ],
    [ "event", "structpw__client__node__methods.html#a0193c45d32cc6806d8b1f4ef9c7a2740", null ],
    [ "port_buffers", "structpw__client__node__methods.html#a1db43e226468e68a6a52292aa6a894c6", null ]
];