var structspa__audio__info__ra =
[
    [ "rate", "structspa__audio__info__ra.html#aa5374f33cf4a773ca3bb779d3e199fc9", null ],
    [ "channels", "structspa__audio__info__ra.html#a281cd0f54656e1ccfda03854e5d36ce2", null ]
];