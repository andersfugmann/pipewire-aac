var structpw__impl__factory__implementation =
[
    [ "version", "structpw__impl__factory__implementation.html#ab63e939995687efd690f736730021e7f", null ],
    [ "create_object", "structpw__impl__factory__implementation.html#a99eef2345bd7b402f47ad72beb6ebfe7", null ]
];