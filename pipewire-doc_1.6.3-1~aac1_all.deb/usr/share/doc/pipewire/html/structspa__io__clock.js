var structspa__io__clock =
[
    [ "flags", "structspa__io__clock.html#ab3d44cc4e16a47abd913553c3b977051", null ],
    [ "id", "structspa__io__clock.html#ab639d1a64a22eecfa76ca04001bc163d", null ],
    [ "nsec", "structspa__io__clock.html#a726264b491673c896b53038752149ecb", null ],
    [ "rate", "structspa__io__clock.html#a96d1fa8bd97bb1a840403a103853673e", null ],
    [ "position", "structspa__io__clock.html#a4813e6c9101d56eb1f3ac2e9eda1d8c8", null ],
    [ "duration", "structspa__io__clock.html#af384237834c65792f29ccfd3fadfeefe", null ],
    [ "delay", "structspa__io__clock.html#af8fa38eef9a514c13306bd01da06e776", null ],
    [ "rate_diff", "structspa__io__clock.html#aaddd01ce3e78da42c39efdeab2180035", null ],
    [ "next_nsec", "structspa__io__clock.html#a3242b88552347adc2e406b75f8136060", null ],
    [ "target_rate", "structspa__io__clock.html#a02274245ac560717fc5c06ddc66553ff", null ],
    [ "target_duration", "structspa__io__clock.html#ad5f6c0254efd87a20ca5807b577d3473", null ],
    [ "target_seq", "structspa__io__clock.html#af91526e984d8c9453e8b98c12dd1f500", null ],
    [ "cycle", "structspa__io__clock.html#a4fae975c36d6534e368ef396961b23b9", null ],
    [ "xrun", "structspa__io__clock.html#a3dc77892eea443b66c01d2acc91acaeb", null ]
];