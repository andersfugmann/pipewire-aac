var structspa__device__events =
[
    [ "version", "structspa__device__events.html#ad79a5bdce6b6bd7b299baa38330c96a7", null ],
    [ "info", "structspa__device__events.html#a64cea4459b8c4a483d0a2dd684f3e132", null ],
    [ "result", "structspa__device__events.html#a0b9ba211d7f484c7df9ac269d5b49af3", null ],
    [ "event", "structspa__device__events.html#a5b83e45fd5922657978cc36df24cc1c7", null ],
    [ "object_info", "structspa__device__events.html#a830fadb39e2a8658f9b4cb663619cf4b", null ]
];