var structspa__buffer =
[
    [ "n_metas", "structspa__buffer.html#a026a97e0dfd3a606480f436fa61e204b", null ],
    [ "n_datas", "structspa__buffer.html#adbf5510ef0707e22b19980c84b61a073", null ],
    [ "metas", "structspa__buffer.html#a9705c915e89400eaa96a1fe84209e53e", null ],
    [ "datas", "structspa__buffer.html#ad4c72bfda8875b33b7316af4bafb9560", null ]
];