var structspa__node__callbacks =
[
    [ "version", "structspa__node__callbacks.html#a249a8d683dc8b92cdca1c0b9eed75d4d", null ],
    [ "ready", "structspa__node__callbacks.html#a2e4fa7f89e8c1d306d44569191c44311", null ],
    [ "reuse_buffer", "structspa__node__callbacks.html#a48ef28f7570e07dbfb45fdb247e02671", null ],
    [ "xrun", "structspa__node__callbacks.html#a597eb6e41252d8030e4d697b51406ad0", null ]
];