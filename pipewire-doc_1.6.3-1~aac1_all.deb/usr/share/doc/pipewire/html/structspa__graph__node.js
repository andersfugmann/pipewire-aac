var structspa__graph__node =
[
    [ "link", "structspa__graph__node.html#a6215edd0d426cfc8e697d648c09a4f57", null ],
    [ "graph", "structspa__graph__node.html#a7a4bea046f4d6a88d97e12a5297ed740", null ],
    [ "ports", "structspa__graph__node.html#aec1169015c1d7a4aaea10d5f4946f7d4", null ],
    [ "links", "structspa__graph__node.html#acfb4e7658140701927336dee05ed1948", null ],
    [ "flags", "structspa__graph__node.html#a23c316f71a255a568e96092e72c40cae", null ],
    [ "state", "structspa__graph__node.html#ada29bc9109cd890c74cfba630989b76c", null ],
    [ "graph_link", "structspa__graph__node.html#acbee04440eefb9b0a77f69ff1876dbc0", null ],
    [ "subgraph", "structspa__graph__node.html#ab16592a35d02f827271786b49110341c", null ],
    [ "callbacks", "structspa__graph__node.html#a6664b3c60baddc151a340bf2ebb3a5a2", null ],
    [ "sched_link", "structspa__graph__node.html#af4ae9586aa3d544a48414987f1839a67", null ]
];