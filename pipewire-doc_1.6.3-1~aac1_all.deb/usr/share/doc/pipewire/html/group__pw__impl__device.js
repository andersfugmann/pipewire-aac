var group__pw__impl__device =
[
    [ "impl-device.h", "impl-device_8h.html", null ],
    [ "pw_impl_device_events", "structpw__impl__device__events.html", [
      [ "version", "structpw__impl__device__events.html#adbb4dbff59d4c076dd28626b2b2de840", null ],
      [ "destroy", "structpw__impl__device__events.html#a537507ed435ab1f01c34e063d9f48982", null ],
      [ "free", "structpw__impl__device__events.html#a04b3922036844e0e7eb8f51671ac19e5", null ],
      [ "initialized", "structpw__impl__device__events.html#ad9bbb080f7502ba24a6c170461078884", null ],
      [ "info_changed", "structpw__impl__device__events.html#aee86b69561fd8e8f0525223ed8685e60", null ]
    ] ],
    [ "pw_impl_device", "structpw__impl__device.html", null ],
    [ "PW_VERSION_IMPL_DEVICE_EVENTS", "group__pw__impl__device.html#ga14cf46f067be94c56b3e893b7711e0d1", null ],
    [ "pw_context_create_device", "group__pw__impl__device.html#gaf7a2385c66b42b5a5a48a53999c05ac8", null ],
    [ "pw_impl_device_register", "group__pw__impl__device.html#ga5ad9e42ea1d048840b5ef3785ff5034d", null ],
    [ "pw_impl_device_destroy", "group__pw__impl__device.html#ga206bef1c4398d878a95dac034d008cb9", null ],
    [ "pw_impl_device_get_user_data", "group__pw__impl__device.html#ga0b276d268df05641e6835facbbaa3c48", null ],
    [ "pw_impl_device_set_implementation", "group__pw__impl__device.html#ga231905eac744e7eeae3512c6e90a5079", null ],
    [ "pw_impl_device_get_implementation", "group__pw__impl__device.html#ga216a66f5646678bdeb761ccdecc530b2", null ],
    [ "pw_impl_device_get_global", "group__pw__impl__device.html#gaa2740ec45018e6799a0ff92d12fe7c97", null ],
    [ "pw_impl_device_add_listener", "group__pw__impl__device.html#ga8365dd9ac6c4cc731cbc7bcbd5a68c8a", null ],
    [ "pw_impl_device_update_properties", "group__pw__impl__device.html#gadde284a435764d784c07179253f01b7a", null ],
    [ "pw_impl_device_get_properties", "group__pw__impl__device.html#ga2786a192d34aa5b9901543cd677e48d7", null ],
    [ "pw_impl_device_for_each_param", "group__pw__impl__device.html#gab94fa183d46cce3606c559ca10df16ce", null ]
];