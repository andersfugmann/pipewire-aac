/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "PipeWire", "index.html", [
    [ "Overview", "page_overview.html", null ],
    [ "Configuration", "page_config.html", "page_config" ],
    [ "Programs", "page_programs.html", "page_programs" ],
    [ "Modules", "page_modules.html", "page_modules" ],
    [ "Pulseaudio Modules", "page_pulse_modules.html", "page_pulse_modules" ],
    [ "Internals", "page_internals.html", "page_internals" ],
    [ "PipeWire API", "page_api.html", "page_api" ],
    [ "API Tutorial", "page_tutorial.html", "page_tutorial" ],
    [ "API Reference", "topics.html", "topics" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ]
    ] ],
    [ "Examples", "examples.html", "examples" ],
    [ "PipeWire Versions", "usergroup0.html", [
      [ "1.2.x", "^https://docs.pipewire.org/1.2/", null ],
      [ "1.4.x", "^https://docs.pipewire.org/1.4/", null ],
      [ "1.6.x", "^https://docs.pipewire.org/1.6/", null ],
      [ "Development", "^https://docs.pipewire.org/devel/", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"aac-types_8h.html",
"group__pw__core.html#ga844067d3c4ee799eebb94db3d3c29e09",
"group__pw__impl__metadata.html#gaa6f28989938dc595ccded5afe5d0c709",
"group__pw__keys.html#gaf4643e961de004488943e2ab0322ac4c",
"group__pw__permission.html#ga4564637816ca41369b383af05951a3b7",
"group__pw__session__manager.html#ga31cff50a1b1c9652e16d4666b39f890a",
"group__pw__utils.html#ga97004c44df1cac3ac75257c40ff8ce58",
"group__spa__debug.html#ga136cf4d2d230a5f6deae8e2b386c3bee",
"group__spa__interfaces.html#gaf9eef5cf634711b4de82fc5f9e3802ee",
"group__spa__names.html#ga010bfd1f2c50f4927df733f5f13e5690",
"group__spa__param.html#ga043c422a1329d7456fec05aba5ec9710",
"group__spa__param.html#ga9ee7ee937054acf61c0fa3b0943508c4",
"group__spa__param.html#gga339d759aafadca6ef623f32ce7e65be0a871dcd85dad60d460bbad9176d23d048",
"group__spa__param.html#gga741ca54fc7f93308779660120bbed31eafe30d2fb50cb6f7a1964877b073252a1",
"group__spa__param.html#ggad544eabde6eb05d43433b18e78f9c5d1a5012d63db372da6a3e3f046e3ea63cea",
"group__spa__pod.html#ga582fb9a481313638185ce6f158eda737",
"group__spa__ringbuffer.html#gad620fa22ac4d12b7f482e50525e1242f",
"h264_8h.html",
"page_pulse_module_rtp_recv.html",
"structpw__core__methods.html#a460ee1de46fe6e281c576cbe54841309",
"structpw__loop.html#abab71679705176a16c9e27b3115701c3",
"structpw__timer.html#a200b8df57bbb5c594db0d44fa642de54",
"structspa__event.html#a2411141eed88d3587687a8d86c99d488",
"structspa__loop__utils__methods.html#adc8b3b97121c94a824307117dad02989",
"structspa__result__node__params__data.html#a8815a2e634f16dff3598e1a2fee6e469"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';
var LISTOFALLMEMBERS = 'List of all members';