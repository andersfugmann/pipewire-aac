var structpw__protocol__native__message =
[
    [ "id", "structpw__protocol__native__message.html#a32d56d90a40415a584d28262cb30941e", null ],
    [ "opcode", "structpw__protocol__native__message.html#aef6ddaa16aeaa35b4276e3b2767268aa", null ],
    [ "data", "structpw__protocol__native__message.html#a60ea6289ac35a79b83b7e1caa0c8edf6", null ],
    [ "size", "structpw__protocol__native__message.html#ad9a08cd2b12fa38a8d222308270faf40", null ],
    [ "n_fds", "structpw__protocol__native__message.html#a6c4a9b3a354cf7f37c8c4aa25de81d67", null ],
    [ "fds", "structpw__protocol__native__message.html#abaad1bc5e0c163fa89fea9c0d0852c4f", null ],
    [ "seq", "structpw__protocol__native__message.html#a45a77f421d3b6b1123b85883e28b48b3", null ]
];