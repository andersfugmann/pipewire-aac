var structspa__log =
[
    [ "iface", "structspa__log.html#a2904120a458d402fce2b316280f677c6", null ],
    [ "level", "structspa__log.html#aeb76fd47b796f30c75d48512b390cedb", null ]
];