var structpw__session__info =
[
    [ "version", "structpw__session__info.html#aa58e4f042f5cf3226d0765654439a9a3", null ],
    [ "id", "structpw__session__info.html#aa2d06aa8a36c3da1890e37f02e4702a6", null ],
    [ "change_mask", "structpw__session__info.html#a1289ec21ec9441f29314a561b341cf13", null ],
    [ "params", "structpw__session__info.html#a00aaf0720fd58ae285a1fe122ab0fb93", null ],
    [ "n_params", "structpw__session__info.html#abfebf0a6ad9331c4690ffad37894d660", null ]
];