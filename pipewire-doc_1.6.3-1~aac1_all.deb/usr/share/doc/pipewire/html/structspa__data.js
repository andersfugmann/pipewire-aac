var structspa__data =
[
    [ "type", "structspa__data.html#afe135d90bee247325e72ba2f33dd9864", null ],
    [ "flags", "structspa__data.html#a997e0a03014d4455fbb993c0d7aa0c82", null ],
    [ "fd", "structspa__data.html#a504188801211b4dcaae3fc2e37653752", null ],
    [ "mapoffset", "structspa__data.html#a75b63dcf6ea09c5908b8682f1696eeae", null ],
    [ "maxsize", "structspa__data.html#ae942ee4f53c1ae2b708fdea5aa334406", null ],
    [ "data", "structspa__data.html#ac4930c9bcfff1327bc57c27a436f6451", null ],
    [ "chunk", "structspa__data.html#a2ac8186060605f0c2e23d383dc702c18", null ]
];