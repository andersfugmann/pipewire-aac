var structpw__filter__events =
[
    [ "version", "structpw__filter__events.html#a5a03c51cf03b2e8408ead88cc66b25cd", null ],
    [ "destroy", "structpw__filter__events.html#adb8416b044c19f8856dac1d2b554f32a", null ],
    [ "state_changed", "structpw__filter__events.html#afb8a57497ec76189b2fd247ce72966c5", null ],
    [ "io_changed", "structpw__filter__events.html#a58d1c6027c07caec0ed77edd5dbdac5b", null ],
    [ "param_changed", "structpw__filter__events.html#a56e04005c73bc3b32cda5b0febfb67cc", null ],
    [ "add_buffer", "structpw__filter__events.html#aca5d0df9b247219e850a94be2bf9d135", null ],
    [ "remove_buffer", "structpw__filter__events.html#aa541b66c8fa1cbf804d9ebf8c9aad239", null ],
    [ "process", "structpw__filter__events.html#a324db3b12bbac07c495395eae521e97a", null ],
    [ "drained", "structpw__filter__events.html#a74a4deeb45f4626823c44cab4ace174a", null ],
    [ "command", "structpw__filter__events.html#a7ded13531102414fec81a846974f5728", null ]
];