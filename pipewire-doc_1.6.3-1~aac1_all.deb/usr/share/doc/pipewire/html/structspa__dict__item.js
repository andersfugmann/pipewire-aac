var structspa__dict__item =
[
    [ "key", "structspa__dict__item.html#a16dc8153e2ea77c9c82380456734478a", null ],
    [ "value", "structspa__dict__item.html#af08479e3ff870039be002b436a02457d", null ]
];