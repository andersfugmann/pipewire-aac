var structpw__factory__methods =
[
    [ "version", "structpw__factory__methods.html#aa3d553e1352e95ecc6870f28cb98a5fe", null ],
    [ "add_listener", "structpw__factory__methods.html#af8cbd6088a874710de9c066169a75d6a", null ]
];