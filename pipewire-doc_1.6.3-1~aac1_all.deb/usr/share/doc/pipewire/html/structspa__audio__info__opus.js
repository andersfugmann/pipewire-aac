var structspa__audio__info__opus =
[
    [ "rate", "structspa__audio__info__opus.html#abf65d8f7d0877d50068bb68cff1f3e44", null ],
    [ "channels", "structspa__audio__info__opus.html#ab354cfeab8ed9e4561332f86f77f5397", null ]
];