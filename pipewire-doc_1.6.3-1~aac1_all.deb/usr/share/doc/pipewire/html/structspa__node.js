var structspa__node =
[
    [ "iface", "structspa__node.html#a898fcb8b2d37d7c42fd9c15d1f8c1ed7", null ]
];