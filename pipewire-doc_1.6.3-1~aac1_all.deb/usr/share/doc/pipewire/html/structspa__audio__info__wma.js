var structspa__audio__info__wma =
[
    [ "rate", "structspa__audio__info__wma.html#ad572e9079c943a87b18d96060ced5af4", null ],
    [ "channels", "structspa__audio__info__wma.html#a08102a7049195a3a9f5b734a6b8f7be5", null ],
    [ "bitrate", "structspa__audio__info__wma.html#a46f090f295f02f54aaa427abb93d44e2", null ],
    [ "block_align", "structspa__audio__info__wma.html#a328501d7905f732937932d3731916a55", null ],
    [ "profile", "structspa__audio__info__wma.html#a0bf6e6bad02abf194f2d65b5b458e7ba", null ]
];