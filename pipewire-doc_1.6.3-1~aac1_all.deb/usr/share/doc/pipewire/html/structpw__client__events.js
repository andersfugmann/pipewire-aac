var structpw__client__events =
[
    [ "version", "structpw__client__events.html#a0ceb2ae8884ca4a30bae720198410075", null ],
    [ "info", "structpw__client__events.html#a58af5a46ef2875bf85f2683ed522d254", null ],
    [ "permissions", "structpw__client__events.html#af685647fe57d1a9dba2a0d89d32aae39", null ]
];