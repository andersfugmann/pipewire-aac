var structpw__client__endpoint__methods =
[
    [ "version", "structpw__client__endpoint__methods.html#a58fe2e1f1524cf0f22dda84f7f9c33e0", null ],
    [ "add_listener", "structpw__client__endpoint__methods.html#a283f6ec14d1a3ff9b0b0aa213b2ea850", null ],
    [ "update", "group__pw__session__manager.html#gaa8366fa5903ce48d728d5a4bf1eb6ff2", null ],
    [ "stream_update", "group__pw__session__manager.html#gaf6d9b5f36fb09c37ae8e1cd3716618e5", null ]
];