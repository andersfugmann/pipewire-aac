var structpw__endpoint__link__methods =
[
    [ "version", "structpw__endpoint__link__methods.html#a339f0750fb1ab4709b832f87366a0f60", null ],
    [ "add_listener", "structpw__endpoint__link__methods.html#a790b919611ad52e740c6c3baa09f2bf0", null ],
    [ "subscribe_params", "structpw__endpoint__link__methods.html#ac85085528468519f49c7bba87a12f2cd", null ],
    [ "enum_params", "structpw__endpoint__link__methods.html#acb694bb5ac728b0b436b71815732b9e2", null ],
    [ "set_param", "structpw__endpoint__link__methods.html#a000fb2581dc5831e616635aca029165e", null ],
    [ "request_state", "structpw__endpoint__link__methods.html#a2e15950aee91de65432410de0889a91f", null ]
];