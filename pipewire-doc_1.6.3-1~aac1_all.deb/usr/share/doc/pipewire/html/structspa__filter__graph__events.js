var structspa__filter__graph__events =
[
    [ "version", "structspa__filter__graph__events.html#a5679561cb1d6515e49f4719ef4edd33e", null ],
    [ "info", "structspa__filter__graph__events.html#ab5f3808cad27363303850727e8f917f3", null ],
    [ "apply_props", "structspa__filter__graph__events.html#ab0db05d4a9001e840f11c5a3169de2cb", null ],
    [ "props_changed", "structspa__filter__graph__events.html#a8fd95c909c7a64cbd856ffac8860824f", null ]
];