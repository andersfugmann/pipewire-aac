var structspa__audio__info__iec958 =
[
    [ "codec", "structspa__audio__info__iec958.html#adc76e7bde0fc3d66ffa5a8442c3b1409", null ],
    [ "flags", "structspa__audio__info__iec958.html#ab4797480f2e4e7f25d19a0a42c748eac", null ],
    [ "rate", "structspa__audio__info__iec958.html#af028b6675757cd4504ad1b11a2e746c7", null ]
];