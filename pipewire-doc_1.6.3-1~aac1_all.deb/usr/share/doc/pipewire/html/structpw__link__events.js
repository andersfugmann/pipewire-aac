var structpw__link__events =
[
    [ "version", "structpw__link__events.html#a36fd833d967b2b648424449197eb95c5", null ],
    [ "info", "structpw__link__events.html#a4f9f823d13092e197c89c151ea21b27b", null ]
];