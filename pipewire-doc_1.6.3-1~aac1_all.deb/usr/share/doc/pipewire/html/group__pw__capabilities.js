var group__pw__capabilities =
[
    [ "capabilities.h", "capabilities_8h.html", null ],
    [ "PW_CAPABILITY_DEVICE_ID_NEGOTIATION", "group__pw__capabilities.html#ga20c06a188296b946482d8d2964cdc032", null ],
    [ "PW_CAPABILITY_DEVICE_IDS", "group__pw__capabilities.html#ga057e255bd0e3b819779d9d2ade8b7e8f", null ],
    [ "PW_CAPABILITY_DEVICE_ID", "group__pw__capabilities.html#ga28972f3c98663e781466a7aa7e54c64f", null ]
];