var group__pw__security__context =
[
    [ "security-context.h", "security-context_8h.html", null ],
    [ "pw_security_context_events", "structpw__security__context__events.html", [
      [ "version", "structpw__security__context__events.html#a850daf6cc8301b0618be12fe37a30b81", null ]
    ] ],
    [ "pw_security_context_methods", "structpw__security__context__methods.html", [
      [ "version", "structpw__security__context__methods.html#a431ad7c170c6f5b2c13499d03997088d", null ],
      [ "add_listener", "structpw__security__context__methods.html#a4b13cd5a9739a3c82813276b8c875faa", null ],
      [ "create", "structpw__security__context__methods.html#a78e54bfd81f8e41605152161f29ad166", null ]
    ] ],
    [ "pw_security_context", "structpw__security__context.html", null ],
    [ "PW_TYPE_INTERFACE_SecurityContext", "group__pw__security__context.html#ga2c78bb5527539e13b74bf624edc8c044", null ],
    [ "PW_SECURITY_CONTEXT_PERM_MASK", "group__pw__security__context.html#gaac18d2708155ea3bbd0075cb79aaced1", null ],
    [ "PW_VERSION_SECURITY_CONTEXT", "group__pw__security__context.html#ga6da9d0e608f05ec4a9abb869885e48a9", null ],
    [ "PW_API_SECURITY_CONTEXT", "group__pw__security__context.html#gab592b8348343057e2fcfe74fae6abd51", null ],
    [ "PW_EXTENSION_MODULE_SECURITY_CONTEXT", "group__pw__security__context.html#ga12298f1482fad1c35a385a34f45e6872", null ],
    [ "PW_SECURITY_CONTEXT_EVENT_NUM", "group__pw__security__context.html#gad442632a8cf410ec525609c07485f578", null ],
    [ "PW_VERSION_SECURITY_CONTEXT_EVENTS", "group__pw__security__context.html#gaf9493e785ba08d9899f0bb693fb3c40b", null ],
    [ "PW_SECURITY_CONTEXT_METHOD_ADD_LISTENER", "group__pw__security__context.html#ga9cc1fce099b93fba7f084733002d5be1", null ],
    [ "PW_SECURITY_CONTEXT_METHOD_CREATE", "group__pw__security__context.html#ga1d857df854f893358903d28103ca23ae", null ],
    [ "PW_SECURITY_CONTEXT_METHOD_NUM", "group__pw__security__context.html#gaa02d30dd7f59f7310bb16a9eb1b1d11e", null ],
    [ "PW_VERSION_SECURITY_CONTEXT_METHODS", "group__pw__security__context.html#ga6ac2fda997fdd601ffd52c82e6a9d96b", null ],
    [ "pw_security_context_add_listener", "group__pw__security__context.html#gafddb7fe1e691b81dc07d205b639f116b", null ],
    [ "pw_security_context_create", "group__pw__security__context.html#gaa0da52ee00dd60307bcf68691bfa6a72", null ]
];