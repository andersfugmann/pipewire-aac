var group__pw__registry =
[
    [ "core.h", "core_8h.html", null ],
    [ "pw_registry_events", "structpw__registry__events.html", [
      [ "version", "structpw__registry__events.html#a94464d7de86207e80a3dff93974b1a01", null ],
      [ "global", "structpw__registry__events.html#a37bd7089a7a07d7154e111e67b25f96c", null ],
      [ "global_remove", "structpw__registry__events.html#a04c4f7cbbf5dcc0c54887862887dbc97", null ]
    ] ],
    [ "pw_registry_methods", "structpw__registry__methods.html", [
      [ "version", "structpw__registry__methods.html#a82488a74c02c5b764b0764b0d3e42fac", null ],
      [ "add_listener", "structpw__registry__methods.html#a91a13e6dbf685af929ced294d5816089", null ],
      [ "bind", "structpw__registry__methods.html#a743174c4df93282f1361f137383cb41a", null ],
      [ "destroy", "structpw__registry__methods.html#afe6865901f9bc87f009674959d12e60c", null ]
    ] ],
    [ "PW_REGISTRY_EVENT_GLOBAL", "group__pw__registry.html#gadf3f807d7cf834259e0ee5d1fddcce7a", null ],
    [ "PW_REGISTRY_EVENT_GLOBAL_REMOVE", "group__pw__registry.html#gad6a0258ff50f7c71f7b5d42033569428", null ],
    [ "PW_REGISTRY_EVENT_NUM", "group__pw__registry.html#gac2d679d17b73a0ccb01b6afff1810ffc", null ],
    [ "PW_VERSION_REGISTRY_EVENTS", "group__pw__registry.html#ga04010cf6cd7698a6702eab918717cf58", null ],
    [ "PW_REGISTRY_METHOD_ADD_LISTENER", "group__pw__registry.html#ga911d189930ae2198ff19f8fe66dcee15", null ],
    [ "PW_REGISTRY_METHOD_BIND", "group__pw__registry.html#ga2a38f2b9474b345dd09961560fa7aaac", null ],
    [ "PW_REGISTRY_METHOD_DESTROY", "group__pw__registry.html#gad58197f43a40ed4791f74c21471fc5c8", null ],
    [ "PW_REGISTRY_METHOD_NUM", "group__pw__registry.html#gaa7d1ac6646be6feac1f071f09422ac75", null ],
    [ "PW_VERSION_REGISTRY_METHODS", "group__pw__registry.html#gad9662f67cee6e6a37df16f6ec1924434", null ],
    [ "pw_registry_add_listener", "group__pw__registry.html#ga489f504357a3174226844d4cc29c94f3", null ],
    [ "pw_registry_bind", "group__pw__registry.html#gab169a76ef75f12083798c12ee1efd74b", null ],
    [ "pw_registry_destroy", "group__pw__registry.html#gaabc306d2f09ec27601a1bb646aa5a5dd", null ]
];