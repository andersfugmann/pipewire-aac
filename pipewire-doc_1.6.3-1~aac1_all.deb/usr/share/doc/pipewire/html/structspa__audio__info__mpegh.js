var structspa__audio__info__mpegh =
[
    [ "rate", "structspa__audio__info__mpegh.html#a3b86ae403e1f7387fb587180a01f56a3", null ]
];