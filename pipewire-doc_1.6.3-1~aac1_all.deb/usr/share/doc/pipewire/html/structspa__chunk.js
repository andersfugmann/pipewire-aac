var structspa__chunk =
[
    [ "offset", "structspa__chunk.html#ae7a889b81a5d56ff5babd521b5ce7cb7", null ],
    [ "size", "structspa__chunk.html#a73c84537a6f3a0da168f765cb3558735", null ],
    [ "stride", "structspa__chunk.html#a5a6f66c73b76acf608ef18846d539df2", null ],
    [ "flags", "structspa__chunk.html#ae77eb3c5ecf94cc2b80c306afd7a6768", null ]
];