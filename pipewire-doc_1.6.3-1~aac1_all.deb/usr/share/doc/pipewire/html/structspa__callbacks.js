var structspa__callbacks =
[
    [ "funcs", "structspa__callbacks.html#a0c52caccee37692f842b93785b3f7f22", null ],
    [ "data", "structspa__callbacks.html#adc0097ae82d42b5fc92e896f47e13ee5", null ]
];