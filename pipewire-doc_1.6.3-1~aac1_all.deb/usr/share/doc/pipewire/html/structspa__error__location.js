var structspa__error__location =
[
    [ "line", "structspa__error__location.html#a27e5f537468106c7c9512ef61cebdc0b", null ],
    [ "col", "structspa__error__location.html#a96cfad70df7abe445f4f3f803bff2ea3", null ],
    [ "len", "structspa__error__location.html#ac36183875ecfde9571bd8adb365e1e39", null ],
    [ "location", "structspa__error__location.html#a2dca332c84751285d399d0743ebf06b1", null ],
    [ "reason", "structspa__error__location.html#ac9798422ecc76aced802ceedddefdfce", null ]
];