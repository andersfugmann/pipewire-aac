var structspa__audio__layout__info =
[
    [ "n_channels", "structspa__audio__layout__info.html#abd815a9154f329d6a02f84f222bca93a", null ],
    [ "position", "structspa__audio__layout__info.html#a939d325d78f6c2cb4492fda99fe3efd0", null ]
];