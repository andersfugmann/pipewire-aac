var structpw__port__methods =
[
    [ "version", "structpw__port__methods.html#a77b4f3e654eb54c6066faa61fa478186", null ],
    [ "add_listener", "structpw__port__methods.html#adbe08858422d830443b9f111cd6d44bd", null ],
    [ "subscribe_params", "structpw__port__methods.html#a3c19aedb668ea1a71bc12f89b106d94a", null ],
    [ "enum_params", "structpw__port__methods.html#a902dc57cb5eaae752960a0667ff10ab8", null ]
];