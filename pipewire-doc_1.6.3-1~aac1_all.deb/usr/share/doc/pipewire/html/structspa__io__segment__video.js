var structspa__io__segment__video =
[
    [ "flags", "structspa__io__segment__video.html#abb72f2853693bb3cfad27520b41f3248", null ],
    [ "offset", "structspa__io__segment__video.html#aefffdac704f6aa878542c37d5cc7accb", null ],
    [ "framerate", "structspa__io__segment__video.html#a500d2d64d490ad483be879cb40b799b4", null ],
    [ "hours", "structspa__io__segment__video.html#ad9a1cecce33ac8e1c02532188fe51b5f", null ],
    [ "minutes", "structspa__io__segment__video.html#add60a69b800c7177da7a687fc47984db", null ],
    [ "seconds", "structspa__io__segment__video.html#a4f9acf42fec13d66072ac47ca9aad116", null ],
    [ "frames", "structspa__io__segment__video.html#ae1cc1d15b524665254cff4c3d5daeceb", null ],
    [ "field_count", "structspa__io__segment__video.html#a9c45645d7e6aa9aea4508336dd87d17d", null ],
    [ "padding", "structspa__io__segment__video.html#ae03652e1ab2e76a1a03a63d7bd0fcc99", null ]
];