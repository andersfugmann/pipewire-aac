var structspa__json =
[
    [ "cur", "structspa__json.html#a60cdc9944f16c66d15eace2d674d7e04", null ],
    [ "end", "structspa__json.html#a8c09dbf1f541a944ceef31cb0b4110af", null ],
    [ "parent", "structspa__json.html#ae765edf5a3ac4c7fe5be87c93f62b0c2", null ],
    [ "state", "structspa__json.html#a8a0962e6aafa40f4b0124bcbb94e04df", null ],
    [ "depth", "structspa__json.html#a0d67dd0c9901c7b451b224b4102e20fd", null ]
];