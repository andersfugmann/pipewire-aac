var structspa__audio__info__aac =
[
    [ "rate", "structspa__audio__info__aac.html#ab29a8d8e1cba013ab5008404ba2836ea", null ],
    [ "channels", "structspa__audio__info__aac.html#a16974760cfa2cbe91398d01fb7f4b947", null ],
    [ "bitrate", "structspa__audio__info__aac.html#a3b08334e341344e0035a7ee94a5c87a2", null ],
    [ "stream_format", "structspa__audio__info__aac.html#ad93ec0c832f6ed449d9e073068e221d1", null ]
];