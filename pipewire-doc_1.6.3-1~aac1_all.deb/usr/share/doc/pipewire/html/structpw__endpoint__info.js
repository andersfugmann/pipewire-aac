var structpw__endpoint__info =
[
    [ "version", "structpw__endpoint__info.html#abbedd652482907400c17a0e19ed4eefd", null ],
    [ "id", "structpw__endpoint__info.html#a444b5b544b0d120912b38a19c04da4f5", null ],
    [ "media_class", "structpw__endpoint__info.html#ac9c79172b3c9d4a42d622896d357eb4a", null ],
    [ "direction", "structpw__endpoint__info.html#a53e7835959ec347ff84295673cf8e834", null ],
    [ "flags", "structpw__endpoint__info.html#a652272ff97cabdbc2cb630e631319894", null ],
    [ "change_mask", "structpw__endpoint__info.html#a50f24fd870f36fe554ff1ce0cf29ab92", null ],
    [ "n_streams", "structpw__endpoint__info.html#af238696ba49e512e921eea434d3dee54", null ],
    [ "session_id", "structpw__endpoint__info.html#add8888495992bb7b239f5538db21202f", null ],
    [ "params", "structpw__endpoint__info.html#a1b2b450d001a613908596afb785c9bf6", null ],
    [ "n_params", "structpw__endpoint__info.html#a6509522ee4d9d9d6c2c546938b24f5bc", null ]
];