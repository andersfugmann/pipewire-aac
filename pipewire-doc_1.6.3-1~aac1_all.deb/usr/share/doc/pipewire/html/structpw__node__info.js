var structpw__node__info =
[
    [ "id", "structpw__node__info.html#a737754b76140ca4751f2cd68667ffaa2", null ],
    [ "max_input_ports", "structpw__node__info.html#a178dbb8570999efffa8584d13e52ce0e", null ],
    [ "max_output_ports", "structpw__node__info.html#ac312e1844784e77e412f6bb341814372", null ],
    [ "change_mask", "structpw__node__info.html#a88bcfe3c9dbce8c5c6ac7b663e4db009", null ],
    [ "n_input_ports", "structpw__node__info.html#ae3b1789c08bcae95888e042790c95b75", null ],
    [ "n_output_ports", "structpw__node__info.html#ab5c2457030a463ccdc6ca5291ced856f", null ],
    [ "state", "structpw__node__info.html#a125f4d8851630b989c86fc0ebc83fba0", null ],
    [ "error", "structpw__node__info.html#a48075df9117cf8e55b474c8d2d445a1d", null ],
    [ "params", "structpw__node__info.html#aa2bd90f2d1c5f570eac18709b2acc387", null ],
    [ "n_params", "structpw__node__info.html#add4c3cdb14e0baa27c6c28d8c4a4d7f1", null ]
];