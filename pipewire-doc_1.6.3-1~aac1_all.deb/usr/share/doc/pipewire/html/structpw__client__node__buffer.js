var structpw__client__node__buffer =
[
    [ "mem_id", "structpw__client__node__buffer.html#a0b4e8dbf6a9aad4e72153fd2bf5f6392", null ],
    [ "offset", "structpw__client__node__buffer.html#a1d524a38ed82fb88371d741bcb1e3ff0", null ],
    [ "size", "structpw__client__node__buffer.html#a003e6b6549d0dbd9e2c8a6030a1cfa85", null ],
    [ "buffer", "structpw__client__node__buffer.html#a27039caf89b376d354a33d1559e939b3", null ]
];