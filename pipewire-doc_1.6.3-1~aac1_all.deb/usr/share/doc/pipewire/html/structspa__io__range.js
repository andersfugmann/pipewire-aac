var structspa__io__range =
[
    [ "offset", "structspa__io__range.html#a2a824a298a2e459bb719ed29f57de141", null ],
    [ "min_size", "structspa__io__range.html#af3d7c25e34fd60458e8ca8cfa1067c92", null ],
    [ "max_size", "structspa__io__range.html#adac0f561e72d269206216a3327720ff7", null ]
];