var structpw__profiler__methods =
[
    [ "version", "structpw__profiler__methods.html#a6d6488538db93934b63ad3ee7fc3cc9a", null ],
    [ "add_listener", "structpw__profiler__methods.html#a036f959bbeba1ad5da22f20c0e66a1f8", null ]
];