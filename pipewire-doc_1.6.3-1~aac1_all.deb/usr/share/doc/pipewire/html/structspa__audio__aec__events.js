var structspa__audio__aec__events =
[
    [ "version", "structspa__audio__aec__events.html#ab137f922d3a547caf388c5c11be2e5ce", null ],
    [ "info", "structspa__audio__aec__events.html#a355f3bedb9b4094912577187225797d9", null ]
];