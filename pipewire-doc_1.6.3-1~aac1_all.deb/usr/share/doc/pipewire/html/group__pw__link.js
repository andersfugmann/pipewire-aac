var group__pw__link =
[
    [ "link.h", "link_8h.html", null ],
    [ "pw_link_info", "structpw__link__info.html", [
      [ "id", "structpw__link__info.html#a0c7b378ed65b5311702cd2b693d6b819", null ],
      [ "output_node_id", "structpw__link__info.html#a5a21130d91e20dafc4ce1b09b7c30aca", null ],
      [ "output_port_id", "structpw__link__info.html#a0513f644f43b252a0e068e09c8452382", null ],
      [ "input_node_id", "structpw__link__info.html#ad4e7766ec44b62455169b916c3cdbbb1", null ],
      [ "input_port_id", "structpw__link__info.html#afaa2ba4fad6933cc019375c14f103120", null ],
      [ "change_mask", "structpw__link__info.html#a274785180186fbe127e48715092d775a", null ],
      [ "state", "structpw__link__info.html#a64ff3f8d01d62e5e2ed86933fd6b15e1", null ],
      [ "error", "structpw__link__info.html#a98d810a2a69da694add77f70b2f86061", null ],
      [ "format", "structpw__link__info.html#ae62f88ba3c96b5465a0b046ce93acdd5", null ]
    ] ],
    [ "pw_link_events", "structpw__link__events.html", [
      [ "version", "structpw__link__events.html#a36fd833d967b2b648424449197eb95c5", null ],
      [ "info", "structpw__link__events.html#a4f9f823d13092e197c89c151ea21b27b", null ]
    ] ],
    [ "pw_link_methods", "structpw__link__methods.html", [
      [ "version", "structpw__link__methods.html#a93094b3a43a3dd5911e6016f1cbd44cf", null ],
      [ "add_listener", "structpw__link__methods.html#ae0864a9eb97073db8174b051b074f180", null ]
    ] ],
    [ "pw_link", "structpw__link.html", null ],
    [ "pw_link_state", "group__pw__link.html#ga7859f6eb040fead1673d0214b83b445b", [
      [ "PW_LINK_STATE_ERROR", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445ba1cdbf68b2f1a25b0c6202141e9069f70", null ],
      [ "PW_LINK_STATE_UNLINKED", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445ba2ae1f2004f19f37a37c6fb21ccc7157b", null ],
      [ "PW_LINK_STATE_INIT", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445baebfc67d86c96c1d6cab229600b46a041", null ],
      [ "PW_LINK_STATE_NEGOTIATING", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445ba843c796704968af8538babd8f5c642e2", null ],
      [ "PW_LINK_STATE_ALLOCATING", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445baec2b9ab9232c60cf2c436d785ff15ddc", null ],
      [ "PW_LINK_STATE_PAUSED", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445ba369af04b8025470a27c313640bbb4bc0", null ],
      [ "PW_LINK_STATE_ACTIVE", "group__pw__link.html#gga7859f6eb040fead1673d0214b83b445ba18fa086cc84e690d88d9e029c53da1b4", null ]
    ] ],
    [ "PW_TYPE_INTERFACE_Link", "group__pw__link.html#ga0f2b028863c04de464bc9f84fa8a00aa", null ],
    [ "PW_LINK_PERM_MASK", "group__pw__link.html#ga74ce50685c3953853ae73bb26730c9c4", null ],
    [ "PW_VERSION_LINK", "group__pw__link.html#gaa90bcda1ac9edbb5f2c92703f1e38d84", null ],
    [ "PW_API_LINK_IMPL", "group__pw__link.html#gaa7105f182c11f7e090cb2836c544ee91", null ],
    [ "PW_LINK_CHANGE_MASK_STATE", "group__pw__link.html#ga4fd8cdb5e29131594e4008770ba7102c", null ],
    [ "PW_LINK_CHANGE_MASK_FORMAT", "group__pw__link.html#ga72d8e03483fd111c9a9eb87aac3897a2", null ],
    [ "PW_LINK_CHANGE_MASK_PROPS", "group__pw__link.html#ga26c6617beb9f6c949e94ed06bed1cdf2", null ],
    [ "PW_LINK_CHANGE_MASK_ALL", "group__pw__link.html#ga5856c4bf425be34681be7fd3693ff846", null ],
    [ "PW_LINK_EVENT_INFO", "group__pw__link.html#ga481b4d0b9cd49478fd13dc8934478840", null ],
    [ "PW_LINK_EVENT_NUM", "group__pw__link.html#ga17b648acf6eedef254434bf612f83f14", null ],
    [ "PW_VERSION_LINK_EVENTS", "group__pw__link.html#gaa09465885f2b5edd3aecf62a2e8f7ef7", null ],
    [ "PW_LINK_METHOD_ADD_LISTENER", "group__pw__link.html#ga5d3c859845886244df9d51621460f53b", null ],
    [ "PW_LINK_METHOD_NUM", "group__pw__link.html#ga48c5bb1ab03972f1ecf21dd01861b2c4", null ],
    [ "PW_VERSION_LINK_METHODS", "group__pw__link.html#ga4796803290f46ec3439ecebfb0c97a98", null ],
    [ "pw_link_state_as_string", "group__pw__link.html#ga364b6ed143112bf432e1795503cc8e6e", null ],
    [ "pw_link_info_update", "group__pw__link.html#ga7602f28360acd4519b5205b671662213", null ],
    [ "pw_link_info_merge", "group__pw__link.html#ga612c4f639f150e68fc981f834a82fa0f", null ],
    [ "pw_link_info_free", "group__pw__link.html#ga7499737d4d9014d7b632fdebb08ce66e", null ],
    [ "pw_link_add_listener", "group__pw__link.html#gad91637525a60f096b6997908039f6c32", null ]
];