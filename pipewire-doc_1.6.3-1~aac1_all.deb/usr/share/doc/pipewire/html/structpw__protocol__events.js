var structpw__protocol__events =
[
    [ "version", "structpw__protocol__events.html#af7bb9abb40f974acecda6bb2c6ad5cad", null ],
    [ "destroy", "structpw__protocol__events.html#ab341415c5d72294c801c580ac9653426", null ]
];