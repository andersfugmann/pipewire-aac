var structspa__dict =
[
    [ "flags", "structspa__dict.html#a88aca003fcdbc47599ffb3e2737f1a69", null ],
    [ "n_items", "structspa__dict.html#a3b3b78bfe5fffe13a10720bb7099c399", null ],
    [ "items", "structspa__dict.html#a1f1083da3fcd51b9c3eb22cc8f1d54e0", null ]
];