var structspa__loop__control__hooks =
[
    [ "version", "structspa__loop__control__hooks.html#a1d60078aab0c143a082ab30e91151dd2", null ],
    [ "before", "structspa__loop__control__hooks.html#a129526ea88e29db103f01666a32c2d20", null ],
    [ "after", "structspa__loop__control__hooks.html#a94545cf994d47a1acc84437e5c357141", null ]
];