var structspa__debug__log__ctx =
[
    [ "ctx", "structspa__debug__log__ctx.html#a89c265ff2c1860bc78cb3a71e016c44a", null ],
    [ "log", "structspa__debug__log__ctx.html#a7834e2a074032895d9760015da193685", null ],
    [ "level", "structspa__debug__log__ctx.html#a7ef044cf8f043c056c0f09e7dc52772f", null ],
    [ "topic", "structspa__debug__log__ctx.html#afcdc7fd8504c905b64485893b6816ee2", null ],
    [ "file", "structspa__debug__log__ctx.html#abcfc47fb7d6acf39603b9a1547edd1e7", null ],
    [ "line", "structspa__debug__log__ctx.html#a49ae612d5a9f8abff00d338e0f42f338", null ],
    [ "func", "structspa__debug__log__ctx.html#a283294f711d9752bb65c8c09e5a06724", null ]
];