var structspa__event =
[
    [ "pod", "structspa__event.html#a2411141eed88d3587687a8d86c99d488", null ],
    [ "body", "structspa__event.html#a1cfdf789b23f6f0ba623f3fc973951bb", null ]
];