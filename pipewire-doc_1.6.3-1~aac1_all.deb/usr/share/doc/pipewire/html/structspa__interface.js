var structspa__interface =
[
    [ "type", "structspa__interface.html#a99da3754855d6dd1430d21ed97fa0bfb", null ],
    [ "version", "structspa__interface.html#a2572eec5caf615f77e143013373cdcdf", null ],
    [ "cb", "structspa__interface.html#ae748ef778a029468d301c3727c80a85b", null ]
];