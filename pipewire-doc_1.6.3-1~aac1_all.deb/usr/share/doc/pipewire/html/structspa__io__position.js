var structspa__io__position =
[
    [ "clock", "structspa__io__position.html#a0e69b290ceddaa228852e517d67a8ff8", null ],
    [ "video", "structspa__io__position.html#a112b0de264eccfba2c44c9a4a917b83d", null ],
    [ "offset", "structspa__io__position.html#afa5a197f2a03c7b71ed7d99bcd3a3718", null ],
    [ "state", "structspa__io__position.html#a576f55a0a4a9b468cedb3c4ccb41a0c4", null ],
    [ "n_segments", "structspa__io__position.html#a6381154ac49e6f6f37c2a7d65366b7b8", null ],
    [ "segments", "structspa__io__position.html#a6b6da4b94ab7924dda2007712ff2e8f1", null ]
];