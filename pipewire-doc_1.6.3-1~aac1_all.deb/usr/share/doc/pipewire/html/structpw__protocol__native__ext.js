var structpw__protocol__native__ext =
[
    [ "version", "structpw__protocol__native__ext.html#a588964b2fd1a055deb2d0ab1455e3e9f", null ],
    [ "begin_proxy", "structpw__protocol__native__ext.html#a3de6ba89d6e099eee955acf2744a52da", null ],
    [ "add_proxy_fd", "structpw__protocol__native__ext.html#a356887f5340ad05b4b8ba90f26238565", null ],
    [ "get_proxy_fd", "structpw__protocol__native__ext.html#a04968e51cb5e9777795800dce3eaaa76", null ],
    [ "end_proxy", "structpw__protocol__native__ext.html#a6eb6702a7aaeaa50172d66ed9a6f818a", null ],
    [ "begin_resource", "structpw__protocol__native__ext.html#a9c23c3dab6c416b7f92e3b3684ddae88", null ],
    [ "add_resource_fd", "structpw__protocol__native__ext.html#a92709bdf1f3f815be21a33f119b0d8e6", null ],
    [ "get_resource_fd", "structpw__protocol__native__ext.html#aee24b5ce6da772ce4167bfd88a8c7cdb", null ],
    [ "end_resource", "structpw__protocol__native__ext.html#a1a348ddd739378bbd4b996ef68de2adc", null ]
];