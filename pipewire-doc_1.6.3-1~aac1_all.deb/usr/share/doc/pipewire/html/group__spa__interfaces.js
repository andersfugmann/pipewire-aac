var group__spa__interfaces =
[
    [ "hook.h", "hook_8h.html", null ],
    [ "spa_callbacks", "structspa__callbacks.html", [
      [ "funcs", "structspa__callbacks.html#a0c52caccee37692f842b93785b3f7f22", null ],
      [ "data", "structspa__callbacks.html#adc0097ae82d42b5fc92e896f47e13ee5", null ]
    ] ],
    [ "spa_interface", "structspa__interface.html", [
      [ "type", "structspa__interface.html#a99da3754855d6dd1430d21ed97fa0bfb", null ],
      [ "version", "structspa__interface.html#a2572eec5caf615f77e143013373cdcdf", null ],
      [ "cb", "structspa__interface.html#ae748ef778a029468d301c3727c80a85b", null ]
    ] ],
    [ "SPA_CALLBACK_VERSION_MIN", "group__spa__interfaces.html#ga7eadf4e30be75d856d81c9b0d818b0e1", null ],
    [ "SPA_CALLBACK_CHECK", "group__spa__interfaces.html#gafbe7e2c178c8649d89fe3d6cfcb74c65", null ],
    [ "SPA_CALLBACKS_INIT", "group__spa__interfaces.html#ga7cd31fca0faa447261fb4425d8036bb5", null ],
    [ "SPA_INTERFACE_INIT", "group__spa__interfaces.html#gaf9eef5cf634711b4de82fc5f9e3802ee", null ],
    [ "spa_callbacks_call", "group__spa__interfaces.html#ga5f51d2f3b4df5eb44fa6163ba3958f5d", null ],
    [ "spa_callbacks_call_fast", "group__spa__interfaces.html#ga48dc1c688fd324d08a3eed9684abf41a", null ],
    [ "spa_callback_version_min", "group__spa__interfaces.html#gab3415032c65751a4b16279a6167f5972", null ],
    [ "spa_callback_check", "group__spa__interfaces.html#ga6492da0e834e92dbbcef7dd3026ce04f", null ],
    [ "spa_callbacks_call_res", "group__spa__interfaces.html#gac11e7999a90fa354ef765abf8a6f9696", null ],
    [ "spa_callbacks_call_fast_res", "group__spa__interfaces.html#ga82b852e58c524d44fa24aba3247ccebb", null ],
    [ "spa_interface_callback_version_min", "group__spa__interfaces.html#ga1566a7843972b177af627e6e16b86c26", null ],
    [ "spa_interface_callback_check", "group__spa__interfaces.html#ga8ba5c01fe17d8a199516e2d87e59c025", null ],
    [ "spa_interface_call", "group__spa__interfaces.html#ga1facc1b12f5dfb7e3362e9f1a6d3cb6c", null ],
    [ "spa_interface_call_fast", "group__spa__interfaces.html#ga333235e7b2636c920cfa766481e59729", null ],
    [ "spa_interface_call_res", "group__spa__interfaces.html#ga0b43b5a0ee8aa8f305d0c9971716e5b0", null ],
    [ "spa_interface_call_fast_res", "group__spa__interfaces.html#ga12d9c46094ccfe8448e2d592cc8f457b", null ],
    [ "spa_api_func_v", "group__spa__interfaces.html#ga1b51c7fdbe1f8410265a580f6c2f665b", null ],
    [ "spa_api_func_r", "group__spa__interfaces.html#ga64526227552ce1cb60b2d4b49093ab8e", null ],
    [ "spa_api_func_fast", "group__spa__interfaces.html#ga8faab01630487f11668e10c6cba2cba4", null ],
    [ "spa_api_method_v", "group__spa__interfaces.html#ga8c8d974afb29c051a7f1596212b1de7f", null ],
    [ "spa_api_method_r", "group__spa__interfaces.html#ga3084e1a22093fefb17159e1a28d898dc", null ],
    [ "spa_api_method_null_v", "group__spa__interfaces.html#gac944ac92ca54b76490092333606d7cc7", null ],
    [ "spa_api_method_null_r", "group__spa__interfaces.html#ga071ba70deed0b6fce61267018e58791e", null ],
    [ "spa_api_method_fast_v", "group__spa__interfaces.html#ga89958eb1868fd1d416a043be09796a8d", null ],
    [ "spa_api_method_fast_r", "group__spa__interfaces.html#ga420964156eb8e34991d5c44e29f1c6b1", null ]
];