var structpw__session__events =
[
    [ "version", "structpw__session__events.html#a9156a82a54dba4f5e6f7b045a31b5ac7", null ],
    [ "info", "structpw__session__events.html#a36371c5decff93c9c0c0688c19b2780c", null ],
    [ "param", "structpw__session__events.html#a6d9e402e306432f33e6fe085599416d7", null ]
];