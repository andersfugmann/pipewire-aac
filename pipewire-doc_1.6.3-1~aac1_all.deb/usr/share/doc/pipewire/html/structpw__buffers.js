var structpw__buffers =
[
    [ "mem", "structpw__buffers.html#af915317f3448e471390a13c48c0d873e", null ],
    [ "buffers", "structpw__buffers.html#adf149a809c1ea9c435ae7439391c87ed", null ],
    [ "n_buffers", "structpw__buffers.html#ad2d1496ce9316c04921470078b8046c5", null ],
    [ "flags", "structpw__buffers.html#ac6dff2ff3c481e5b092fca206e0c144f", null ]
];