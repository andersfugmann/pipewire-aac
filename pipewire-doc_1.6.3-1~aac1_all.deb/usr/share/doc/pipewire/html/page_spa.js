var page_spa =
[
    [ "SPA Design", "page_spa_design.html", null ],
    [ "SPA Plugins", "page_spa_plugins.html", null ],
    [ "SPA POD", "page_spa_pod.html", null ],
    [ "SPA Buffers", "page_spa_buffer.html", null ]
];