var structpw__core__info =
[
    [ "id", "structpw__core__info.html#ace1c72a0b6d18567a1156b2d961f63ca", null ],
    [ "cookie", "structpw__core__info.html#ab93eadf54d48e19762c4e6ebf5595083", null ],
    [ "user_name", "structpw__core__info.html#ad294c9fa79558c75141a731c4d812b42", null ],
    [ "host_name", "structpw__core__info.html#ade7cf9abf36e9cd82fe49ffa95159a2f", null ],
    [ "version", "structpw__core__info.html#a3e394e50023a597dafb391887249d4eb", null ],
    [ "change_mask", "structpw__core__info.html#a25d93390dbafcb433827ec29c195404f", null ]
];