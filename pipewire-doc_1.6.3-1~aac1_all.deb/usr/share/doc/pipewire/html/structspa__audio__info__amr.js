var structspa__audio__info__amr =
[
    [ "rate", "structspa__audio__info__amr.html#ac715c7089e6ff2b562a3762bd46136cb", null ],
    [ "channels", "structspa__audio__info__amr.html#a1b1d2870fa166b3de6bf2f5b1b45a05d", null ],
    [ "band_mode", "structspa__audio__info__amr.html#a42ebba3d8e2cdd474ef49fb4c4c6b0f4", null ]
];