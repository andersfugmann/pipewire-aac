var structpw__factory__events =
[
    [ "version", "structpw__factory__events.html#a92c9ad52c5b502a07bb45e29504dad2f", null ],
    [ "info", "structpw__factory__events.html#ad58b5fc377977b0ce5eef6877549a9b8", null ]
];