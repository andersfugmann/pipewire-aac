var structpw__export__type =
[
    [ "link", "structpw__export__type.html#a753c33021857c67d7bd9df56ebd13116", null ],
    [ "type", "structpw__export__type.html#a2a49749c0d81fc22b2d70845a5c04e3b", null ],
    [ "func", "structpw__export__type.html#a2697ec1513e5a9fd156bfd41a1c26d6a", null ]
];