var structpw__endpoint__stream__info =
[
    [ "version", "structpw__endpoint__stream__info.html#ae5c7fb592c52111ce8bfc96faf4fb523", null ],
    [ "id", "structpw__endpoint__stream__info.html#ae2e6491fda9eacf17fb4bf05caf5fe06", null ],
    [ "endpoint_id", "structpw__endpoint__stream__info.html#a24e5e8c23830fcf15bca4513230b6bf8", null ],
    [ "change_mask", "structpw__endpoint__stream__info.html#ae7e20969d89c3c94e3f073a5e433a80b", null ],
    [ "link_params", "structpw__endpoint__stream__info.html#ae1e52d894dfd26fac731016958df44cc", null ],
    [ "params", "structpw__endpoint__stream__info.html#a1edec61e343d4e5a7433258765704c9b", null ],
    [ "n_params", "structpw__endpoint__stream__info.html#a083c2b84553da989d2dfde58cf8fcb50", null ]
];