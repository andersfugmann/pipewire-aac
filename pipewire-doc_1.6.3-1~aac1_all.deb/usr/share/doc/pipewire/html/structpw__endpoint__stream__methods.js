var structpw__endpoint__stream__methods =
[
    [ "version", "structpw__endpoint__stream__methods.html#ab73e2f70fc5a78721ebb38118af947b5", null ],
    [ "add_listener", "structpw__endpoint__stream__methods.html#a06d4d4c207f88dd3e87dadee7401b785", null ],
    [ "subscribe_params", "structpw__endpoint__stream__methods.html#ae9591b91164d11c342bfb44f87010932", null ],
    [ "enum_params", "structpw__endpoint__stream__methods.html#ab7b9c94de60336876dac12fbd671e8cb", null ],
    [ "set_param", "structpw__endpoint__stream__methods.html#a795f1ab22b0899bc18142419723e369b", null ]
];