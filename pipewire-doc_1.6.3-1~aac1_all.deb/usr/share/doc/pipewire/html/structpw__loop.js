var structpw__loop =
[
    [ "system", "structpw__loop.html#abab71679705176a16c9e27b3115701c3", null ],
    [ "loop", "structpw__loop.html#a4624741580712c167c17bd9242be003f", null ],
    [ "control", "structpw__loop.html#a639de0bfd74cf9e292932aaed15182c5", null ]
];