var structspa__device =
[
    [ "iface", "structspa__device.html#a00d8f19734c35525e99ecaab33113d3f", null ]
];