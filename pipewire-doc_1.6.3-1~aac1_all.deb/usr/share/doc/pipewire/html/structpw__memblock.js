var structpw__memblock =
[
    [ "pool", "structpw__memblock.html#a66508184497a6f6e211eafa8f6e4edd7", null ],
    [ "id", "structpw__memblock.html#a1ca99934939d8b89c158a0256d6d906c", null ],
    [ "ref", "structpw__memblock.html#ac130234986a5d662d20a3e593448bbbd", null ],
    [ "flags", "structpw__memblock.html#a88d9c260a71ebd2413b9c4f6c6b84889", null ],
    [ "type", "structpw__memblock.html#a8fb4076dc9a00af2a3da6be6859b6a00", null ],
    [ "fd", "structpw__memblock.html#a4731883fd9899d0d668c0f44a16d3b33", null ],
    [ "size", "structpw__memblock.html#a8e96a2d24a5fc723b2a637de4bf700b1", null ],
    [ "map", "structpw__memblock.html#ae9876a344086ff407cf6bf3704b24515", null ]
];