var structpw__endpoint__methods =
[
    [ "version", "structpw__endpoint__methods.html#a06713ce8a9d182272a9552da9d0c229f", null ],
    [ "add_listener", "structpw__endpoint__methods.html#a57ed4ba10caacf4575e7a7644d17f5e2", null ],
    [ "subscribe_params", "structpw__endpoint__methods.html#a6bc6ff48ccd0c3c56d24c00017c9a20b", null ],
    [ "enum_params", "structpw__endpoint__methods.html#af6edf84d00162a4ad7a25d417be5358b", null ],
    [ "set_param", "structpw__endpoint__methods.html#ab78e5de3c1ca35dfcb09881d58f46ba2", null ],
    [ "create_link", "structpw__endpoint__methods.html#a981eeb169f40ac34ad5c348572a3eb95", null ]
];