var structpw__stream__events =
[
    [ "version", "structpw__stream__events.html#a74aaca4c31e44dad69aba50607055419", null ],
    [ "destroy", "structpw__stream__events.html#abbe98bb0d78e6411d08244495f349b0b", null ],
    [ "state_changed", "structpw__stream__events.html#a89192aed5fcd89314bf7cc7ef6b21085", null ],
    [ "control_info", "structpw__stream__events.html#a12fa5918ff2c41cc41d5bf8ae36b3ca3", null ],
    [ "io_changed", "structpw__stream__events.html#ad60b819ff0ea17b0bd8833220cbd4a3e", null ],
    [ "param_changed", "structpw__stream__events.html#a4d1ed03aa78fb2c8324ae13bc45731e3", null ],
    [ "add_buffer", "structpw__stream__events.html#abd09d7c76b0e14a201a438f09e609b29", null ],
    [ "remove_buffer", "structpw__stream__events.html#a0cdc45fef5f2458a0fd11a6e9ef1f6fb", null ],
    [ "process", "structpw__stream__events.html#a512bd219ce44ba1a688d600773efe84b", null ],
    [ "drained", "structpw__stream__events.html#aab4b9831ef563920b401b1f9daf93042", null ],
    [ "command", "structpw__stream__events.html#a66e43e35eb2be261520cda8a4e24098c", null ],
    [ "trigger_done", "structpw__stream__events.html#a1de8432b45484bc0e060162b78720c02", null ]
];