var structpw__module__methods =
[
    [ "version", "structpw__module__methods.html#ac20cd689bc54dcab9452e65c58fc5da3", null ],
    [ "add_listener", "structpw__module__methods.html#ace8dfde4c073903664ba703b575f6e01", null ]
];