var structspa__plugin__loader__methods =
[
    [ "version", "structspa__plugin__loader__methods.html#ae2de2d15c28cf425552bb3aa6ca0bad4", null ],
    [ "load", "structspa__plugin__loader__methods.html#ac03d77f832ee680b4a1b68acdbcc05d4", null ],
    [ "unload", "structspa__plugin__loader__methods.html#aa91d4ff3f01f2d7c38a066b3d8bc98ca", null ]
];