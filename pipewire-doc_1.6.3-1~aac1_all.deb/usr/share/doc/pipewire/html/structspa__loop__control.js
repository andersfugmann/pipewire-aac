var structspa__loop__control =
[
    [ "iface", "structspa__loop__control.html#a392f811fbacb15de863fc0265031050f", null ]
];