var structspa__audio__info__eac3 =
[
    [ "rate", "structspa__audio__info__eac3.html#a740b8ce1f9dc936f54ac972e185f91dc", null ],
    [ "channels", "structspa__audio__info__eac3.html#a2eac3bfcd209cead7b8a3c81e23b3952", null ]
];