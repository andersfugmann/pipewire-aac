var structpw__port__info =
[
    [ "id", "structpw__port__info.html#ab8bd7cf30a25d379e02bfc66c5692c64", null ],
    [ "direction", "structpw__port__info.html#ae58ded9d9277c0f93862d58026faf4e2", null ],
    [ "change_mask", "structpw__port__info.html#a59e2afe4f65b5f74eb7a28f51fb958aa", null ],
    [ "params", "structpw__port__info.html#a5131d23e86aef3c0d1727a6aa6359e9c", null ],
    [ "n_params", "structpw__port__info.html#a3c95bbed7080e2f033b133409315f31a", null ]
];