var structspa__dll =
[
    [ "bw", "structspa__dll.html#ac3de731c327763f69c44e98224ee1068", null ],
    [ "z1", "structspa__dll.html#a7b2d7a0adb6cdc3680db685fef886d78", null ],
    [ "z2", "structspa__dll.html#a6e71bca8352ac6213b6d26c22732c9a1", null ],
    [ "z3", "structspa__dll.html#aa109171408f82fa3f287b70e2396ba42", null ],
    [ "w0", "structspa__dll.html#aa99d781b6e4c1133db7bef843fc4a21a", null ],
    [ "w1", "structspa__dll.html#ae1e3a33d3f38548692173d283b613574", null ],
    [ "w2", "structspa__dll.html#a90a86177cee5a8c972d4a2825244d3de", null ]
];