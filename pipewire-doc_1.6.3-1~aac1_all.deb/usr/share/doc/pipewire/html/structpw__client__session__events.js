var structpw__client__session__events =
[
    [ "version", "structpw__client__session__events.html#a6005c505de498fbaaaed2dd87918773f", null ],
    [ "set_param", "structpw__client__session__events.html#a8e823bcde1844c0857314b10069f3b8d", null ],
    [ "link_set_param", "structpw__client__session__events.html#af3eab807465363845550f89f1bb9d816", null ],
    [ "link_request_state", "structpw__client__session__events.html#aae0dc344c9b1d62b21fb16e4fc2c9c33", null ]
];