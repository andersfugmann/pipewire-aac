var structpw__profiler__events =
[
    [ "version", "structpw__profiler__events.html#a00e0a36b711bd01ce994d368e0e39629", null ],
    [ "profile", "structpw__profiler__events.html#ab4f32595bfcc74f3c77ccc9cb0bb2acb", null ]
];