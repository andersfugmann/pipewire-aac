var group__spa__graph =
[
    [ "graph.h", "graph_8h.html", null ],
    [ "spa_graph_state", "structspa__graph__state.html", [
      [ "status", "structspa__graph__state.html#ade14580f5dc43afc10b857d4233d3f99", null ],
      [ "required", "structspa__graph__state.html#a98a2cfe5aa419430cefaf19e3836ce40", null ],
      [ "pending", "structspa__graph__state.html#a8f3cf9778a95b2717a5a6ac0d5b55bb9", null ]
    ] ],
    [ "spa_graph_link", "structspa__graph__link.html", [
      [ "link", "structspa__graph__link.html#ab1f910424f6a5ea5a34b52695536f53d", null ],
      [ "state", "structspa__graph__link.html#a15313bfb8509b74448784ebf30f191c6", null ],
      [ "signal", "structspa__graph__link.html#ab7c807f9aaa9242cf8573b13212de674", null ],
      [ "signal_data", "structspa__graph__link.html#abf9a5059f5b888cf3a331832830f7373", null ]
    ] ],
    [ "spa_graph", "structspa__graph.html", [
      [ "flags", "structspa__graph.html#a850c90822a1b32d7cd67ec5c76eda2fa", null ],
      [ "parent", "structspa__graph.html#a9bcd83554b53da4a139ed6a9be38bb1c", null ],
      [ "state", "structspa__graph.html#aacd6dde80b95c6415d300f419ea6f144", null ],
      [ "nodes", "structspa__graph.html#a90439529765f13aadc6f1d7727244a1c", null ]
    ] ],
    [ "spa_graph_node_callbacks", "structspa__graph__node__callbacks.html", [
      [ "version", "structspa__graph__node__callbacks.html#acbbdda8c4d517ce24ee12cad1c4e60ec", null ],
      [ "process", "structspa__graph__node__callbacks.html#a9c7b2744d4983173d88469654e626375", null ],
      [ "reuse_buffer", "structspa__graph__node__callbacks.html#abc2bcb2b88b65f3eabe0e13d5d73f4e8", null ]
    ] ],
    [ "spa_graph_node", "structspa__graph__node.html", [
      [ "link", "structspa__graph__node.html#a6215edd0d426cfc8e697d648c09a4f57", null ],
      [ "graph", "structspa__graph__node.html#a7a4bea046f4d6a88d97e12a5297ed740", null ],
      [ "ports", "structspa__graph__node.html#aec1169015c1d7a4aaea10d5f4946f7d4", null ],
      [ "links", "structspa__graph__node.html#acfb4e7658140701927336dee05ed1948", null ],
      [ "flags", "structspa__graph__node.html#a23c316f71a255a568e96092e72c40cae", null ],
      [ "state", "structspa__graph__node.html#ada29bc9109cd890c74cfba630989b76c", null ],
      [ "graph_link", "structspa__graph__node.html#acbee04440eefb9b0a77f69ff1876dbc0", null ],
      [ "subgraph", "structspa__graph__node.html#ab16592a35d02f827271786b49110341c", null ],
      [ "callbacks", "structspa__graph__node.html#a6664b3c60baddc151a340bf2ebb3a5a2", null ],
      [ "sched_link", "structspa__graph__node.html#af4ae9586aa3d544a48414987f1839a67", null ]
    ] ],
    [ "spa_graph_port", "structspa__graph__port.html", [
      [ "link", "structspa__graph__port.html#af25d08a94327c7642abd9d22c1f00dee", null ],
      [ "node", "structspa__graph__port.html#a2010d31b7d56fef0f5a8eeb4188e7ff6", null ],
      [ "direction", "structspa__graph__port.html#ac60bcc3482ad354bc5ae32d3cade3a02", null ],
      [ "port_id", "structspa__graph__port.html#a6a077a5cc2c1115b43d05208bb072208", null ],
      [ "flags", "structspa__graph__port.html#a8ee1612c0aaef539c9270761f3d6d8b6", null ],
      [ "peer", "structspa__graph__port.html#a7139cc16698356c2fc915149d45a741f", null ]
    ] ],
    [ "SPA_API_GRAPH", "group__spa__graph.html#ga28e6d326ef26650fec4955704818ec93", null ],
    [ "spa_debug", "group__spa__graph.html#ga85dfce75df6a24fc0a29945ab03b1c86", null ],
    [ "spa_graph_link_signal", "group__spa__graph.html#ga35411dc23f99354fb70e3c298426da7a", null ],
    [ "spa_graph_state_dec", "group__spa__graph.html#gaf4ffa38ece7913a1eb5f4e6a65275122", null ],
    [ "SPA_VERSION_GRAPH_NODE_CALLBACKS", "group__spa__graph.html#gaf3a2fc5db0af85206c694318944beef2", null ],
    [ "spa_graph_node_call", "group__spa__graph.html#gaad5ba578c8601c9239c455b0dc2c68c7", null ],
    [ "spa_graph_node_process", "group__spa__graph.html#gad5dde6d83fc7914aefe2b4840f2bea76", null ],
    [ "spa_graph_node_reuse_buffer", "group__spa__graph.html#ga46a58a570be342df082e1fb35878ac6f", null ],
    [ "spa_graph_state_reset", "group__spa__graph.html#ga09452de18e664f27c4733f1f67680fa6", null ],
    [ "spa_graph_link_trigger", "group__spa__graph.html#ga827fee5fb44767b0729dc7be956b4e27", null ],
    [ "spa_graph_node_trigger", "group__spa__graph.html#ga39dfce9fe8e309c3b5202c7d90672a2b", null ],
    [ "spa_graph_run", "group__spa__graph.html#gac4ec2972c3a8d92d98a43720a91f8efe", null ],
    [ "spa_graph_finish", "group__spa__graph.html#ga3c0b6e1dadecc78c4444f99a083a1f12", null ],
    [ "spa_graph_link_signal_node", "group__spa__graph.html#gaea33bdd44717bbacac85b105f49648c7", null ],
    [ "spa_graph_link_signal_graph", "group__spa__graph.html#gafd92052eb9b98b9a8e436dd1e1b95a51", null ],
    [ "spa_graph_init", "group__spa__graph.html#gaec6571fdd89b64234df5ad91d71b1b65", null ],
    [ "spa_graph_link_add", "group__spa__graph.html#gadb6df1a6a81fb8d1d821f29fbca4eda3", null ],
    [ "spa_graph_link_remove", "group__spa__graph.html#ga021ade562de6b533a758c9e82fd53538", null ],
    [ "spa_graph_node_init", "group__spa__graph.html#ga359fe4a4cffdb3da21811ee100c66501", null ],
    [ "spa_graph_node_impl_sub_process", "group__spa__graph.html#gaffb4bddf83d38fecb62b4358809765e0", null ],
    [ "spa_graph_node_set_subgraph", "group__spa__graph.html#ga82592f0caa91672bc768692590b6b050", null ],
    [ "spa_graph_node_set_callbacks", "group__spa__graph.html#gae9a03dad722b21c22d21209cc7ec91c7", null ],
    [ "spa_graph_node_add", "group__spa__graph.html#ga6c46c4c96985b75eea2e864d43b8660f", null ],
    [ "spa_graph_node_remove", "group__spa__graph.html#ga1eb6e4ddde706ff6d11efef4c8009b40", null ],
    [ "spa_graph_port_init", "group__spa__graph.html#ga0f3e769cbbeab1535811eadec2f5cb25", null ],
    [ "spa_graph_port_add", "group__spa__graph.html#gaac61ca2f8b7f1dcea4680df5b1a497fb", null ],
    [ "spa_graph_port_remove", "group__spa__graph.html#ga5638b2a42e27b393a86bdbf0ce82d436", null ],
    [ "spa_graph_port_link", "group__spa__graph.html#gaaa058b8c9e7c3a9429b3e0b455ec1f73", null ],
    [ "spa_graph_port_unlink", "group__spa__graph.html#ga50c5733136f81a88bc0a395bcfad90a0", null ],
    [ "spa_graph_node_impl_process", "group__spa__graph.html#ga48bb4629af6271a3f14ef63d045117bf", null ],
    [ "spa_graph_node_impl_reuse_buffer", "group__spa__graph.html#ga56e40d23e197a78ea528e5d87ca83b4f", null ],
    [ "spa_graph_node_sub_impl_default", "group__spa__graph.html#ga6d547c1c911a17ff700908d2cbd97d29", null ],
    [ "spa_graph_node_impl_default", "group__spa__graph.html#ga1c81532d49873312268b69610b6ff2bd", null ]
];