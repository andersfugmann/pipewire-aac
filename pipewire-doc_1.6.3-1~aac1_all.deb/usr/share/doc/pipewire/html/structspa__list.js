var structspa__list =
[
    [ "next", "structspa__list.html#aed4aa24d6a3d4f62a4198296312a6196", null ],
    [ "prev", "structspa__list.html#ab67df98c96319f199a02cb48ee7de93e", null ]
];