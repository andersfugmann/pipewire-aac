var structspa__io__segment =
[
    [ "version", "structspa__io__segment.html#af9ec3a1565e77b1ad781376b758b58c3", null ],
    [ "flags", "structspa__io__segment.html#a6ba7bf8b5ba9725546b59b1918f49cc7", null ],
    [ "duration", "structspa__io__segment.html#a6b7f7b35362210bbb0548ce4ab463e12", null ],
    [ "rate", "structspa__io__segment.html#ab725d4cd7f8cb1a44abe185ac504fd1c", null ],
    [ "position", "structspa__io__segment.html#aa0c906a4de1d90ec5042826b14742301", null ],
    [ "bar", "structspa__io__segment.html#ad525d9a6f0185e329abc7e89fe394cfd", null ],
    [ "video", "structspa__io__segment.html#ac4988f1d377a80a859eb45771f3317fb", null ]
];