var structspa__latency__info =
[
    [ "direction", "structspa__latency__info.html#a9b3d5d2e366d8081d91adcf736b15c48", null ],
    [ "min_quantum", "structspa__latency__info.html#aadaa9a123ffe5f4a050945e210cc5725", null ],
    [ "max_quantum", "structspa__latency__info.html#aab5617769d3799f99a80747917268db8", null ],
    [ "min_rate", "structspa__latency__info.html#a04589efd15d0106f14fc7cd93d938145", null ],
    [ "max_rate", "structspa__latency__info.html#a9241f63614bcb363ad375b6fb07d251e", null ],
    [ "min_ns", "structspa__latency__info.html#a203b83cfc08a9e968691577fd1dce326", null ],
    [ "max_ns", "structspa__latency__info.html#ad483ad02d7fa54b3069970ab7a636fd5", null ]
];