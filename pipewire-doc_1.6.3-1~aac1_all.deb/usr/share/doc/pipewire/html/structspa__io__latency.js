var structspa__io__latency =
[
    [ "rate", "structspa__io__latency.html#aebb31ddb5622017843ee612c7c66f32a", null ],
    [ "min", "structspa__io__latency.html#a017f13089f0f6847cd70e62d725bd99c", null ],
    [ "max", "structspa__io__latency.html#a5f23744c90a1dc0e9f0c1e067b8d390a", null ]
];