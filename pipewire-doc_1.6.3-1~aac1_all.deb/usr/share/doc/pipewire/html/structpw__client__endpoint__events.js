var structpw__client__endpoint__events =
[
    [ "version", "structpw__client__endpoint__events.html#afab781a09b218afdc2c9ffb54502be5e", null ],
    [ "set_session_id", "structpw__client__endpoint__events.html#a12f427748eebbfd39cdc4f75a9db57ed", null ],
    [ "set_param", "structpw__client__endpoint__events.html#a45e7bb70eb2b24c33aad0c82dcf001b6", null ],
    [ "stream_set_param", "structpw__client__endpoint__events.html#a43e06e14ba4461922bfce4c3c98c13f1", null ],
    [ "create_link", "structpw__client__endpoint__events.html#a02d8f4d9cd9f898d3109a64f7afd81e1", null ]
];