var page_tutorial =
[
    [ "Tutorial - Part 1: Getting Started", "page_tutorial1.html", null ],
    [ "Tutorial - Part 2: Enumerating Objects", "page_tutorial2.html", null ],
    [ "Tutorial - Part 3: Forcing A Roundtrip", "page_tutorial3.html", null ],
    [ "Tutorial - Part 4: Playing A Tone", "page_tutorial4.html", null ],
    [ "Tutorial - Part 5: Capturing Video Frames", "page_tutorial5.html", null ],
    [ "Tutorial - Part 6: Binding Objects", "page_tutorial6.html", null ],
    [ "Tutorial - Part 7: Creating an Audio DSP Filter", "page_tutorial7.html", null ],
    [ "List of example programs", "page_examples.html", null ]
];