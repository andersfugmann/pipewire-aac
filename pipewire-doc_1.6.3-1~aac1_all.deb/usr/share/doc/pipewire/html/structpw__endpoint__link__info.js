var structpw__endpoint__link__info =
[
    [ "version", "structpw__endpoint__link__info.html#aaae0e9204b82b599f01bfcafe7573103", null ],
    [ "id", "structpw__endpoint__link__info.html#a07c6bf548b8e042c2812543981a51598", null ],
    [ "session_id", "structpw__endpoint__link__info.html#af223a0fa8116ac65191724bd0feb0a74", null ],
    [ "output_endpoint_id", "structpw__endpoint__link__info.html#a1d398555b2824d65fda91cfd3258a813", null ],
    [ "output_stream_id", "structpw__endpoint__link__info.html#aea0b70e668d2c6c0dbec40bfc6b6ff62", null ],
    [ "input_endpoint_id", "structpw__endpoint__link__info.html#a460974a8c40082a75b90d5d151e93ca7", null ],
    [ "input_stream_id", "structpw__endpoint__link__info.html#aea87c1744850124ef9bc31d92af578f1", null ],
    [ "change_mask", "structpw__endpoint__link__info.html#a0c23a32dc6e567f7cf483a20c988feb3", null ],
    [ "state", "structpw__endpoint__link__info.html#abe1a77c360812808ac34d2ab016f6bd7", null ],
    [ "error", "structpw__endpoint__link__info.html#a7effc16feab6bfc6322e96d90ebea27d", null ],
    [ "params", "structpw__endpoint__link__info.html#abbca6b1e2d0509bea65aff817962e0e7", null ],
    [ "n_params", "structpw__endpoint__link__info.html#ae0c6caf742470e3133cd0de7a7e642a9", null ]
];