var structpw__registry__methods =
[
    [ "version", "structpw__registry__methods.html#a82488a74c02c5b764b0764b0d3e42fac", null ],
    [ "add_listener", "structpw__registry__methods.html#a91a13e6dbf685af929ced294d5816089", null ],
    [ "bind", "structpw__registry__methods.html#a743174c4df93282f1361f137383cb41a", null ],
    [ "destroy", "structpw__registry__methods.html#afe6865901f9bc87f009674959d12e60c", null ]
];