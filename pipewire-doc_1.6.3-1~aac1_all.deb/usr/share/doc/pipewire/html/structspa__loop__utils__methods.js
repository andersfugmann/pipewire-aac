var structspa__loop__utils__methods =
[
    [ "version", "structspa__loop__utils__methods.html#aefb69d2a6ad30b352b4414401a55f3e7", null ],
    [ "add_io", "structspa__loop__utils__methods.html#adc8b3b97121c94a824307117dad02989", null ],
    [ "update_io", "structspa__loop__utils__methods.html#a166d2e9aab23ce96b9d7795c3466fc6b", null ],
    [ "add_idle", "structspa__loop__utils__methods.html#a79ae6123ff0f20029d4e722053b49a11", null ],
    [ "enable_idle", "structspa__loop__utils__methods.html#a4466703d3ee6e18abc89bafea2b0c0ed", null ],
    [ "add_event", "structspa__loop__utils__methods.html#aea2ab7bb653eef26373295fafbe048fc", null ],
    [ "signal_event", "structspa__loop__utils__methods.html#aa30b5933fcadb8606772d95471ec7a05", null ],
    [ "add_timer", "structspa__loop__utils__methods.html#ab24aa861875574691b833aaaf356a2ad", null ],
    [ "update_timer", "structspa__loop__utils__methods.html#abc9a0d7bb777e2c892343b1ca5a6d37d", null ],
    [ "add_signal", "structspa__loop__utils__methods.html#af9604ab5944fce7539516ff227ddc2f9", null ],
    [ "destroy_source", "structspa__loop__utils__methods.html#acb650a30486b87fcab5859afd000d913", null ]
];