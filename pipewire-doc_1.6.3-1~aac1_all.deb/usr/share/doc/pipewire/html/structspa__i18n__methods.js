var structspa__i18n__methods =
[
    [ "version", "structspa__i18n__methods.html#a3aa971d572e886ab027a897a288f767b", null ],
    [ "text", "structspa__i18n__methods.html#a7ceb5c3a7165fbfb3ee340574881d675", null ],
    [ "ntext", "structspa__i18n__methods.html#a884391486c3277069fb8ee2f9d754234", null ]
];