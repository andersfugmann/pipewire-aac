var structpw__impl__client__events =
[
    [ "version", "structpw__impl__client__events.html#a30be6d32c40038f0ae9dfdbccdf74e1b", null ],
    [ "destroy", "structpw__impl__client__events.html#a7aee6a7b912b1a37032a3a6a156def9d", null ],
    [ "free", "structpw__impl__client__events.html#a7cc746f92f5d5b8aacf5d9cd278ea575", null ],
    [ "initialized", "structpw__impl__client__events.html#a3e42dd29cba77e524cf6328d006e2b9e", null ],
    [ "info_changed", "structpw__impl__client__events.html#a64120718bec833fc87ca30ff85e01645", null ],
    [ "resource_added", "structpw__impl__client__events.html#a59d0c58fc080957b72648c77155782a1", null ],
    [ "resource_removed", "structpw__impl__client__events.html#aafead0de7de83f2b9f4d0a84c9c9dbd3", null ],
    [ "busy_changed", "structpw__impl__client__events.html#a046e956441b5395308c8ff140292dfee", null ]
];