var structspa__fraction =
[
    [ "num", "structspa__fraction.html#a55246db96d647cd96be18983d59feb56", null ],
    [ "denom", "structspa__fraction.html#af099fb3a18c93ddac10239564da9de0c", null ]
];