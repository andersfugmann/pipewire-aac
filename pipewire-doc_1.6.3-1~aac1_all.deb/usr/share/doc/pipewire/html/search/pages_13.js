var searchData=
[
  ['native_0',['Protocol Native',['../page_module_protocol_native.html',1,'page_modules']]],
  ['native_20protocol_1',['Native Protocol',['../page_native_protocol.html',1,'page_internals']]],
  ['negotiation_2',['negotiation',['../page_streams.html#sec_buffers',1,'Buffer negotiation'],['../page_streams.html#sec_format',1,'Format negotiation']]],
  ['netjack2_20driver_3',['Netjack2 driver',['../page_module_netjack2_driver.html',1,'page_modules']]],
  ['netjack2_20manager_4',['Netjack2 manager',['../page_module_netjack2_manager.html',1,'page_modules']]],
  ['node_5',['Node',['../page_module_client_node.html',1,'Client Node'],['../page_module_spa_node.html',1,'SPA Node']]],
  ['node_20factory_6',['SPA Node factory',['../page_module_spa_node_factory.html',1,'page_modules']]],
  ['node_20properties_7',['COMMON NODE PROPERTIES',['../page_man_pipewire-props_7.html#props__common_node_properties',1,'']]],
  ['node_20rules_8',['NODE RULES',['../page_man_pipewire_conf_5.html#pipewire_conf__node_rules',1,'']]],
  ['null_20sink_9',['Null Sink',['../page_pulse_module_null_sink.html',1,'page_pulse_modules']]]
];
