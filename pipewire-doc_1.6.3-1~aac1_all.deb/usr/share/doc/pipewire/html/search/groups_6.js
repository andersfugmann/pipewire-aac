var searchData=
[
  ['global_0',['Global',['../group__pw__global.html',1,'']]],
  ['graph_1',['Graph',['../group__spa__filter__graph.html',1,'Filter Graph'],['../group__spa__graph.html',1,'Graph']]]
];
