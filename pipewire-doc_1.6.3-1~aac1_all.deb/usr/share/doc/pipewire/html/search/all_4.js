var searchData=
[
  ['5_3a_20capturing_20video_20frames_0',['Tutorial - Part 5: Capturing Video Frames',['../page_tutorial5.html',1,'page_tutorial']]]
];
