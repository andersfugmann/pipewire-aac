var searchData=
[
  ['identifying_20properties_0',['Identifying Properties',['../page_man_pipewire-props_7.html#props__identifying_properties',1,'']]],
  ['implementation_1',['Client Implementation',['../page_client_impl.html',1,'page_api']]],
  ['in_20configuration_20files_2',['DROP-IN CONFIGURATION FILES',['../page_man_pipewire_conf_5.html#pipewire_conf__drop-in_configuration_files',1,'']]],
  ['index_3',['INDEX',['../page_man_pipewire-props_7.html#pipewire-props__index',1,'']]],
  ['index_4',['Index',['../page_config_xref.html',1,'page_config']]],
  ['information_5',['Obtaining timing information',['../page_streams.html#sec_stream_timing',1,'']]],
  ['input_6',['ROC Sink Input',['../page_pulse_module_roc_sink_input.html',1,'page_pulse_modules']]],
  ['inspect_7',['spa-inspect',['../page_man_spa-inspect_1.html',1,'page_programs']]],
  ['internals_8',['Internals',['../page_internals.html',1,'']]]
];
