var searchData=
[
  ['x_0',['x',['../structspa__point.html#ad0e2590c913f99dd1bd9f18aecffc951',1,'spa_point']]],
  ['xrun_1',['xrun',['../structpw__impl__node__rt__events.html#a2f04aea57fc1da2b792d4925e7fd2918',1,'pw_impl_node_rt_events::xrun'],['../structspa__io__clock.html#a3dc77892eea443b66c01d2acc91acaeb',1,'spa_io_clock::xrun'],['../structspa__node__callbacks.html#a597eb6e41252d8030e4d697b51406ad0',1,'spa_node_callbacks::xrun']]]
];
