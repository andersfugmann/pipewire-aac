var searchData=
[
  ['echo_20cancel_0',['Echo Cancel',['../page_module_echo_cancel.html',1,'Echo Cancel'],['../page_pulse_module_echo_cancel.html',1,'Echo Cancel']]],
  ['enumerating_20objects_1',['Tutorial - Part 2: Enumerating Objects',['../page_tutorial2.html',1,'page_tutorial']]],
  ['environment_20variables_2',['ENVIRONMENT VARIABLES',['../page_man_pipewire-client_conf_5.html#client-env__environment_variables',1,'ENVIRONMENT VARIABLES'],['../page_man_pipewire-jack_conf_5.html#jack-env__environment_variables',1,'ENVIRONMENT VARIABLES'],['../page_man_pipewire_1.html#pipewire-env__environment_variables',1,'ENVIRONMENT VARIABLES']]],
  ['environment_20variables_3',['Environment Variables',['../page_streams.html#sec_stream_environment',1,'']]],
  ['equalizer_4',['Parametric-Equalizer',['../page_module_parametric_equalizer.html',1,'page_modules']]],
  ['events_5',['Events',['../page_proxy.html#sec_page_proxy_events',1,'']]],
  ['events_20and_20callbacks_6',['Events and Callbacks',['../page_thread_loop.html#sec_thread_loop_events',1,'']]],
  ['example_20filter_7',['Example Filter',['../page_module_example_filter.html',1,'page_modules']]],
  ['example_20programs_8',['List of example programs',['../page_examples.html',1,'page_tutorial']]],
  ['example_20sink_9',['Example Sink',['../page_module_example_sink.html',1,'page_modules']]],
  ['example_20source_10',['Example Source',['../page_module_example_source.html',1,'page_modules']]],
  ['execution_11',['COMMAND EXECUTION',['../page_man_pipewire_conf_5.html#pipewire_conf__command_execution',1,'']]],
  ['extension_12',['extension',['../page_pulse_module_device_manager.html',1,'Device manager extension'],['../page_pulse_module_device_restore.html',1,'Device restore extension'],['../page_pulse_module_stream_restore.html',1,'Stream restore extension']]]
];
