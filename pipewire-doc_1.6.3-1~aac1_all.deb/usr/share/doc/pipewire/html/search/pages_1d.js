var searchData=
[
  ['zeroconf_20discover_0',['Zeroconf Discover',['../page_module_zeroconf_discover.html',1,'Zeroconf Discover'],['../page_pulse_module_zeroconf_discover.html',1,'Zeroconf Discover']]],
  ['zeroconf_20publish_1',['Zeroconf Publish',['../page_pulse_module_zeroconf_publish.html',1,'page_pulse_modules']]]
];
