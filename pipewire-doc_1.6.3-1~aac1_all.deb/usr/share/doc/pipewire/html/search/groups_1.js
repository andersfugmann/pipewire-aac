var searchData=
[
  ['blocks_0',['Memory Blocks',['../group__pw__memblock.html',1,'']]],
  ['buffers_1',['Buffers',['../group__pw__buffers.html',1,'Buffers'],['../group__spa__buffer.html',1,'Buffers']]]
];
