var searchData=
[
  ['header_0',['Message header',['../page_native_protocol.html#native-protocol-message-header',1,'']]]
];
