var searchData=
[
  ['factory_0',['Factory',['../group__pw__factory.html',1,'']]],
  ['factory_20impl_1',['Factory Impl',['../group__pw__impl__factory.html',1,'']]],
  ['factory_20names_2',['Factory Names',['../group__spa__names.html',1,'']]],
  ['filter_3',['Filter',['../group__pw__filter.html',1,'']]],
  ['filter_20graph_4',['Filter Graph',['../group__spa__filter__graph.html',1,'']]]
];
