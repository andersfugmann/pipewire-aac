var searchData=
[
  ['object_20types_0',['OTHER OBJECT TYPES',['../page_man_pipewire-props_7.html#props__other_object_types',1,'']]],
  ['object_5finfo_1',['object_info',['../structspa__device__events.html#a830fadb39e2a8658f9b4cb663619cf4b',1,'spa_device_events']]],
  ['objects_2',['CONTEXT OBJECTS',['../page_man_pipewire_conf_5.html#pipewire_conf__context_objects',1,'']]],
  ['objects_3',['Objects',['../page_tutorial2.html',1,'Tutorial - Part 2: Enumerating Objects'],['../page_tutorial6.html',1,'Tutorial - Part 6: Binding Objects']]],
  ['objects_20design_4',['Objects Design',['../page_objects_design.html',1,'page_internals']]],
  ['obtaining_20timing_20information_5',['Obtaining timing information',['../page_streams.html#sec_stream_timing',1,'']]],
  ['of_20example_20programs_6',['List of example programs',['../page_examples.html',1,'page_tutorial']]],
  ['offset_7',['offset',['../structpw__memmap.html#a2a254ea08d19704537d73b68ef548a12',1,'pw_memmap::offset'],['../structpw__map__range.html#aaf1ff0e5b8623a1c64ee4ac9dbf2008a',1,'pw_map_range::offset'],['../structpw__client__node__buffer.html#a1d524a38ed82fb88371d741bcb1e3ff0',1,'pw_client_node_buffer::offset'],['../structspa__chunk.html#ae7a889b81a5d56ff5babd521b5ce7cb7',1,'spa_chunk::offset'],['../structspa__meta__header.html#a1410208fd9ccdd153418f01d5ce12d7b',1,'spa_meta_header::offset'],['../structspa__meta__bitmap.html#abaac271d52c056bf717f25698e9690bd',1,'spa_meta_bitmap::offset'],['../structspa__io__range.html#a2a824a298a2e459bb719ed29f57de141',1,'spa_io_range::offset'],['../structspa__io__segment__bar.html#ad6d079e00b9b7428ab66c7f7fc5e0a5e',1,'spa_io_segment_bar::offset'],['../structspa__io__segment__video.html#aefffdac704f6aa878542c37d5cc7accb',1,'spa_io_segment_video::offset'],['../structspa__io__position.html#afa5a197f2a03c7b71ed7d99bcd3a3718',1,'spa_io_position::offset'],['../structspa__pod__frame.html#a3af1eba573563e63ed9d5fa9b3246795',1,'spa_pod_frame::offset'],['../structspa__pod__builder__state.html#ac64c9a0aad0f5630c44c86e97561ffae',1,'spa_pod_builder_state::offset'],['../structspa__pod__parser__state.html#a7d20db21de9472df961d8b2da5845ea0',1,'spa_pod_parser_state::offset'],['../structspa__pod__control.html#ae2a97b90cef2051c5bc8fa6db940179d',1,'spa_pod_control::offset']]],
  ['on_20connect_8',['Switch on Connect',['../page_pulse_module_switch_on_connect.html',1,'page_pulse_modules']]],
  ['opcode_9',['opcode',['../structpw__protocol__native__message.html#aef6ddaa16aeaa35b4276e3b2767268aa',1,'pw_protocol_native_message']]],
  ['opus_10',['opus',['../structspa__audio__info.html#a880d36c25907b88e7ca3dc34d200c343',1,'spa_audio_info']]],
  ['opus_2eh_11',['opus.h',['../opus_8h.html',1,'']]],
  ['other_20object_20types_12',['OTHER OBJECT TYPES',['../page_man_pipewire-props_7.html#props__other_object_types',1,'']]],
  ['output_5fendpoint_5fid_13',['output_endpoint_id',['../structpw__endpoint__link__info.html#a1d398555b2824d65fda91cfd3258a813',1,'pw_endpoint_link_info']]],
  ['output_5fnode_5fid_14',['output_node_id',['../structpw__link__info.html#a5a21130d91e20dafc4ce1b09b7c30aca',1,'pw_link_info']]],
  ['output_5fport_5fid_15',['output_port_id',['../structpw__link__info.html#a0513f644f43b252a0e068e09c8452382',1,'pw_link_info']]],
  ['output_5fstream_5fid_16',['output_stream_id',['../structpw__endpoint__link__info.html#aea0b70e668d2c6c0dbec40bfc6b6ff62',1,'pw_endpoint_link_info']]],
  ['overflow_17',['overflow',['../structspa__pod__builder__callbacks.html#a8acfb9e8c57e0c3ac2d3dac4a4f37aa6',1,'spa_pod_builder_callbacks']]],
  ['overview_18',['Overview',['../page_overview.html',1,'Overview'],['../page_client_impl.html#sec_page_client_impl_overview',1,'Overview'],['../page_proxy.html#sec_page_proxy_overview',1,'Overview'],['../page_streams.html#sec_overview',1,'Overview'],['../page_thread_loop.html#sec_thread_loop_overview',1,'Overview']]]
];
