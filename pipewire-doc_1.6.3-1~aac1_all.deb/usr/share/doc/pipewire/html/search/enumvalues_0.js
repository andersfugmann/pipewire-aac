var searchData=
[
  ['_5fspa_5fcontrol_5flast_0',['_SPA_CONTROL_LAST',['../group__spa__control.html#gga9780c9a5192589544170788a97f20b82a6d60da01306a62b9def5922f36870b6d',1,'control.h']]],
  ['_5fspa_5fdata_5flast_1',['_SPA_DATA_LAST',['../group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bda156b1c773c0fd4ce6f735e4e9bea25b7',1,'buffer.h']]],
  ['_5fspa_5fmeta_5flast_2',['_SPA_META_LAST',['../group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05aefff8a3623d2416a427dafe4861ae5c3',1,'meta.h']]],
  ['_5fspa_5ftype_5fcommand_5flast_3',['_SPA_TYPE_COMMAND_LAST',['../group__spa__types.html#gga73b196216e009c2bf3cb0c632154839dad9368eac91f702bab0607906ccaca2b7',1,'type.h']]],
  ['_5fspa_5ftype_5fevent_5flast_4',['_SPA_TYPE_EVENT_LAST',['../group__spa__types.html#gga73b196216e009c2bf3cb0c632154839dab86413edcf3bc9ba4454e49c451d5c9e',1,'type.h']]],
  ['_5fspa_5ftype_5flast_5',['_SPA_TYPE_LAST',['../group__spa__types.html#gga73b196216e009c2bf3cb0c632154839da74f4d538e5505aed6fc795ce42b428cd',1,'type.h']]],
  ['_5fspa_5ftype_5fobject_5flast_6',['_SPA_TYPE_OBJECT_LAST',['../group__spa__types.html#gga73b196216e009c2bf3cb0c632154839dab0d0e30c07c9d934c96bc2210183537b',1,'type.h']]],
  ['_5fspa_5ftype_5fpointer_5flast_7',['_SPA_TYPE_POINTER_LAST',['../group__spa__types.html#gga73b196216e009c2bf3cb0c632154839daf64dcbfbabdf6f2529ab10eee233a25f',1,'type.h']]]
];
