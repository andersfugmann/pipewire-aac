var searchData=
[
  ['making_20a_20connection_0',['Making a connection',['../page_native_protocol.html#native-protocol-making-connection',1,'']]],
  ['manager_1',['Manager',['../page_session_manager.html',1,'PipeWire Session Manager'],['../page_module_session_manager.html',1,'Session Manager']]],
  ['manager_2',['Netjack2 manager',['../page_module_netjack2_manager.html',1,'page_modules']]],
  ['manager_20extension_3',['Device manager extension',['../page_pulse_module_device_manager.html',1,'page_pulse_modules']]],
  ['manager_20properties_4',['Session Manager Properties',['../page_man_pipewire-props_7.html#props__session_manager_properties',1,'']]],
  ['match_20rules_5',['MATCH RULES',['../page_man_pipewire_conf_5.html#pipewire_conf__match_rules',1,'MATCH RULES'],['../page_man_pipewire-jack_conf_5.html#jack_conf__match_rules',1,'MATCH RULES']]],
  ['message_20header_6',['Message header',['../page_native_protocol.html#native-protocol-message-header',1,'']]],
  ['metadata_7',['Metadata',['../page_module_metadata.html',1,'page_modules']]],
  ['metadata_8',['pw-metadata',['../page_man_pw-metadata_1.html',1,'page_programs']]],
  ['methods_9',['Methods',['../page_proxy.html#sec_page_proxy_methods',1,'']]],
  ['midi_20properties_10',['ALSA MIDI PROPERTIES',['../page_man_pipewire-props_7.html#props__alsa_midi_properties',1,'']]],
  ['midi_20support_11',['MIDI Support',['../page_midi.html',1,'page_internals']]],
  ['mididump_12',['pw-mididump',['../page_man_pw-mididump_1.html',1,'page_programs']]],
  ['modules_13',['MODULES',['../page_man_pipewire_conf_5.html#pipewire_conf__modules',1,'MODULES'],['../page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__pulseaudio_modules',1,'PULSEAUDIO MODULES']]],
  ['modules_14',['Modules',['../page_modules.html',1,'Modules'],['../page_pulse_modules.html',1,'Pulseaudio Modules']]],
  ['modules_15',['modules',['../page_man_libpipewire-modules_7.html',1,'libpipewire-modules'],['../page_man_pipewire-pulse-modules_7.html',1,'pipewire-pulse-modules']]],
  ['mon_16',['pw-mon',['../page_man_pw-mon_1.html',1,'page_programs']]],
  ['monitor_17',['spa-monitor',['../page_man_spa-monitor_1.html',1,'page_programs']]]
];
