var searchData=
[
  ['registry_0',['Registry',['../group__pw__registry.html',1,'']]],
  ['resource_1',['Resource',['../group__pw__resource.html',1,'']]],
  ['result_20handling_2',['Result handling',['../group__spa__result.html',1,'']]],
  ['ringbuffer_3',['Ringbuffer',['../group__spa__ringbuffer.html',1,'']]]
];
