var searchData=
[
  ['names_2eh_0',['names.h',['../names_8h.html',1,'']]],
  ['node_2eh_1',['node.h',['../spa_2include_2spa_2debug_2node_8h.html',1,'(Global Namespace)'],['../spa_2include_2spa_2node_2node_8h.html',1,'(Global Namespace)'],['../src_2pipewire_2node_8h.html',1,'(Global Namespace)']]]
];
