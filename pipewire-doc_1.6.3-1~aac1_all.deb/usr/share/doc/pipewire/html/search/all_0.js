var searchData=
[
  ['1_3a_20getting_20started_0',['Tutorial - Part 1: Getting Started',['../page_tutorial1.html',1,'page_tutorial']]]
];
