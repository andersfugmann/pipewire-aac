var searchData=
[
  ['v4l2_0',['pw-v4l2',['../page_man_pw-v4l2_1.html',1,'page_programs']]],
  ['variables_1',['VARIABLES',['../page_man_pipewire-client_conf_5.html#client-env__environment_variables',1,'ENVIRONMENT VARIABLES'],['../page_man_pipewire-jack_conf_5.html#jack-env__environment_variables',1,'ENVIRONMENT VARIABLES'],['../page_man_pipewire_1.html#pipewire-env__environment_variables',1,'ENVIRONMENT VARIABLES']]],
  ['variables_2',['Environment Variables',['../page_streams.html#sec_stream_environment',1,'']]],
  ['vban_20receiver_3',['VBAN receiver',['../page_module_vban_recv.html',1,'page_modules']]],
  ['vban_20sender_4',['VBAN sender',['../page_module_vban_send.html',1,'page_modules']]],
  ['video_20frames_5',['Tutorial - Part 5: Capturing Video Frames',['../page_tutorial5.html',1,'page_tutorial']]],
  ['virtual_20sink_6',['Virtual Sink',['../page_pulse_module_virtual_sink.html',1,'page_pulse_modules']]],
  ['virtual_20source_7',['Virtual Source',['../page_pulse_module_virtual_source.html',1,'page_pulse_modules']]]
];
