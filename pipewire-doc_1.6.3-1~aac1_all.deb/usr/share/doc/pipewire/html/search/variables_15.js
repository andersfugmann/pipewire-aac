var searchData=
[
  ['unit_0',['unit',['../structspa__pod__sequence__body.html#ae83a44c4123cc5dc4450a985d4c4445d',1,'spa_pod_sequence_body']]],
  ['unlinked_1',['unlinked',['../structpw__control__events.html#a2cda9616fd4aa65d7cc2f8dc6efe69dc',1,'pw_control_events']]],
  ['unload_2',['unload',['../structspa__plugin__loader__methods.html#aa91d4ff3f01f2d7c38a066b3d8bc98ca',1,'spa_plugin_loader_methods']]],
  ['unlock_3',['unlock',['../structspa__loop__control__methods.html#a77322a2f445222c1f22df952caaa12b3',1,'spa_loop_control_methods']]],
  ['update_4',['update',['../group__pw__client__node.html#ga3472e36b6ef5e4d2267b86272ba5b1a6',1,'pw_client_node_methods::update'],['../group__pw__session__manager.html#gaa8366fa5903ce48d728d5a4bf1eb6ff2',1,'pw_client_endpoint_methods::update'],['../group__pw__session__manager.html#gab104098c9fd6fad4bbe290509aefbe20',1,'pw_client_session_methods::update']]],
  ['update_5fio_5',['update_io',['../structspa__loop__utils__methods.html#a166d2e9aab23ce96b9d7795c3466fc6b',1,'spa_loop_utils_methods']]],
  ['update_5fpermissions_6',['update_permissions',['../structpw__client__methods.html#a2804d8a526c068a486a4e261821c9a07',1,'pw_client_methods']]],
  ['update_5fproperties_7',['update_properties',['../structpw__client__methods.html#a17155250b4b575de0530a8d01447148a',1,'pw_client_methods']]],
  ['update_5fsource_8',['update_source',['../structspa__loop__methods.html#aa1c58c24c44c6161f7c5d81910cc5acc',1,'spa_loop_methods']]],
  ['update_5ftimer_9',['update_timer',['../structspa__loop__utils__methods.html#abc9a0d7bb777e2c892343b1ca5a6d37d',1,'spa_loop_utils_methods']]],
  ['user_10',['user',['../structspa__param__info.html#aafe96bbf409564bcce653d58fffb40cf',1,'spa_param_info']]],
  ['user_5fdata_11',['user_data',['../structpw__buffer.html#ad85549808ad885c57f85e1aee60b8c96',1,'pw_buffer']]],
  ['user_5fname_12',['user_name',['../structpw__core__info.html#ad294c9fa79558c75141a731c4d812b42',1,'pw_core_info']]]
];
