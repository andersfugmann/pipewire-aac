var searchData=
[
  ['handle_0',['Plugin Handle',['../group__spa__handle.html',1,'']]],
  ['handling_1',['handling',['../group__spa__result.html',1,'Result handling'],['../group__spa__string.html',1,'String handling']]],
  ['hooks_2',['Hooks',['../group__spa__hooks.html',1,'']]]
];
