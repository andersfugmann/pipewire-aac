var searchData=
[
  ['spa_5fhandle_5ffactory_5fenum_5ffunc_5ft_0',['spa_handle_factory_enum_func_t',['../group__spa__handle.html#ga12bab914d8b3939f802d93439768bfd4',1,'plugin.h']]],
  ['spa_5finvoke_5ffunc_5ft_1',['spa_invoke_func_t',['../group__spa__loop.html#gab59a4a2bc60d5c26983a0e0edabc6617',1,'loop.h']]],
  ['spa_5fsource_5fevent_5ffunc_5ft_2',['spa_source_event_func_t',['../group__spa__loop.html#ga4de35545ca7478aeaf64f46434262346',1,'loop.h']]],
  ['spa_5fsource_5ffunc_5ft_3',['spa_source_func_t',['../group__spa__loop.html#ga809d037b8643139b58878b4b31b28cf6',1,'loop.h']]],
  ['spa_5fsource_5fidle_5ffunc_5ft_4',['spa_source_idle_func_t',['../group__spa__loop.html#ga710acda9d2c12a7d44236e5b1024e941',1,'loop.h']]],
  ['spa_5fsource_5fio_5ffunc_5ft_5',['spa_source_io_func_t',['../group__spa__loop.html#gacb78ee7f8a1948db3767b3f9c82f7370',1,'loop.h']]],
  ['spa_5fsource_5fsignal_5ffunc_5ft_6',['spa_source_signal_func_t',['../group__spa__loop.html#ga5484a18b8cc8060d6397589465948378',1,'loop.h']]],
  ['spa_5fsource_5ftimer_5ffunc_5ft_7',['spa_source_timer_func_t',['../group__spa__loop.html#ga12c55826c9d89a9d385da0363ee586d9',1,'loop.h']]]
];
