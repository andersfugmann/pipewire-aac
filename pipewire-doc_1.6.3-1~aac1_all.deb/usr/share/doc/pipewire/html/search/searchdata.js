var indexSectionsWithContent =
{
  0: "1234567_abcdefghijklmnopqrstuvwxyz",
  1: "ips",
  2: "abcdefghijklmnoprstuvw",
  3: "psv",
  4: "_abcdefghijklmnopqrstuvwxyz",
  5: "ps",
  6: "ps",
  7: "_ps",
  8: "_eps",
  9: "abcdefghijklmnpqrstuw",
  10: "1234567abcdefghijlmnoprstuvwxz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

