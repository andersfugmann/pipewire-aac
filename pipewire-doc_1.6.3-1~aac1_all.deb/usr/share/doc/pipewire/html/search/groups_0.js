var searchData=
[
  ['ansi_20codes_0',['ANSI codes',['../group__spa__ansi.html',1,'']]],
  ['api_1',['API',['../group__api__pw__core.html',1,'Core API'],['../group__api__pw__impl.html',1,'Implementation API']]],
  ['array_2',['Array',['../group__pw__array.html',1,'']]]
];
