var searchData=
[
  ['i18n_0',['I18N',['../group__spa__i18n.html',1,'']]],
  ['impl_1',['Impl',['../group__pw__impl__client.html',1,'Client Impl'],['../group__pw__impl__core.html',1,'Core Impl'],['../group__pw__impl__device.html',1,'Device Impl'],['../group__pw__impl__factory.html',1,'Factory Impl'],['../group__pw__impl__link.html',1,'Link Impl'],['../group__pw__impl__metadata.html',1,'Metadata Impl'],['../group__pw__impl__module.html',1,'Module Impl'],['../group__pw__impl__node.html',1,'Node Impl'],['../group__pw__impl__port.html',1,'Port Impl']]],
  ['implementation_20api_2',['Implementation API',['../group__api__pw__impl.html',1,'']]],
  ['info_3',['Type info',['../group__pw__type.html',1,'']]],
  ['initialization_4',['Initialization',['../group__pw__pipewire.html',1,'']]],
  ['interfaces_5',['Interfaces',['../group__spa__interfaces.html',1,'']]],
  ['internationalization_6',['Internationalization',['../group__pw__gettext.html',1,'']]]
];
