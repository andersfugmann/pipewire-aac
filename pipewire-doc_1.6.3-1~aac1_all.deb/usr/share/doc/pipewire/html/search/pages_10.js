var searchData=
[
  ['jack_0',['pw-jack',['../page_man_pw-jack_1.html',1,'page_programs']]],
  ['jack_20conf_1',['jack.conf',['../page_man_pipewire-jack_conf_5.html',1,'page_config']]],
  ['jack_20dbus_20detect_2',['JACK DBus detect',['../page_module_jackdbus_detect.html',1,'page_modules']]],
  ['jack_20properties_3',['JACK PROPERTIES',['../page_man_pipewire-jack_conf_5.html#jack_conf__jack_properties',1,'']]],
  ['jack_20tunnel_4',['JACK Tunnel',['../page_module_jack_tunnel.html',1,'page_modules']]],
  ['jackdbus_20detect_5',['JackDBus Detect',['../page_pulse_module_jackdbus_detect.html',1,'page_pulse_modules']]],
  ['json_20dump_6',['spa-json-dump',['../page_man_spa-json-dump_1.html',1,'page_programs']]]
];
