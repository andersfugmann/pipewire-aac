var structspa__filter__graph__methods =
[
    [ "version", "structspa__filter__graph__methods.html#a1594f5cf64b8ebef04df18235ceaaf89", null ],
    [ "add_listener", "structspa__filter__graph__methods.html#af944f94cb213a71e8732d3549de9a951", null ],
    [ "enum_prop_info", "structspa__filter__graph__methods.html#acb362219639424b68c755c482452aee1", null ],
    [ "get_props", "structspa__filter__graph__methods.html#af0d6d2620f36be37c6eddcd1f8d1e781", null ],
    [ "set_props", "structspa__filter__graph__methods.html#a8db8c44f35a239ea33e090492835663e", null ],
    [ "activate", "structspa__filter__graph__methods.html#a5175a2243523028dfce167dd342a87f4", null ],
    [ "deactivate", "structspa__filter__graph__methods.html#ad46f74ca0b8c8c88ecf2a1b3a18991e5", null ],
    [ "reset", "structspa__filter__graph__methods.html#ab713fd216ef7316fa763fdca3976b2cd", null ],
    [ "process", "structspa__filter__graph__methods.html#a0a013473845571bdb3cc9f78964705a9", null ]
];