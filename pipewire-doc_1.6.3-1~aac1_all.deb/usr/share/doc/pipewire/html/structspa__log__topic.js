var structspa__log__topic =
[
    [ "version", "structspa__log__topic.html#a03003ed60b6acc4788b41e74b9945911", null ],
    [ "topic", "structspa__log__topic.html#ab77cbaf7b01d2f4dddbcf7f51766b9d6", null ],
    [ "level", "structspa__log__topic.html#a23fb58684c75ff5cadeda72fa6ea1f92", null ],
    [ "has_custom_level", "structspa__log__topic.html#a1295d4049013c031f7c30074182dfe58", null ]
];