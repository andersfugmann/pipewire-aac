var structpw__core__events =
[
    [ "version", "structpw__core__events.html#a8d568483182f9bdd13d8d4acbac462b7", null ],
    [ "info", "structpw__core__events.html#a8433a5ea5115e8d914a70ba5dacd3b81", null ],
    [ "done", "structpw__core__events.html#acc0442d3b7d94005c8c63e5bd7b89473", null ],
    [ "ping", "structpw__core__events.html#a20931e5073a743e26c70957f85c10fd8", null ],
    [ "error", "structpw__core__events.html#a590bf80a38429eef4a94d2e8b7f82e56", null ],
    [ "remove_id", "structpw__core__events.html#a8a700a03453729d52d96112647125303", null ],
    [ "bound_id", "structpw__core__events.html#aab9b9d3a84837d892a4617c29f03e976", null ],
    [ "add_mem", "structpw__core__events.html#a7c1f8bd6078afab78aa943704efe7131", null ],
    [ "remove_mem", "structpw__core__events.html#a28cd6e2263efb69df702822028a45df2", null ],
    [ "bound_props", "structpw__core__events.html#a7e1a9d6c8598cee58b622cf61432769e", null ]
];