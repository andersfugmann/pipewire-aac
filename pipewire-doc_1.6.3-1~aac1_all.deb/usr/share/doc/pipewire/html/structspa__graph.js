var structspa__graph =
[
    [ "flags", "structspa__graph.html#a850c90822a1b32d7cd67ec5c76eda2fa", null ],
    [ "parent", "structspa__graph.html#a9bcd83554b53da4a139ed6a9be38bb1c", null ],
    [ "state", "structspa__graph.html#aacd6dde80b95c6415d300f419ea6f144", null ],
    [ "nodes", "structspa__graph.html#a90439529765f13aadc6f1d7727244a1c", null ]
];