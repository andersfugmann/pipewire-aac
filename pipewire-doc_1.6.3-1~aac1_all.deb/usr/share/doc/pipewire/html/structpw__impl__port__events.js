var structpw__impl__port__events =
[
    [ "version", "structpw__impl__port__events.html#a7d76d0a7bef38963ff7c3e5a4fd9a1d3", null ],
    [ "destroy", "structpw__impl__port__events.html#a5595c734ed5c3fc9ab27c2f5244fa325", null ],
    [ "free", "structpw__impl__port__events.html#a7049ef85f5a0f35988c6a2f60a02c385", null ],
    [ "initialized", "structpw__impl__port__events.html#a8ddfb5c4f95dafcf15e0e9d3df367169", null ],
    [ "info_changed", "structpw__impl__port__events.html#a69e18fd1facb78dbb42025c17ef0884a", null ],
    [ "link_added", "structpw__impl__port__events.html#a73104e5c2b8f887977945a597fa6b1ee", null ],
    [ "link_removed", "structpw__impl__port__events.html#acae053d6b84259d9a475eda14ca670ed", null ],
    [ "state_changed", "structpw__impl__port__events.html#a77a67b128bc4961a1caa38572f8f6094", null ],
    [ "control_added", "structpw__impl__port__events.html#a3e2788e02240c77076c32642e1d57c82", null ],
    [ "control_removed", "structpw__impl__port__events.html#a9f23250e31672a49aa26a5dd5b593e80", null ],
    [ "param_changed", "structpw__impl__port__events.html#a8d5a42f37e97b448cf6e1d7942677c81", null ],
    [ "latency_changed", "structpw__impl__port__events.html#a74130c25a3cc6e05ef753847e17a85cb", null ],
    [ "tag_changed", "structpw__impl__port__events.html#abf43e1309a677e920e0e818ed657a7f6", null ],
    [ "capability_changed", "structpw__impl__port__events.html#a8a7ade97568cec1c0423fabac65934b1", null ]
];