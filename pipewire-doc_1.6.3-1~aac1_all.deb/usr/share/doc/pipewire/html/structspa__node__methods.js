var structspa__node__methods =
[
    [ "version", "structspa__node__methods.html#a9b95b184ba04c05972ca57c1ae16c346", null ],
    [ "add_listener", "structspa__node__methods.html#a2bb8310a8ab8273ac0f53b54c6b23223", null ],
    [ "set_callbacks", "structspa__node__methods.html#a8b0809c0e27afae1c9489bc5807e4cb7", null ],
    [ "sync", "structspa__node__methods.html#a3d23d14b7707fc2f3926a78d47dde720", null ],
    [ "enum_params", "structspa__node__methods.html#a788f398e8fa5e85f03ecb68602821204", null ],
    [ "set_param", "structspa__node__methods.html#a0ea59a508f6d40b5889c23940a036be6", null ],
    [ "set_io", "structspa__node__methods.html#ab76d1e119a213a4cd3e5a15fb783f829", null ],
    [ "send_command", "structspa__node__methods.html#accf0d924064ab5c9c1cdde7d0013232c", null ],
    [ "add_port", "structspa__node__methods.html#a7236a06df9ca3894d3164b7b0566cc54", null ],
    [ "remove_port", "structspa__node__methods.html#ac43bffc3912889ba2c35c8fe7c7142db", null ],
    [ "port_enum_params", "structspa__node__methods.html#a1f465eba7a1322ef153142227a68d43b", null ],
    [ "port_set_param", "structspa__node__methods.html#af04906b32eb2e2862e8e2e2b0ef71f0c", null ],
    [ "port_use_buffers", "structspa__node__methods.html#a2773ceced2814d3adec184fa5ad538d2", null ],
    [ "port_set_io", "structspa__node__methods.html#a2089aa56468969fa4e6e65d6c80dbd14", null ],
    [ "port_reuse_buffer", "structspa__node__methods.html#ab92b0dc3ae1a61ea5f291393e927de93", null ],
    [ "process", "structspa__node__methods.html#a2216e9265fde3d179e7bec8ae69baecc", null ]
];