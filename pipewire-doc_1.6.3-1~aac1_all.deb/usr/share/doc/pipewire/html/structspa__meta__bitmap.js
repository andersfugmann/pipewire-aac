var structspa__meta__bitmap =
[
    [ "format", "structspa__meta__bitmap.html#aa1f903801d658ae96cbc5e624676ff71", null ],
    [ "size", "structspa__meta__bitmap.html#a6f32bc13290f583d10ea16cc1bb825da", null ],
    [ "stride", "structspa__meta__bitmap.html#ac2f340dbebb61308461ac61592b52fe0", null ],
    [ "offset", "structspa__meta__bitmap.html#abaac271d52c056bf717f25698e9690bd", null ]
];