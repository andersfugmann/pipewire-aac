var structspa__audio__info__dts =
[
    [ "rate", "structspa__audio__info__dts.html#a9003219cb1cf00a8896f73bfa3b962f9", null ],
    [ "channels", "structspa__audio__info__dts.html#a1499125a994e660d9c826ae1b9ebb515", null ],
    [ "ext_type", "structspa__audio__info__dts.html#a8af77cb26b9cbd08602c98fe58b0ab65", null ]
];