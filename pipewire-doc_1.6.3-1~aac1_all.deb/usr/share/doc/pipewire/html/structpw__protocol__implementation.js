var structpw__protocol__implementation =
[
    [ "version", "structpw__protocol__implementation.html#a8bf7e732f7cac47bba3b798c722f739a", null ],
    [ "new_client", "structpw__protocol__implementation.html#a859abf630e7a562357647c0bb7caccb6", null ],
    [ "add_server", "structpw__protocol__implementation.html#a237c5d6a817a2b5dddb0f2e996d0a0bd", null ],
    [ "add_fd_server", "structpw__protocol__implementation.html#aa3e4acbc68161bd86cdab82f056b8825", null ]
];