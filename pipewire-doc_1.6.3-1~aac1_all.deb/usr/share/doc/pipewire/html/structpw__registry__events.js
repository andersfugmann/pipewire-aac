var structpw__registry__events =
[
    [ "version", "structpw__registry__events.html#a94464d7de86207e80a3dff93974b1a01", null ],
    [ "global", "structpw__registry__events.html#a37bd7089a7a07d7154e111e67b25f96c", null ],
    [ "global_remove", "structpw__registry__events.html#a04c4f7cbbf5dcc0c54887862887dbc97", null ]
];