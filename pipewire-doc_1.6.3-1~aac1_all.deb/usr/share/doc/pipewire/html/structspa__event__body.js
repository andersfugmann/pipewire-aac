var structspa__event__body =
[
    [ "body", "structspa__event__body.html#aa484bc2cadd16a104476183666de3819", null ]
];