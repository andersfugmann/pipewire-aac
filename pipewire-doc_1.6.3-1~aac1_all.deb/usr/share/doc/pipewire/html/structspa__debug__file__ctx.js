var structspa__debug__file__ctx =
[
    [ "ctx", "structspa__debug__file__ctx.html#a817d19045e3261030ec8e38842a018c3", null ],
    [ "f", "structspa__debug__file__ctx.html#a34708c6380f0ca51b9d318a089306401", null ]
];