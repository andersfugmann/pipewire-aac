var group__spa__filter__graph =
[
    [ "filter-graph.h", "filter-graph_8h.html", null ],
    [ "spa_filter_graph", "structspa__filter__graph.html", [
      [ "iface", "structspa__filter__graph.html#ae4cf9c14db9d225b8375b9c79e2fdedd", null ]
    ] ],
    [ "spa_filter_graph_info", "structspa__filter__graph__info.html", [
      [ "n_inputs", "structspa__filter__graph__info.html#af711f93f5835cd02a067d2dc87e22505", null ],
      [ "n_outputs", "structspa__filter__graph__info.html#a53f7bae92bfb7c557a0a72ec2ee8b30a", null ],
      [ "change_mask", "structspa__filter__graph__info.html#a43b384b8632949298f98b259def189a9", null ],
      [ "flags", "structspa__filter__graph__info.html#a63b56226066ddb49290a08d995a82980", null ]
    ] ],
    [ "spa_filter_graph_events", "structspa__filter__graph__events.html", [
      [ "version", "structspa__filter__graph__events.html#a5679561cb1d6515e49f4719ef4edd33e", null ],
      [ "info", "structspa__filter__graph__events.html#ab5f3808cad27363303850727e8f917f3", null ],
      [ "apply_props", "structspa__filter__graph__events.html#ab0db05d4a9001e840f11c5a3169de2cb", null ],
      [ "props_changed", "structspa__filter__graph__events.html#a8fd95c909c7a64cbd856ffac8860824f", null ]
    ] ],
    [ "spa_filter_graph_methods", "structspa__filter__graph__methods.html", [
      [ "version", "structspa__filter__graph__methods.html#a1594f5cf64b8ebef04df18235ceaaf89", null ],
      [ "add_listener", "structspa__filter__graph__methods.html#af944f94cb213a71e8732d3549de9a951", null ],
      [ "enum_prop_info", "structspa__filter__graph__methods.html#acb362219639424b68c755c482452aee1", null ],
      [ "get_props", "structspa__filter__graph__methods.html#af0d6d2620f36be37c6eddcd1f8d1e781", null ],
      [ "set_props", "structspa__filter__graph__methods.html#a8db8c44f35a239ea33e090492835663e", null ],
      [ "activate", "structspa__filter__graph__methods.html#a5175a2243523028dfce167dd342a87f4", null ],
      [ "deactivate", "structspa__filter__graph__methods.html#ad46f74ca0b8c8c88ecf2a1b3a18991e5", null ],
      [ "reset", "structspa__filter__graph__methods.html#ab713fd216ef7316fa763fdca3976b2cd", null ],
      [ "process", "structspa__filter__graph__methods.html#a0a013473845571bdb3cc9f78964705a9", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_FilterGraph", "group__spa__filter__graph.html#gabcc07f441d25f43fa0895fdf14a4af61", null ],
    [ "SPA_VERSION_FILTER_GRAPH", "group__spa__filter__graph.html#ga0e03604f1b91e1233e29a487cd29ec2d", null ],
    [ "SPA_FILTER_GRAPH_CHANGE_MASK_FLAGS", "group__spa__filter__graph.html#gafaa33cf5387b4e7e2f6984b7b059e69f", null ],
    [ "SPA_FILTER_GRAPH_CHANGE_MASK_PROPS", "group__spa__filter__graph.html#gaec645d8eab4ec5e00dc28d31b3728580", null ],
    [ "SPA_VERSION_FILTER_GRAPH_EVENTS", "group__spa__filter__graph.html#ga9459e99fd168c97ed456ea29c3c82a8a", null ],
    [ "SPA_VERSION_FILTER_GRAPH_METHODS", "group__spa__filter__graph.html#ga972d93399e612254d1fdb29f8972ae58", null ],
    [ "spa_filter_graph_add_listener", "group__spa__filter__graph.html#gaed289c7c1fb144910caab60738a1065a", null ],
    [ "spa_filter_graph_enum_prop_info", "group__spa__filter__graph.html#ga176d18db8d9c72d09f5f1b3806604f13", null ],
    [ "spa_filter_graph_get_props", "group__spa__filter__graph.html#gad994a8c1e2fb16a64ea7240725c5f27e", null ],
    [ "spa_filter_graph_set_props", "group__spa__filter__graph.html#ga97d86556256c8d3a47ebf7e7768f7c55", null ],
    [ "spa_filter_graph_activate", "group__spa__filter__graph.html#gaabecec3e804a9b96c6462aae852b405a", null ],
    [ "spa_filter_graph_deactivate", "group__spa__filter__graph.html#ga9fee01a674ca50b26d7df6f0f44a57f0", null ],
    [ "spa_filter_graph_reset", "group__spa__filter__graph.html#ga5dbc25ca24f8411a074557f54323f6b1", null ],
    [ "spa_filter_graph_process", "group__spa__filter__graph.html#ga076508044862548e3ff5793fabe02799", null ]
];