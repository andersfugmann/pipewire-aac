var structspa__dbus__connection =
[
    [ "version", "structspa__dbus__connection.html#a8b89c910cd288a5e1d2af8216568a3a6", null ],
    [ "get", "structspa__dbus__connection.html#a684f175f4839121d8c976c50ca273303", null ],
    [ "destroy", "structspa__dbus__connection.html#a1b0a0400c311d50b764f100b4b50bf8f", null ],
    [ "add_listener", "structspa__dbus__connection.html#a2e21fc21219047d9bdc8e1994a23acea", null ]
];