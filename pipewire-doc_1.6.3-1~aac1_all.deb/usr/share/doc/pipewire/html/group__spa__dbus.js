var group__spa__dbus =
[
    [ "dbus.h", "dbus_8h.html", null ],
    [ "spa_dbus", "structspa__dbus.html", [
      [ "iface", "structspa__dbus.html#a240c318013b1a4441195fa94f213b65b", null ]
    ] ],
    [ "spa_dbus_connection_events", "structspa__dbus__connection__events.html", [
      [ "version", "structspa__dbus__connection__events.html#a2ae8b95b36226127853160f1779260e0", null ],
      [ "destroy", "structspa__dbus__connection__events.html#a1e35b4f490157dd9c4194b4a03490fc6", null ],
      [ "disconnected", "structspa__dbus__connection__events.html#a481b39049a46ec7d8519c8d2c9318968", null ]
    ] ],
    [ "spa_dbus_connection", "structspa__dbus__connection.html", [
      [ "version", "structspa__dbus__connection.html#a8b89c910cd288a5e1d2af8216568a3a6", null ],
      [ "get", "structspa__dbus__connection.html#a684f175f4839121d8c976c50ca273303", null ],
      [ "destroy", "structspa__dbus__connection.html#a1b0a0400c311d50b764f100b4b50bf8f", null ],
      [ "add_listener", "structspa__dbus__connection.html#a2e21fc21219047d9bdc8e1994a23acea", null ]
    ] ],
    [ "spa_dbus_methods", "structspa__dbus__methods.html", [
      [ "version", "structspa__dbus__methods.html#a6e090fa6083fa425460f631ea48c3434", null ],
      [ "get_connection", "structspa__dbus__methods.html#a1e518bcb13046ec6b46a927024b6cc28", null ]
    ] ],
    [ "spa_dbus_type", "group__spa__dbus.html#ga39128520ce2167eb64279fc23e617fa0", [
      [ "SPA_DBUS_TYPE_SESSION", "group__spa__dbus.html#gga39128520ce2167eb64279fc23e617fa0a1527a1d0ef093fd2a6cddc424d80b2d2", null ],
      [ "SPA_DBUS_TYPE_SYSTEM", "group__spa__dbus.html#gga39128520ce2167eb64279fc23e617fa0a5fdca2872c84184d6a5ca0701726d229", null ],
      [ "SPA_DBUS_TYPE_STARTER", "group__spa__dbus.html#gga39128520ce2167eb64279fc23e617fa0a4645a44a9d5954b882e7a3c23672fed8", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_DBus", "group__spa__dbus.html#ga8015339211635f3bcf91ff52a9953678", null ],
    [ "SPA_VERSION_DBUS", "group__spa__dbus.html#ga86263eb7e15c01e44c67b4b92c777a45", null ],
    [ "SPA_DBUS_CONNECTION_EVENT_DESTROY", "group__spa__dbus.html#gae64bf9807f6afbbf8e5cefce37bddd9f", null ],
    [ "SPA_DBUS_CONNECTION_EVENT_DISCONNECTED", "group__spa__dbus.html#gaed122ed9b453bf144717949594e6a86d", null ],
    [ "SPA_DBUS_CONNECTION_EVENT_NUM", "group__spa__dbus.html#gaa1bb9052d868e1185afd82668582d740", null ],
    [ "SPA_VERSION_DBUS_CONNECTION_EVENTS", "group__spa__dbus.html#ga3b4641d430f6892c79f6a02284349dbf", null ],
    [ "SPA_VERSION_DBUS_CONNECTION", "group__spa__dbus.html#gab06fb2f95424f573700caeabf9424784", null ],
    [ "SPA_VERSION_DBUS_METHODS", "group__spa__dbus.html#ga9c9264eb38a39811f9a1103bef5d1d99", null ],
    [ "spa_dbus_connection_get", "group__spa__dbus.html#ga99b6b19bfaddde18c2e2a1282624ed45", null ],
    [ "spa_dbus_connection_destroy", "group__spa__dbus.html#ga40e25506512f4fb7f1237f5c48240531", null ],
    [ "spa_dbus_connection_add_listener", "group__spa__dbus.html#gab2d1a7bc0b6f0b251e677f68db0c84c7", null ],
    [ "spa_dbus_get_connection", "group__spa__dbus.html#gaa4fae4782ba7059f2e9ea7b5dc2dad3b", null ]
];