var structpw__buffer =
[
    [ "buffer", "structpw__buffer.html#ad0716b5bc3f7e1cb3009c524c0192090", null ],
    [ "user_data", "structpw__buffer.html#ad85549808ad885c57f85e1aee60b8c96", null ],
    [ "size", "structpw__buffer.html#a925734b861209896789573f3b94a61c1", null ],
    [ "requested", "structpw__buffer.html#ab5fe741ec31686febdbc602098945f08", null ],
    [ "time", "structpw__buffer.html#a934ea386457a593550c5600368a50994", null ]
];