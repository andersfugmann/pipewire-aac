var structpw__link__methods =
[
    [ "version", "structpw__link__methods.html#a93094b3a43a3dd5911e6016f1cbd44cf", null ],
    [ "add_listener", "structpw__link__methods.html#ae0864a9eb97073db8174b051b074f180", null ]
];