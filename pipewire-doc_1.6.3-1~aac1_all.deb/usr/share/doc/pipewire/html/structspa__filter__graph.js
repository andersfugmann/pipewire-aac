var structspa__filter__graph =
[
    [ "iface", "structspa__filter__graph.html#ae4cf9c14db9d225b8375b9c79e2fdedd", null ]
];