var structpw__global__events =
[
    [ "version", "structpw__global__events.html#a909a601dfd3ce02c04c0e714df6450a1", null ],
    [ "destroy", "structpw__global__events.html#a8ccd4e331a4c1a0401e13ab3c9b04236", null ],
    [ "free", "structpw__global__events.html#a57040ccb9805bda67581693d06c0cea6", null ],
    [ "permissions_changed", "structpw__global__events.html#a914924700d817cb9d4f58c327d5952e8", null ]
];