var structspa__audio__info__dsd =
[
    [ "bitorder", "structspa__audio__info__dsd.html#a698a141255b6d57f04d56de0fa52d170", null ],
    [ "flags", "structspa__audio__info__dsd.html#a9f7ed724310d9b5a2c95607399fe3a34", null ],
    [ "interleave", "structspa__audio__info__dsd.html#a902dd094aab140dc3500a3a36ef967da", null ],
    [ "rate", "structspa__audio__info__dsd.html#a72a8060d8747abb6e380e0dc0261157e", null ],
    [ "channels", "structspa__audio__info__dsd.html#a563add98a612fe3617a58e2cb1a703bc", null ],
    [ "position", "structspa__audio__info__dsd.html#a4f11fce0402edcbe61f0b35f27396ac9", null ]
];