var group__spa__string =
[
    [ "string.h", "string_8h.html", null ],
    [ "spa_strbuf", "structspa__strbuf.html", [
      [ "buffer", "structspa__strbuf.html#ad1ee23ef60728cefba6d11341da61ef1", null ],
      [ "maxsize", "structspa__strbuf.html#ac82fdbc33669185a77140a3faf908a0c", null ],
      [ "pos", "structspa__strbuf.html#a8ddb2d12b7d6a2804f13ab6c40cab6d1", null ]
    ] ],
    [ "spa_streq", "group__spa__string.html#gafd68727836dd49a711264f91e0f545aa", null ],
    [ "spa_strneq", "group__spa__string.html#ga9e9a66a0c909e89dfadf528d6cbadd66", null ],
    [ "spa_strstartswith", "group__spa__string.html#ga8355173a6b0d6cc666f807230793e3b0", null ],
    [ "spa_strendswith", "group__spa__string.html#ga71cd880d1fa5c3795bb29fdcdf3be2d7", null ],
    [ "spa_atoi32", "group__spa__string.html#gac1a2c0fc276ebd9521cd0c95a0c0de1f", null ],
    [ "spa_atou32", "group__spa__string.html#gaf585043d3d326f5ef9e163fe3e92266d", null ],
    [ "spa_atoi64", "group__spa__string.html#gabe1883778302abe4496b1365ee9a69be", null ],
    [ "spa_atou64", "group__spa__string.html#ga31e639f4315450d893c1b830813f8427", null ],
    [ "spa_atob", "group__spa__string.html#ga9f9bcdacd686aad5b3b03f78038d8061", null ],
    [ "spa_vscnprintf", "group__spa__string.html#gad02cefc75ea507b8396010e957487419", null ],
    [ "spa_scnprintf", "group__spa__string.html#gad95d42df75305c0da0efcf8c633515b1", null ],
    [ "spa_strtof", "group__spa__string.html#gad138c0d015bb42c3acc942657c12be87", null ],
    [ "spa_atof", "group__spa__string.html#ga36b56ba179f4b5ead98a9ac82409f48c", null ],
    [ "spa_strtod", "group__spa__string.html#gad0f91dfe5b84b02022abc3b0780f3f4e", null ],
    [ "spa_atod", "group__spa__string.html#gae10f94b4feaaea1dbd8e09ee749fab4e", null ],
    [ "spa_dtoa", "group__spa__string.html#ga02a69c28268b45e9c96785c5fea8ac64", null ],
    [ "spa_strbuf_init", "group__spa__string.html#ga62c6417fd88eae51f063f7fab332e2a2", null ],
    [ "spa_strbuf_append", "group__spa__string.html#ga09d9f308bcb98d09e25655e8446df5ce", null ]
];