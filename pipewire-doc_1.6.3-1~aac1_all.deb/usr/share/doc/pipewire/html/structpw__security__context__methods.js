var structpw__security__context__methods =
[
    [ "version", "structpw__security__context__methods.html#a431ad7c170c6f5b2c13499d03997088d", null ],
    [ "add_listener", "structpw__security__context__methods.html#a4b13cd5a9739a3c82813276b8c875faa", null ],
    [ "create", "structpw__security__context__methods.html#a78e54bfd81f8e41605152161f29ad166", null ]
];