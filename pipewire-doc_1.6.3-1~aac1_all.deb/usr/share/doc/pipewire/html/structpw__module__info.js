var structpw__module__info =
[
    [ "id", "structpw__module__info.html#a027112b51093afc0ec6370a549bcb29f", null ],
    [ "filename", "structpw__module__info.html#a1578038e841f4d0e8ac4348f263124c8", null ],
    [ "args", "structpw__module__info.html#a8991e7a078e6d92aa05e1922efc5bc53", null ],
    [ "change_mask", "structpw__module__info.html#aae79b994769838377e2b549736f12de3", null ]
];