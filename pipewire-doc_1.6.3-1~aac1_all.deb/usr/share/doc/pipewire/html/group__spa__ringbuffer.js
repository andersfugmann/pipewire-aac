var group__spa__ringbuffer =
[
    [ "ringbuffer.h", "ringbuffer_8h.html", null ],
    [ "spa_ringbuffer", "structspa__ringbuffer.html", [
      [ "readindex", "structspa__ringbuffer.html#a6374bbe98fbea037a4479f11cec464c2", null ],
      [ "writeindex", "structspa__ringbuffer.html#ae7b07eebf6c9f8d3266f46cdffdfca28", null ]
    ] ],
    [ "SPA_API_RINGBUFFER", "group__spa__ringbuffer.html#ga48e87cc044b8351f3dcd9d3a66bdf703", null ],
    [ "SPA_RINGBUFFER_INIT", "group__spa__ringbuffer.html#ga636d45b00fa064ed74316528cd21cab5", null ],
    [ "spa_ringbuffer_init", "group__spa__ringbuffer.html#gacdaf56229f46245a9b58b71c83181a9a", null ],
    [ "spa_ringbuffer_set_avail", "group__spa__ringbuffer.html#ga255dbffcace9c96af41b33e358e1bf1b", null ],
    [ "spa_ringbuffer_get_read_index", "group__spa__ringbuffer.html#ga8d0967ca7c3d8a3dcb39879d46f49cf2", null ],
    [ "spa_ringbuffer_read_data", "group__spa__ringbuffer.html#gad620fa22ac4d12b7f482e50525e1242f", null ],
    [ "spa_ringbuffer_read_update", "group__spa__ringbuffer.html#gaa049c4f76b7818538e2e41adb471d6b4", null ],
    [ "spa_ringbuffer_get_write_index", "group__spa__ringbuffer.html#gaa333935551d66a9a434227adcb1f3976", null ],
    [ "spa_ringbuffer_write_data", "group__spa__ringbuffer.html#gac988a539e59a52667f90977282898a6c", null ],
    [ "spa_ringbuffer_write_update", "group__spa__ringbuffer.html#ga8f1a9c2bb15d923d00803f1dadcccaed", null ]
];