var structpw__impl__link__events =
[
    [ "version", "structpw__impl__link__events.html#a05c9fec1c6580f673d09e33005bca5ee", null ],
    [ "destroy", "structpw__impl__link__events.html#a8e6dceaefdbbe793d1eba749370a3f25", null ],
    [ "free", "structpw__impl__link__events.html#a7cf5965ff2f975aba7ac061938e1fa9c", null ],
    [ "initialized", "structpw__impl__link__events.html#ae136867ff703e789d52dbb2ef427726d", null ],
    [ "info_changed", "structpw__impl__link__events.html#a36d3179004ca94bfe99cfc7c7608321a", null ],
    [ "state_changed", "structpw__impl__link__events.html#a05b20c99f1014e62e0d032b92382f584", null ],
    [ "port_unlinked", "structpw__impl__link__events.html#ad161d67256c9fd29f54cc53dbacb10d5", null ]
];