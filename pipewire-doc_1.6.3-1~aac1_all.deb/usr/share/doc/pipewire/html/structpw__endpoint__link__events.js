var structpw__endpoint__link__events =
[
    [ "version", "structpw__endpoint__link__events.html#ac94440a980f13b2ec1dca2be768d7a2e", null ],
    [ "info", "structpw__endpoint__link__events.html#ac358bf9f098e9a01690fb72901927427", null ],
    [ "param", "structpw__endpoint__link__events.html#ade3caa4760973bd219b5b8845a2ab8f6", null ]
];