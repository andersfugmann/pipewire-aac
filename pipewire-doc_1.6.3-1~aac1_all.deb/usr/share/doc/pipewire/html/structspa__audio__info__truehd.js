var structspa__audio__info__truehd =
[
    [ "rate", "structspa__audio__info__truehd.html#accd98e59cbe943295c85824226bc8f07", null ],
    [ "channels", "structspa__audio__info__truehd.html#a7525ba382f5f6806f9a6437579f0926f", null ]
];