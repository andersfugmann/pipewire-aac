var structpw__node__events =
[
    [ "version", "structpw__node__events.html#a37faf21db57a7e95999db521fb1cbcab", null ],
    [ "info", "structpw__node__events.html#a31efa366284e12aa933c87ac63290adf", null ],
    [ "param", "structpw__node__events.html#aa945ae608ff9a37d9fb0a2a24208caff", null ]
];