var structspa__i18n =
[
    [ "iface", "structspa__i18n.html#a4ca10c865fe33ffff4fd9abb9265c0f8", null ]
];