var structpw__client__info =
[
    [ "id", "structpw__client__info.html#a8585e5629d10bb4359ede29782fd7c21", null ],
    [ "change_mask", "structpw__client__info.html#a9123521af948ea7b720d1ebb0f39c66b", null ]
];