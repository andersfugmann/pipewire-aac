var structspa__node__info =
[
    [ "max_input_ports", "structspa__node__info.html#a9f05f762157f2ae9db446937f19da173", null ],
    [ "max_output_ports", "structspa__node__info.html#a5c181a5c275e9a0c9ec82156a38f10a5", null ],
    [ "change_mask", "structspa__node__info.html#a985458f3b046fb6b7da0974ac08fe504", null ],
    [ "flags", "structspa__node__info.html#a248c6cf0005c3b29a3ceb1bbff232cd9", null ],
    [ "params", "structspa__node__info.html#a11fa9f260086bf624de400a80bf79219", null ],
    [ "n_params", "structspa__node__info.html#a41964dbf3b7ace8dd61b9f82d123b4d6", null ]
];