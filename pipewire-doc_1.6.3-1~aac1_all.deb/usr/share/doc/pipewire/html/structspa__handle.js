var structspa__handle =
[
    [ "version", "structspa__handle.html#aaf5d3406480eab83a92db807bc2154c5", null ],
    [ "get_interface", "structspa__handle.html#a740b7347a19e12eb38d16d39b5aebbb3", null ],
    [ "clear", "structspa__handle.html#aaef038ef76a15ddaf5833510535716b4", null ]
];