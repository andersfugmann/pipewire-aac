var structspa__filter__graph__info =
[
    [ "n_inputs", "structspa__filter__graph__info.html#af711f93f5835cd02a067d2dc87e22505", null ],
    [ "n_outputs", "structspa__filter__graph__info.html#a53f7bae92bfb7c557a0a72ec2ee8b30a", null ],
    [ "change_mask", "structspa__filter__graph__info.html#a43b384b8632949298f98b259def189a9", null ],
    [ "flags", "structspa__filter__graph__info.html#a63b56226066ddb49290a08d995a82980", null ]
];