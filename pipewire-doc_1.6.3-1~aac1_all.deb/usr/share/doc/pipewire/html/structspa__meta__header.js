var structspa__meta__header =
[
    [ "flags", "structspa__meta__header.html#a2d8eed1753e4b1649faf357f3307217d", null ],
    [ "offset", "structspa__meta__header.html#a1410208fd9ccdd153418f01d5ce12d7b", null ],
    [ "pts", "structspa__meta__header.html#aae54e5badad1945c2a49d64842df5b1f", null ],
    [ "dts_offset", "structspa__meta__header.html#af9dface8f9e761dc4025dceaa4527a45", null ],
    [ "seq", "structspa__meta__header.html#a76604c6ef39f2e3f103f6e71532205c8", null ]
];