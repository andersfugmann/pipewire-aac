var structspa__meta__sync__timeline =
[
    [ "flags", "structspa__meta__sync__timeline.html#add471afa6cc436f723937b8396097783", null ],
    [ "padding", "structspa__meta__sync__timeline.html#a0382d24924c9671b17a23299a63dd5b8", null ],
    [ "acquire_point", "structspa__meta__sync__timeline.html#a8d526007c330bac0e8a02039b8be640f", null ],
    [ "release_point", "structspa__meta__sync__timeline.html#a9ba1aa15173c417f3d2b85e0a15bbaac", null ]
];