var structpw__module__events =
[
    [ "version", "structpw__module__events.html#a3b36703a786c3fac2605fa5ebde569b5", null ],
    [ "info", "structpw__module__events.html#a83ef14bf35428ebc09a587c65348c5ff", null ]
];