var structspa__audio__aec =
[
    [ "iface", "structspa__audio__aec.html#a472c09f9a147170d0892a650b60c9b5d", null ],
    [ "info", "structspa__audio__aec.html#a09e1e6ddb6cba06861e418fad8eb2442", null ],
    [ "latency", "structspa__audio__aec.html#a2c343b0ced8bc8a9d22c441558c1cc9f", null ]
];