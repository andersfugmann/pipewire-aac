var page_api =
[
    [ "SPA (Simple Plugin API)", "page_spa.html", "page_spa" ],
    [ "Client Implementation", "page_client_impl.html", [
      [ "Overview", "page_client_impl.html#sec_page_client_impl_overview", null ],
      [ "Credentials", "page_client_impl.html#sec_page_client_impl_credentials", null ],
      [ "Types", "page_client_impl.html#sec_page_client_impl_types", null ],
      [ "Resources", "page_client_impl.html#sec_page_client_impl_resources", null ]
    ] ],
    [ "Proxy", "page_proxy.html", [
      [ "Overview", "page_proxy.html#sec_page_proxy_overview", null ],
      [ "Core proxy", "page_proxy.html#sec_page_proxy_core", null ],
      [ "Create", "page_proxy.html#sec_page_proxy_create", null ],
      [ "Bind", "page_proxy.html#sec_page_proxy_bind", null ],
      [ "Methods", "page_proxy.html#sec_page_proxy_methods", null ],
      [ "Events", "page_proxy.html#sec_page_proxy_events", null ],
      [ "Destroy", "page_proxy.html#sec_page_proxy_destroy", null ]
    ] ],
    [ "Streams", "page_streams.html", [
      [ "Overview", "page_streams.html#sec_overview", null ],
      [ "Create", "page_streams.html#sec_create", null ],
      [ "Connect", "page_streams.html#sec_connect", [
        [ "Stream target", "page_streams.html#ssec_stream_target", null ],
        [ "Stream formats", "page_streams.html#ssec_stream_formats", null ]
      ] ],
      [ "Format negotiation", "page_streams.html#sec_format", null ],
      [ "Buffer negotiation", "page_streams.html#sec_buffers", null ],
      [ "Streaming", "page_streams.html#sec_streaming", [
        [ "Consume data", "page_streams.html#ssec_consume", null ],
        [ "Produce data", "page_streams.html#ssec_produce", null ]
      ] ],
      [ "Obtaining timing information", "page_streams.html#sec_stream_timing", null ],
      [ "Driving the graph", "page_streams.html#sec_stream_driving", null ],
      [ "Request processing", "page_streams.html#sec_stream_process_requests", null ],
      [ "Disconnect", "page_streams.html#sec_stream_disconnect", null ],
      [ "Configuration", "page_streams.html#sec_stream_configuration", [
        [ "Stream Properties", "page_streams.html#ssec_config_properties", null ],
        [ "Stream Rules", "page_streams.html#ssec_config_rules", null ]
      ] ],
      [ "Environment Variables", "page_streams.html#sec_stream_environment", null ]
    ] ],
    [ "Thread Loop", "page_thread_loop.html", [
      [ "Overview", "page_thread_loop.html#sec_thread_loop_overview", null ],
      [ "Creation", "page_thread_loop.html#sec_thread_loop_create", null ],
      [ "Destruction", "page_thread_loop.html#sec_thread_loop_destruction", null ],
      [ "Locking", "page_thread_loop.html#sec_thread_loop_locking", null ],
      [ "Events and Callbacks", "page_thread_loop.html#sec_thread_loop_events", null ]
    ] ]
];