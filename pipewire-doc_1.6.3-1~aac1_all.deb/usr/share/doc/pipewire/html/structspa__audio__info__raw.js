var structspa__audio__info__raw =
[
    [ "format", "structspa__audio__info__raw.html#a542692f9d3518632e37ea575d13ca149", null ],
    [ "flags", "structspa__audio__info__raw.html#a696f18b889bb8a5496e16dd48f7d8e01", null ],
    [ "rate", "structspa__audio__info__raw.html#ae7e501bbfbef2cd75f3ae0f13719652c", null ],
    [ "channels", "structspa__audio__info__raw.html#a5a7e0c093143ba0820e936ece11f0952", null ],
    [ "position", "structspa__audio__info__raw.html#ac21ae45356ef4e1dbfde141937fde9c5", null ]
];