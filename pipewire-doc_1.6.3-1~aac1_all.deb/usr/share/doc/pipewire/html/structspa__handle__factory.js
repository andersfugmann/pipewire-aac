var structspa__handle__factory =
[
    [ "version", "structspa__handle__factory.html#a528ffc68aa9b406e094c04bba09bbc10", null ],
    [ "info", "structspa__handle__factory.html#a6edd8af903eeb185389da41ee945158f", null ],
    [ "get_size", "structspa__handle__factory.html#aa48d0b857861f618011a9f4a89435484", null ],
    [ "init", "structspa__handle__factory.html#ad9e9ca49d03aed627c1c1ac5db5266d7", null ],
    [ "enum_interface_info", "structspa__handle__factory.html#a00264d237fb8d45b1878d8ea32fbb5b2", null ]
];