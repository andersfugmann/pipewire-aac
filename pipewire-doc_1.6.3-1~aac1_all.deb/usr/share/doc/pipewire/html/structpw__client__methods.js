var structpw__client__methods =
[
    [ "version", "structpw__client__methods.html#a898d61fc799b5c09421365854020b357", null ],
    [ "add_listener", "structpw__client__methods.html#ad5cf20929a275ce91d7fdbbb80e70be3", null ],
    [ "error", "structpw__client__methods.html#a298f33a5d81477d06b08f52d233b740a", null ],
    [ "update_properties", "structpw__client__methods.html#a17155250b4b575de0530a8d01447148a", null ],
    [ "get_permissions", "structpw__client__methods.html#a7af9e64e81ebc0b3a7d726ff98e0dd84", null ],
    [ "update_permissions", "structpw__client__methods.html#a2804d8a526c068a486a4e261821c9a07", null ]
];