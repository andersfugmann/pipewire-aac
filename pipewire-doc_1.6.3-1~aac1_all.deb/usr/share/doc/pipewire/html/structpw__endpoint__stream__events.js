var structpw__endpoint__stream__events =
[
    [ "version", "structpw__endpoint__stream__events.html#a2deefdff752b1d55ef2d85821b09b04a", null ],
    [ "info", "structpw__endpoint__stream__events.html#ab37cc600d299d1d394d825d151d640c5", null ],
    [ "param", "structpw__endpoint__stream__events.html#aaf1e568a1ebca79113dca8de94c6763a", null ]
];