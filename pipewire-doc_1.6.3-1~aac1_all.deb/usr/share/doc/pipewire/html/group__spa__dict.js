var group__spa__dict =
[
    [ "dict.h", "utils_2dict_8h.html", null ],
    [ "spa_dict_item", "structspa__dict__item.html", [
      [ "key", "structspa__dict__item.html#a16dc8153e2ea77c9c82380456734478a", null ],
      [ "value", "structspa__dict__item.html#af08479e3ff870039be002b436a02457d", null ]
    ] ],
    [ "spa_dict", "structspa__dict.html", [
      [ "flags", "structspa__dict.html#a88aca003fcdbc47599ffb3e2737f1a69", null ],
      [ "n_items", "structspa__dict.html#a3b3b78bfe5fffe13a10720bb7099c399", null ],
      [ "items", "structspa__dict.html#a1f1083da3fcd51b9c3eb22cc8f1d54e0", null ]
    ] ],
    [ "SPA_DICT_ITEM", "group__spa__dict.html#gaa385e5494634121e2797c166a602edda", null ],
    [ "SPA_DICT_ITEM_INIT", "group__spa__dict.html#ga2f4c23f6a5dd5c9eb93cfeccb8211901", null ],
    [ "SPA_DICT_FLAG_SORTED", "group__spa__dict.html#gad96b32b56c741b60cd898d1da2691c45", null ],
    [ "SPA_DICT", "group__spa__dict.html#ga35b6b1a60fe25293c3446d1d9214eb9a", null ],
    [ "SPA_DICT_ARRAY", "group__spa__dict.html#ga1935ad94495edd83e87aaceb6d527523", null ],
    [ "SPA_DICT_ITEMS", "group__spa__dict.html#ga2ac4b79bad1814764458030dddf48bee", null ],
    [ "SPA_DICT_INIT", "group__spa__dict.html#gacba99b7769fe7dde36f2157eb622a9ac", null ],
    [ "SPA_DICT_INIT_ARRAY", "group__spa__dict.html#ga892ec66ef5891b9d84e403ab815356bf", null ],
    [ "spa_dict_for_each", "group__spa__dict.html#gadacdfca3f982645e9671b030fb8e6568", null ],
    [ "spa_dict_item_compare", "group__spa__dict.html#gaa888623b54abbfc067b865a0ed031e5b", null ],
    [ "spa_dict_qsort", "group__spa__dict.html#ga002ee6b6ffc2dc43e96292afc87fb258", null ],
    [ "spa_dict_lookup_item", "group__spa__dict.html#ga24c526e99862abd40bee3b0808170645", null ],
    [ "spa_dict_lookup", "group__spa__dict.html#ga7f19c291bd4ccea2e830d88f7202dcf9", null ]
];