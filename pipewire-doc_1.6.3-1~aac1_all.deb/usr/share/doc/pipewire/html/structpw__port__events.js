var structpw__port__events =
[
    [ "version", "structpw__port__events.html#ab9b6466b9ef1ed29b53c585e6d7d5885", null ],
    [ "info", "structpw__port__events.html#a8f4e9ac2f2e40c313fa06e2f2d6fdced", null ],
    [ "param", "structpw__port__events.html#afee93a171006705e6e7ee53c4ba08a18", null ]
];