var structspa__hook =
[
    [ "link", "structspa__hook.html#aa750440084804e95fb24f95de3eb5d54", null ],
    [ "cb", "structspa__hook.html#a87415e24dddc82ef6048c3572a88cfd7", null ],
    [ "removed", "structspa__hook.html#a439678f47d124fd66beec84984c9de75", null ],
    [ "priv", "structspa__hook.html#ac503424bd37fd0f8b8e6ba5bb248d8a5", null ]
];