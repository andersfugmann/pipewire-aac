var structspa__device__object__info =
[
    [ "version", "structspa__device__object__info.html#a0758afd0518197c48d5d76cdc14526e3", null ],
    [ "type", "structspa__device__object__info.html#a4ed767ff310d6f2e1d4cd78f3a7c3f6f", null ],
    [ "factory_name", "structspa__device__object__info.html#a9b6645d2c0b8b3679833ad122cb299a1", null ],
    [ "change_mask", "structspa__device__object__info.html#a702111c5873243c93551073552863666", null ],
    [ "flags", "structspa__device__object__info.html#aec61b33f732c10087d40e9c0d97bdcb0", null ]
];