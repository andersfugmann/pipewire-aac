var structspa__audio__info__ac3 =
[
    [ "rate", "structspa__audio__info__ac3.html#a23d93a823433552f99e0c3e6d38496dd", null ],
    [ "channels", "structspa__audio__info__ac3.html#ad1fff8ee83ae8ae21979fb4c19936dee", null ]
];