var structpw__device__events =
[
    [ "version", "structpw__device__events.html#adbe2ffa9bd2bcf75f82ce7cfd99ebb29", null ],
    [ "info", "structpw__device__events.html#a223b1ad31ee9892baa431d000ec94141", null ],
    [ "param", "structpw__device__events.html#afd599abc733552407c0284871b1e0635", null ]
];