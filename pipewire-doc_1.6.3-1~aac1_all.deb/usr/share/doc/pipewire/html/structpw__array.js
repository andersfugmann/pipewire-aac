var structpw__array =
[
    [ "data", "structpw__array.html#ab0929cdf2f7acb291f2f17be299b8ea5", null ],
    [ "size", "structpw__array.html#a3d468425a1a0084f98301e2fd9becc6b", null ],
    [ "alloc", "structpw__array.html#a429b934f5c1580d91af238ac04e44842", null ],
    [ "extend", "structpw__array.html#a92ae2df32c3d6935897f41b6e7f5ad3c", null ]
];