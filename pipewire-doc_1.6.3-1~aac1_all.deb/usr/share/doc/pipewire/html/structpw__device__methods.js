var structpw__device__methods =
[
    [ "version", "structpw__device__methods.html#a9141d0e02e0c16303f59f79d4c1569d8", null ],
    [ "add_listener", "structpw__device__methods.html#abe74e1fc28413c676391beffec0ba250", null ],
    [ "subscribe_params", "structpw__device__methods.html#a50406b74540f4535df9b01ae15cfcfe0", null ],
    [ "enum_params", "structpw__device__methods.html#a8210738d5878d65481bc918ff935aa80", null ],
    [ "set_param", "structpw__device__methods.html#a8251c871164651bcff0d7375ebd75440", null ]
];