var structspa__graph__state =
[
    [ "status", "structspa__graph__state.html#ade14580f5dc43afc10b857d4233d3f99", null ],
    [ "required", "structspa__graph__state.html#a98a2cfe5aa419430cefaf19e3836ce40", null ],
    [ "pending", "structspa__graph__state.html#a8f3cf9778a95b2717a5a6ac0d5b55bb9", null ]
];