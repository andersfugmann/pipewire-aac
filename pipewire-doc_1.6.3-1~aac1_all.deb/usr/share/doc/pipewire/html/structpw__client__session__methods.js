var structpw__client__session__methods =
[
    [ "version", "structpw__client__session__methods.html#a4537bb47cfe11b27649ffe082fdd49fa", null ],
    [ "add_listener", "structpw__client__session__methods.html#a54ba399f450c8ee5b85cfba7ad4b352a", null ],
    [ "update", "group__pw__session__manager.html#gab104098c9fd6fad4bbe290509aefbe20", null ],
    [ "link_update", "group__pw__session__manager.html#gad11c6d8d430ddbe887f200ea7b4c33d1", null ]
];