var structpw__node__methods =
[
    [ "version", "structpw__node__methods.html#a44bb3efe45f8a5c763cc62daaa099569", null ],
    [ "add_listener", "structpw__node__methods.html#a01dbc165d13370efdb6a54a5c3f40f41", null ],
    [ "subscribe_params", "structpw__node__methods.html#a66986c115ef6b4046c22774ea438a3ad", null ],
    [ "enum_params", "structpw__node__methods.html#a1f28beb1b607ebd270f2e06b4f9a5266", null ],
    [ "set_param", "structpw__node__methods.html#a0fee61facfa842f9be5b55815d78f49a", null ],
    [ "send_command", "structpw__node__methods.html#a9f04049f6b62d408dacdefe1aafcc802", null ]
];