var structspa__audio__aec__methods =
[
    [ "version", "structspa__audio__aec__methods.html#af6f30eee3a6af553b3e6ef83f850a691", null ],
    [ "add_listener", "structspa__audio__aec__methods.html#a0e357608392e4e4cf8224a523882a80c", null ],
    [ "init", "structspa__audio__aec__methods.html#af7b0dbc68aecaab0c278bc95a9d37503", null ],
    [ "run", "structspa__audio__aec__methods.html#aadf3db584c3062de5a2af134e6d7014d", null ],
    [ "set_props", "structspa__audio__aec__methods.html#a0ea3331fe5e9ceed6a0969c4f2aaa4c3", null ],
    [ "activate", "structspa__audio__aec__methods.html#a5b18f9a4430576c06bf7067a61a97854", null ],
    [ "deactivate", "structspa__audio__aec__methods.html#a1d1c3a7ec1bd783ddb3cea31bc421cb1", null ],
    [ "enum_props", "structspa__audio__aec__methods.html#aa75447be29ace8e48fefb525ed44bcd8", null ],
    [ "get_params", "structspa__audio__aec__methods.html#a028adaf84c4fb5c19e416c53874ad57f", null ],
    [ "set_params", "structspa__audio__aec__methods.html#af75957ae10a92bb2253df67aa6eca97f", null ],
    [ "init2", "structspa__audio__aec__methods.html#a73977fea4b6c069260af4f16b08ceee0", null ]
];