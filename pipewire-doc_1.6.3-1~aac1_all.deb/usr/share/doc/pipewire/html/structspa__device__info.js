var structspa__device__info =
[
    [ "version", "structspa__device__info.html#a394aa2b1d356ce8e510330aedd38ff63", null ],
    [ "change_mask", "structspa__device__info.html#afbe429acf565ab384929f0ccf76fc49c", null ],
    [ "flags", "structspa__device__info.html#a2692374f54a8d9f743474c4a3fcb8ebc", null ],
    [ "params", "structspa__device__info.html#a2ef8690873a8db10e6c29357ea4a216c", null ],
    [ "n_params", "structspa__device__info.html#a5184282839436a8b87d505b4b17cffbd", null ]
];