var structspa__audio__info__vorbis =
[
    [ "rate", "structspa__audio__info__vorbis.html#a7614ad24e4491223d0d44c1931c3089b", null ],
    [ "channels", "structspa__audio__info__vorbis.html#afec5882d3af8e9d177b4b0771c176046", null ]
];