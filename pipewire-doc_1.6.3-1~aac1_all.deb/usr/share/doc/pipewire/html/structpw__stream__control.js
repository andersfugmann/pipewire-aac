var structpw__stream__control =
[
    [ "flags", "structpw__stream__control.html#a4167f3df47a2d2deff793d3f1f6d31d2", null ],
    [ "def", "structpw__stream__control.html#a4541b454ba4caaf23f4e772f431294c1", null ],
    [ "min", "structpw__stream__control.html#a61f6208ade53511ac42e01185f270f62", null ],
    [ "max", "structpw__stream__control.html#a40b47654929367a6a4f1b83b0b68bfb1", null ],
    [ "values", "structpw__stream__control.html#addabfd3b77bb0cb58bb65b779ab1b3d5", null ],
    [ "n_values", "structpw__stream__control.html#a925311b76a91a9034391da7343865091", null ],
    [ "max_values", "structpw__stream__control.html#a4ffcfbdb7762b0650a28f10eb8c10046", null ]
];