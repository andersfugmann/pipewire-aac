var structspa__audio__info__alac =
[
    [ "rate", "structspa__audio__info__alac.html#a93d94a062b877bdb495bd1b07364f05d", null ],
    [ "channels", "structspa__audio__info__alac.html#afd38ff2d76cd8078e80f8955dc23da19", null ]
];