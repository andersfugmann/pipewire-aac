var structspa__node__events =
[
    [ "version", "structspa__node__events.html#a37b6ed18688f456b4c4e9b157879414f", null ],
    [ "info", "structspa__node__events.html#a6950a2df9f758cbbe7651f9db3962bed", null ],
    [ "port_info", "structspa__node__events.html#a7915d7cc4ad14d41c0a0865798470429", null ],
    [ "result", "structspa__node__events.html#a64cd08176057e03e97babf5b36ecd7bf", null ],
    [ "event", "structspa__node__events.html#a4b3918e0034bb87549fe911028ca8741", null ]
];