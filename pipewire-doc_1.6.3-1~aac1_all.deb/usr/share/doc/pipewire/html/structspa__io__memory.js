var structspa__io__memory =
[
    [ "status", "structspa__io__memory.html#a25a75f4edf0631a335b0dfd55c214f3e", null ],
    [ "size", "structspa__io__memory.html#af7c688ea663d461d5c880d0629c7fa49", null ],
    [ "data", "structspa__io__memory.html#a8ad18bb75b7dda83388267077331068c", null ]
];