var structpw__impl__module__events =
[
    [ "version", "structpw__impl__module__events.html#aea5e86ba050b1b9e92bb3c7ba3425f71", null ],
    [ "destroy", "structpw__impl__module__events.html#a4cfcceec669bbbdf6697e36cd5dbae1d", null ],
    [ "free", "structpw__impl__module__events.html#a2cb2abff60d0fa2370afcb8b5c2ae830", null ],
    [ "initialized", "structpw__impl__module__events.html#a1f0de76c49fdf742fe40c6fc0799d08c", null ],
    [ "registered", "structpw__impl__module__events.html#a75c9588d21472e8d610b813bdd9a419e", null ]
];