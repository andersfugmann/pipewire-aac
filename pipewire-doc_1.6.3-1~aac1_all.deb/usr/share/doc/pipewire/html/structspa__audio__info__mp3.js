var structspa__audio__info__mp3 =
[
    [ "rate", "structspa__audio__info__mp3.html#a2066d86c3d391a097c57441f8c391234", null ],
    [ "channels", "structspa__audio__info__mp3.html#a9eab81f1ef553124803e7563d7ffce93", null ],
    [ "channel_mode", "structspa__audio__info__mp3.html#ac67812d9e0eb6d1601c3cb55146367d2", null ]
];