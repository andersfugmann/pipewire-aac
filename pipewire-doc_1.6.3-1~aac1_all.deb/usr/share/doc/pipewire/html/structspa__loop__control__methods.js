var structspa__loop__control__methods =
[
    [ "version", "structspa__loop__control__methods.html#aa66e2f92b352ef1ae10b591f11086340", null ],
    [ "get_fd", "structspa__loop__control__methods.html#a2673d98892466d81baea852c94c91a39", null ],
    [ "add_hook", "structspa__loop__control__methods.html#a4af155a89512ec591bac117a3907e8c4", null ],
    [ "enter", "structspa__loop__control__methods.html#a4a64700ab318b03abb1a5ec5a5309f8a", null ],
    [ "leave", "structspa__loop__control__methods.html#a84177384a1a726c4b35a3e1d9bc8f30f", null ],
    [ "iterate", "structspa__loop__control__methods.html#a2d30cbd197ae33a77b5ccce2216ca61a", null ],
    [ "check", "structspa__loop__control__methods.html#a6fd7cce6e454d8bbaff7f13d2035f6c9", null ],
    [ "lock", "structspa__loop__control__methods.html#a5d5ec8b6fc94a3c6334dd5012a8a526d", null ],
    [ "unlock", "structspa__loop__control__methods.html#a77322a2f445222c1f22df952caaa12b3", null ],
    [ "get_time", "structspa__loop__control__methods.html#a5297296ee961883415a822498d9f6234", null ],
    [ "wait", "structspa__loop__control__methods.html#a26253d8a2a6d747411d3b86803d8b29f", null ],
    [ "signal", "structspa__loop__control__methods.html#a4499bd9395f128c018b3cd483d9e7225", null ],
    [ "accept", "structspa__loop__control__methods.html#a036da696778edfa6d08602396e3b74fe", null ]
];