var structpw__properties =
[
    [ "dict", "structpw__properties.html#a70aa5816bde60f5511f2308971794881", null ],
    [ "flags", "structpw__properties.html#a8003e978689f764bb7bd2a3ab2d46a87", null ]
];