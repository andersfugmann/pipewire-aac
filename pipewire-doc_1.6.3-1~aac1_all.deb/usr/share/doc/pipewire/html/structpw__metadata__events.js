var structpw__metadata__events =
[
    [ "version", "structpw__metadata__events.html#a4d1905b2e0e9965cc9c36461133a6047", null ],
    [ "property", "structpw__metadata__events.html#ac2dd9bc9016f5b10c7af9f292532ef5d", null ]
];