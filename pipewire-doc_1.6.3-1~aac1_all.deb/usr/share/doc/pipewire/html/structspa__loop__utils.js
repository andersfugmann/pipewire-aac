var structspa__loop__utils =
[
    [ "iface", "structspa__loop__utils.html#afd3c579e127e4a5d22c1d407e01b2803", null ]
];