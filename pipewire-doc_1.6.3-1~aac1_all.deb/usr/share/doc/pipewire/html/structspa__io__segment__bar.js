var structspa__io__segment__bar =
[
    [ "flags", "structspa__io__segment__bar.html#afaad39c0e35dbd2e4fc075a93914341f", null ],
    [ "offset", "structspa__io__segment__bar.html#ad6d079e00b9b7428ab66c7f7fc5e0a5e", null ],
    [ "signature_num", "structspa__io__segment__bar.html#af6cb2a9476c6fda23897ed5d45b3f2d4", null ],
    [ "signature_denom", "structspa__io__segment__bar.html#a65f1a61b7161bc2ddfb12e2bec1c51d3", null ],
    [ "bpm", "structspa__io__segment__bar.html#a5398027b6c636c287b2df47239b6b9e3", null ],
    [ "beat", "structspa__io__segment__bar.html#a212f71e2e8b5587d48f4a71151ebdda5", null ],
    [ "bar_start_tick", "structspa__io__segment__bar.html#ad1c1cb6cda52db4b3ffbb4dbee804bb0", null ],
    [ "ticks_per_beat", "structspa__io__segment__bar.html#a7c4acf7c0d30df734669355189d0879f", null ],
    [ "padding", "structspa__io__segment__bar.html#a34df6bc077aed465af23d8b5b8d74a85", null ]
];