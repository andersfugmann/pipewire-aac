var structspa__io__buffers =
[
    [ "status", "structspa__io__buffers.html#a1364df7bc201533525e5a4fa54f444fe", null ],
    [ "buffer_id", "structspa__io__buffers.html#aadfe10a114c998d88137450877d8326b", null ]
];