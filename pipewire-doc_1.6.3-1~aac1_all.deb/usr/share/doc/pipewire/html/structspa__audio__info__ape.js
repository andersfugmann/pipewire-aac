var structspa__audio__info__ape =
[
    [ "rate", "structspa__audio__info__ape.html#a72509a439dfbe203c6c3653bed2153ed", null ],
    [ "channels", "structspa__audio__info__ape.html#a82e8f9bb5e9bd7bd014a92709a06b9f9", null ]
];