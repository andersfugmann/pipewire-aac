var structspa__param__info =
[
    [ "id", "structspa__param__info.html#ad470ae46aca7e354753efbb1019f34fe", null ],
    [ "flags", "structspa__param__info.html#a1fcfd641de4a963a797da64eebfe7771", null ],
    [ "user", "structspa__param__info.html#aafe96bbf409564bcce653d58fffb40cf", null ],
    [ "seq", "structspa__param__info.html#afcbe452106c79a62cc457da5a19eafcb", null ],
    [ "padding", "structspa__param__info.html#a76f02e8ac2d41d1fc75fb734ad94af1c", null ]
];