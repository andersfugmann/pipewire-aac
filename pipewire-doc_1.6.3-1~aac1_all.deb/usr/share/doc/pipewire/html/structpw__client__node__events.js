var structpw__client__node__events =
[
    [ "version", "structpw__client__node__events.html#a3d12bf0a63aba14bc897e4ceb51e4fe4", null ],
    [ "transport", "structpw__client__node__events.html#ad7084094ae633b01409033ba363ef78b", null ],
    [ "set_param", "structpw__client__node__events.html#ac5884f60926b382728097c8846dcba85", null ],
    [ "set_io", "structpw__client__node__events.html#abb5194c288d8bb436b1c8264e21037c7", null ],
    [ "event", "structpw__client__node__events.html#a775ca4ec6d6115039b2e8574bef184f2", null ],
    [ "command", "structpw__client__node__events.html#abac4b80ae987a95a81ece32baa8fef14", null ],
    [ "add_port", "structpw__client__node__events.html#ac0b5a3c66103be01b784464d4dd81fa0", null ],
    [ "remove_port", "structpw__client__node__events.html#a3802ec24f1305664c8d1b846abc244c8", null ],
    [ "port_set_param", "structpw__client__node__events.html#a63c10e914836b4c4ffc02be889c717f8", null ],
    [ "port_use_buffers", "structpw__client__node__events.html#a0fdb140f41117e7690aca449844d72c2", null ],
    [ "port_set_io", "structpw__client__node__events.html#a0942c754a0fd77db7c9051172b2ac991", null ],
    [ "set_activation", "structpw__client__node__events.html#aa25eeb692995699b672f71251ec0b4b6", null ],
    [ "port_set_mix_info", "structpw__client__node__events.html#ab1aba9806056fc945c2328f1cc128f6e", null ]
];