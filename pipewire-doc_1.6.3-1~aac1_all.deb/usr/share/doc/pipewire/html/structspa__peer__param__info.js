var structspa__peer__param__info =
[
    [ "peer_id", "structspa__peer__param__info.html#a6ebbf4ac92449d4773bc03a99e84add8", null ],
    [ "param", "structspa__peer__param__info.html#a7ad5683335bc1ca5f068aea65c979087", null ]
];