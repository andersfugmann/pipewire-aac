var structpw__protocol__native__demarshal =
[
    [ "func", "structpw__protocol__native__demarshal.html#ad4dcb55ad836d8f5cf303742aaae5ff2", null ],
    [ "permissions", "structpw__protocol__native__demarshal.html#acc4296853e8e0def46f6269326b76198", null ],
    [ "flags", "structpw__protocol__native__demarshal.html#a3f981db467091f35ddb7e5ecb2bf0705", null ]
];