var structpw__impl__device__events =
[
    [ "version", "structpw__impl__device__events.html#adbb4dbff59d4c076dd28626b2b2de840", null ],
    [ "destroy", "structpw__impl__device__events.html#a537507ed435ab1f01c34e063d9f48982", null ],
    [ "free", "structpw__impl__device__events.html#a04b3922036844e0e7eb8f51671ac19e5", null ],
    [ "initialized", "structpw__impl__device__events.html#ad9bbb080f7502ba24a6c170461078884", null ],
    [ "info_changed", "structpw__impl__device__events.html#aee86b69561fd8e8f0525223ed8685e60", null ]
];