var structspa__meta =
[
    [ "type", "structspa__meta.html#aceb2df955f0bee0bffaa59e62e6af67d", null ],
    [ "size", "structspa__meta.html#aad98af5fa0f07981e486b6268fe9c71c", null ],
    [ "data", "structspa__meta.html#ae2198fc30f4df8e624cd06db8cfe9583", null ]
];