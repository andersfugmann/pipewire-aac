var structspa__audio__info__flac =
[
    [ "rate", "structspa__audio__info__flac.html#a9be31890542f5995b7bbe493cd29f688", null ],
    [ "channels", "structspa__audio__info__flac.html#a3351a0cbf04538db70fac13cd630e79e", null ]
];