var structpw__protocol__client =
[
    [ "link", "structpw__protocol__client.html#addd42578b59ddffc32a42a52754654be", null ],
    [ "protocol", "structpw__protocol__client.html#a2f6233dcd7a026275a93680ae68ee263", null ],
    [ "core", "structpw__protocol__client.html#a03ad2913f7876e0db722b6d1e318e35f", null ],
    [ "connect", "structpw__protocol__client.html#a020b1da93f4f58c485ff64da4a5ac655", null ],
    [ "connect_fd", "structpw__protocol__client.html#a0f94b0fb5b1f83cbb56529b5c43c4a8f", null ],
    [ "steal_fd", "structpw__protocol__client.html#ae94059a4fa05da14961edb56be183f2a", null ],
    [ "disconnect", "structpw__protocol__client.html#a4b60903a56e79e980b11ea2d14fac80c", null ],
    [ "destroy", "structpw__protocol__client.html#a9ce571a5bc950b3309d0dbd2a55e501f", null ],
    [ "set_paused", "structpw__protocol__client.html#a4f79f140a57922a8c4b7d52f9f433918", null ]
];