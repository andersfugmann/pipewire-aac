var structspa__meta__region =
[
    [ "region", "structspa__meta__region.html#af1fe3dd2f5fc8f7e8899b93049dfffd2", null ]
];