var structpw__timer =
[
    [ "link", "structpw__timer.html#a832ec552d3fe6f869b3dca787063cdbb", null ],
    [ "queue", "structpw__timer.html#acf4006a9ae001df2816065aa1020330e", null ],
    [ "timeout", "structpw__timer.html#a83f4874becb6e73bf2a73a7ffec4e4fc", null ],
    [ "callback", "structpw__timer.html#a76ef18abe65958167e39bf879abb3430", null ],
    [ "data", "structpw__timer.html#a200b8df57bbb5c594db0d44fa642de54", null ],
    [ "padding", "structpw__timer.html#aba742fb172356034566569bce63191fe", null ]
];