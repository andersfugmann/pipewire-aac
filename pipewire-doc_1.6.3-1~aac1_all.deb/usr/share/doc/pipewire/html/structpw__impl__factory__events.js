var structpw__impl__factory__events =
[
    [ "version", "structpw__impl__factory__events.html#a61bf0bc918867a1315f7c09e870cf297", null ],
    [ "destroy", "structpw__impl__factory__events.html#abb0d82e4263cbe36b38aa10eef130ad0", null ],
    [ "free", "structpw__impl__factory__events.html#ae608dbd84c609b5b8a6d7c232e5a569f", null ],
    [ "initialized", "structpw__impl__factory__events.html#a6bb4670f4a96e31d0f1f30d3fc763bc6", null ]
];