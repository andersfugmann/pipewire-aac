var structspa__cpu =
[
    [ "iface", "structspa__cpu.html#a4822c09d9eb0c57ca8d7b6e8ed4bfcda", null ]
];