var structpw__endpoint__events =
[
    [ "version", "structpw__endpoint__events.html#ac01eef7eb942d89fb0437ee91df13522", null ],
    [ "info", "structpw__endpoint__events.html#a80267d5ed443bb1b924b8bbe89375c5f", null ],
    [ "param", "structpw__endpoint__events.html#a89bfc5609cf692b853de5d46da2dbc01", null ]
];