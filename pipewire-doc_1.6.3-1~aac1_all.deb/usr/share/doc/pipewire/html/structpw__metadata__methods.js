var structpw__metadata__methods =
[
    [ "version", "structpw__metadata__methods.html#af38a2fe70b07a10b103931f9e03561c6", null ],
    [ "add_listener", "structpw__metadata__methods.html#a3c5f9a58ed230b347bb819e38662bd46", null ],
    [ "set_property", "structpw__metadata__methods.html#af13aa299868c89d4e91411443fdd46f2", null ],
    [ "clear", "structpw__metadata__methods.html#a140aea55bb9350536ef59595585b7a6b", null ]
];