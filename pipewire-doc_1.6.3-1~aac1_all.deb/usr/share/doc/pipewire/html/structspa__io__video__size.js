var structspa__io__video__size =
[
    [ "flags", "structspa__io__video__size.html#ab8f1361af870dd5de789b63b687a22ce", null ],
    [ "stride", "structspa__io__video__size.html#a817931821ee7f154884141faa47647c0", null ],
    [ "size", "structspa__io__video__size.html#ac21892f7b4b6c90063b80306659a657b", null ],
    [ "framerate", "structspa__io__video__size.html#a14c82d8b6ae358c42c68f7dba2666b18", null ],
    [ "padding", "structspa__io__video__size.html#a259e1fe5e8894a35cf6849b94059ac7f", null ]
];