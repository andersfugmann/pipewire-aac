var structspa__loop__methods =
[
    [ "version", "structspa__loop__methods.html#ae7dc5184539a2425309dee69d2867dcf", null ],
    [ "add_source", "structspa__loop__methods.html#a3cc011aae850f2eda426b98655c4a43c", null ],
    [ "update_source", "structspa__loop__methods.html#aa1c58c24c44c6161f7c5d81910cc5acc", null ],
    [ "remove_source", "structspa__loop__methods.html#a72835084d3a698702f9c875ae5aada7a", null ],
    [ "invoke", "structspa__loop__methods.html#a7852de4b031351b586ed1f5375fdc863", null ],
    [ "locked", "structspa__loop__methods.html#a3dfbdafc8016d88d57a7d99b6683120f", null ]
];