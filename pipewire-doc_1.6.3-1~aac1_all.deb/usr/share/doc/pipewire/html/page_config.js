var page_config =
[
    [ "Index", "page_config_xref.html", null ],
    [ "pipewire.conf", "page_man_pipewire_conf_5.html", [
      [ "DROP-IN CONFIGURATION FILES", "page_man_pipewire_conf_5.html#pipewire_conf__drop-in_configuration_files", null ],
      [ "CONFIGURATION FILE FORMAT", "page_man_pipewire_conf_5.html#pipewire_conf__configuration_file_format", null ],
      [ "CONFIGURATION FILE SECTIONS", "page_man_pipewire_conf_5.html#pipewire_conf__configuration_file_sections", null ],
      [ "CONTEXT PROPERTIES", "page_man_pipewire_conf_5.html#pipewire_conf__context_properties", null ],
      [ "SPA LIBRARIES", "page_man_pipewire_conf_5.html#pipewire_conf__spa_libraries", null ],
      [ "MODULES", "page_man_pipewire_conf_5.html#pipewire_conf__modules", null ],
      [ "CONTEXT OBJECTS", "page_man_pipewire_conf_5.html#pipewire_conf__context_objects", null ],
      [ "COMMAND EXECUTION", "page_man_pipewire_conf_5.html#pipewire_conf__command_execution", null ],
      [ "MATCH RULES", "page_man_pipewire_conf_5.html#pipewire_conf__match_rules", null ],
      [ "CONTEXT PROPERTIES RULES", "page_man_pipewire_conf_5.html#pipewire_conf__context_properties_rules", null ],
      [ "NODE RULES", "page_man_pipewire_conf_5.html#pipewire_conf__node_rules", null ],
      [ "DEVICE RULES", "page_man_pipewire_conf_5.html#pipewire_conf__device_rules", null ]
    ] ],
    [ "client.conf", "page_man_pipewire-client_conf_5.html", [
      [ "CONFIGURATION FILE SECTIONS", "page_man_pipewire-client_conf_5.html#client_conf__configuration_file_sections", null ],
      [ "STREAM PROPERTIES", "page_man_pipewire-client_conf_5.html#client_conf__stream_properties", null ],
      [ "STREAM RULES", "page_man_pipewire-client_conf_5.html#client_conf__stream_rules", null ],
      [ "ALSA CLIENT PROPERTIES", "page_man_pipewire-client_conf_5.html#client_conf__alsa_client_properties", null ],
      [ "ALSA CLIENT RULES", "page_man_pipewire-client_conf_5.html#client_conf__alsa_client_rules", null ],
      [ "ENVIRONMENT VARIABLES", "page_man_pipewire-client_conf_5.html#client-env__environment_variables", null ]
    ] ],
    [ "pipewire-pulse.conf", "page_man_pipewire-pulse_conf_5.html", [
      [ "CONFIGURATION FILE SECTIONS", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__configuration_file_sections", null ],
      [ "STREAM PROPERTIES", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__stream_properties", null ],
      [ "STREAM RULES", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__stream_rules", null ],
      [ "PULSEAUDIO PROPERTIES", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__pulseaudio_properties", null ],
      [ "PULSEAUDIO RULES", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__pulseaudio_rules", null ],
      [ "PULSEAUDIO COMMANDS", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__pulseaudio_commands", null ],
      [ "PULSEAUDIO MODULES", "page_man_pipewire-pulse_conf_5.html#pipewire-pulse_conf__pulseaudio_modules", null ]
    ] ],
    [ "jack.conf", "page_man_pipewire-jack_conf_5.html", [
      [ "CONFIGURATION FILE SECTIONS", "page_man_pipewire-jack_conf_5.html#jack_conf__configuration_file_sections", null ],
      [ "JACK PROPERTIES", "page_man_pipewire-jack_conf_5.html#jack_conf__jack_properties", null ],
      [ "MATCH RULES", "page_man_pipewire-jack_conf_5.html#jack_conf__match_rules", null ],
      [ "ENVIRONMENT VARIABLES", "page_man_pipewire-jack_conf_5.html#jack-env__environment_variables", null ]
    ] ],
    [ "filter-chain.conf", "page_man_pipewire-filter-chain_conf_5.html", null ],
    [ "pipewire-props", "page_man_pipewire-props_7.html", [
      [ "CUSTOMIZING PROPERTIES", "page_man_pipewire-props_7.html#props__customizing_properties", null ],
      [ "COMMON DEVICE PROPERTIES", "page_man_pipewire-props_7.html#props__common_device_properties", null ],
      [ "COMMON NODE PROPERTIES", "page_man_pipewire-props_7.html#props__common_node_properties", [
        [ "Identifying Properties", "page_man_pipewire-props_7.html#props__identifying_properties", null ],
        [ "Classifying Properties", "page_man_pipewire-props_7.html#props__classifying_properties", null ],
        [ "Scheduling Properties", "page_man_pipewire-props_7.html#props__scheduling_properties", null ],
        [ "Session Manager Properties", "page_man_pipewire-props_7.html#props__session_manager_properties", null ]
      ] ],
      [ "AUDIO ADAPTER PROPERTIES", "page_man_pipewire-props_7.html#props__audio_adapter_properties", null ],
      [ "ALSA PROPERTIES", "page_man_pipewire-props_7.html#props__alsa_properties", null ],
      [ "ALSA MIDI PROPERTIES", "page_man_pipewire-props_7.html#props__alsa_midi_properties", null ],
      [ "BLUETOOTH PROPERTIES", "page_man_pipewire-props_7.html#props__bluetooth_properties", null ],
      [ "PORT PROPERTIES", "page_man_pipewire-props_7.html#props__port_properties", null ],
      [ "LINK PROPERTIES", "page_man_pipewire-props_7.html#props__link_properties", null ],
      [ "CLIENT PROPERTIES", "page_man_pipewire-props_7.html#props__client_properties", null ],
      [ "RUNTIME SETTINGS", "page_man_pipewire-props_7.html#props__runtime_settings", null ],
      [ "ALSA CARD PROFILES", "page_man_pipewire-props_7.html#props__alsa_card_profiles", null ],
      [ "OTHER OBJECT TYPES", "page_man_pipewire-props_7.html#props__other_object_types", null ],
      [ "INDEX", "page_man_pipewire-props_7.html#pipewire-props__index", null ]
    ] ],
    [ "pipewire-pulse-modules", "page_man_pipewire-pulse-modules_7.html", null ],
    [ "libpipewire-modules", "page_man_libpipewire-modules_7.html", null ]
];