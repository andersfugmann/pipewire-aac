var structpw__impl__metadata__events =
[
    [ "version", "structpw__impl__metadata__events.html#ac11ef017d8f59e0a28d1d882ac508b22", null ],
    [ "destroy", "structpw__impl__metadata__events.html#a1f7feaad034d62902dccdef0a2b2f85a", null ],
    [ "free", "structpw__impl__metadata__events.html#a75ce933b493a16ecad3e8f9834cc74e6", null ],
    [ "property", "structpw__impl__metadata__events.html#a2a0419974291d4e9360544e5618ffb0f", null ]
];