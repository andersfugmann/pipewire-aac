var structpw__map__range =
[
    [ "offset", "structpw__map__range.html#aaf1ff0e5b8623a1c64ee4ac9dbf2008a", null ],
    [ "size", "structpw__map__range.html#a96ecc91bdc991ce5c807a1b79aded4f4", null ]
];