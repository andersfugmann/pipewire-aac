var structspa__dbus__methods =
[
    [ "version", "structspa__dbus__methods.html#a6e090fa6083fa425460f631ea48c3434", null ],
    [ "get_connection", "structspa__dbus__methods.html#a1e518bcb13046ec6b46a927024b6cc28", null ]
];