var structspa__io__rate__match =
[
    [ "delay", "structspa__io__rate__match.html#a9d0be859f40cffcebe7b829d19fcacee", null ],
    [ "size", "structspa__io__rate__match.html#ad8a395240a4b89d6be0e67538cf6ad5c", null ],
    [ "rate", "structspa__io__rate__match.html#a8f9575e69576c942758927acba7daeef", null ],
    [ "flags", "structspa__io__rate__match.html#a7b89f4c442e2856faf64abeec186050e", null ],
    [ "delay_frac", "structspa__io__rate__match.html#a63710cb0783f022e8d3e6437b39db70b", null ],
    [ "padding", "structspa__io__rate__match.html#a79cd6d144071b3ab6415bc4201af9631", null ]
];