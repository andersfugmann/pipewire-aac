var structspa__dbus =
[
    [ "iface", "structspa__dbus.html#a240c318013b1a4441195fa94f213b65b", null ]
];