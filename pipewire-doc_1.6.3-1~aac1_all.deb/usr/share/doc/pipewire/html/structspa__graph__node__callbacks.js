var structspa__graph__node__callbacks =
[
    [ "version", "structspa__graph__node__callbacks.html#acbbdda8c4d517ce24ee12cad1c4e60ec", null ],
    [ "process", "structspa__graph__node__callbacks.html#a9c7b2744d4983173d88469654e626375", null ],
    [ "reuse_buffer", "structspa__graph__node__callbacks.html#abc2bcb2b88b65f3eabe0e13d5d73f4e8", null ]
];