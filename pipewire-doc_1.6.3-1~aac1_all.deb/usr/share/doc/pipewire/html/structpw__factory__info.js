var structpw__factory__info =
[
    [ "id", "structpw__factory__info.html#aa930c209d3ae55baeaebff7edc38a02b", null ],
    [ "type", "structpw__factory__info.html#a76b3448ac2229cdcbe42c28f824dcf0b", null ],
    [ "version", "structpw__factory__info.html#a0b9fcbe083fe5205459705da31d45f97", null ],
    [ "change_mask", "structpw__factory__info.html#adc3bf8dcfbfb3dbf0ed7f3638a659f46", null ]
];