var structspa__meta__cursor =
[
    [ "id", "structspa__meta__cursor.html#a5f190ab6e828890a8c5b530cb9cae78d", null ],
    [ "flags", "structspa__meta__cursor.html#a01ee3f6baba19d1a0851a44badd819a9", null ],
    [ "position", "structspa__meta__cursor.html#a78b7805e66e52164fc8a985578b4c990", null ],
    [ "hotspot", "structspa__meta__cursor.html#a46bdd5e6f3d880a74ae602e596176028", null ],
    [ "bitmap_offset", "structspa__meta__cursor.html#a9785c5b1408d2d4c4cc053bfb67ef6c0", null ]
];