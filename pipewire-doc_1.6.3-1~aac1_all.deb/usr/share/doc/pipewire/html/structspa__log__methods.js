var structspa__log__methods =
[
    [ "version", "structspa__log__methods.html#a3c9b289423cdd729b13d7b3311f1a637", null ],
    [ "log", "structspa__log__methods.html#ae81b7f30088018ec4e605c0b3d282dc2", null ],
    [ "logv", "structspa__log__methods.html#a1ccec84afda4c9ee2d42f5e1ba6d42c0", null ],
    [ "logt", "structspa__log__methods.html#a5672da2c27786ab1510decfae1dc8f1f", null ],
    [ "logtv", "structspa__log__methods.html#a557a702c3bb29ea46667ab9bcecef17b", null ],
    [ "topic_init", "structspa__log__methods.html#a727bd51b157a0e800169a6c29963a7dd", null ]
];