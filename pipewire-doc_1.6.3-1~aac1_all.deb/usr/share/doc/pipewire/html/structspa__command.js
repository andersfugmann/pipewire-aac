var structspa__command =
[
    [ "pod", "structspa__command.html#ad422c2065f2080f39a1ee42b77154c55", null ],
    [ "body", "structspa__command.html#abf1578cf1ed69aac1d0473684f804d4e", null ]
];