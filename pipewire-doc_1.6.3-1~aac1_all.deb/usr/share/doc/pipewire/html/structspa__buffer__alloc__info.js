var structspa__buffer__alloc__info =
[
    [ "flags", "structspa__buffer__alloc__info.html#afc286a004cefa1ef2d751483a8cc8c15", null ],
    [ "max_align", "structspa__buffer__alloc__info.html#a51af051b079634c3f854680f118716e7", null ],
    [ "n_metas", "structspa__buffer__alloc__info.html#a49810ff55f219eea5c1e4a3e2f24cd4c", null ],
    [ "n_datas", "structspa__buffer__alloc__info.html#aea2d60a678ae26619b5bfb35291b9a01", null ],
    [ "metas", "structspa__buffer__alloc__info.html#aef6e15022383cf49cbba4196111c190d", null ],
    [ "datas", "structspa__buffer__alloc__info.html#adea010a789fec41087739852b235185b", null ],
    [ "data_aligns", "structspa__buffer__alloc__info.html#ae0f8e64c4f71c63cfa87b1b7527a47c7", null ],
    [ "skel_size", "structspa__buffer__alloc__info.html#a963cf1755ba6612abcff0491680abc64", null ],
    [ "meta_size", "structspa__buffer__alloc__info.html#a63296028aeb53c2e98501c78f1d53617", null ],
    [ "chunk_size", "structspa__buffer__alloc__info.html#a8ea4df582a468b0f1621672af3e2426f", null ],
    [ "data_size", "structspa__buffer__alloc__info.html#a30233569ad362f458d9e1344d0b5a58c", null ],
    [ "mem_size", "structspa__buffer__alloc__info.html#a2598f62c920f42fd1ea6547968c0e2a6", null ]
];