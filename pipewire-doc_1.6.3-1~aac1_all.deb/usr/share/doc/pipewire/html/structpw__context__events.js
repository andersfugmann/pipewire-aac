var structpw__context__events =
[
    [ "version", "structpw__context__events.html#ad0a1b4e42b11a408175ab4f70b1bbc7c", null ],
    [ "destroy", "structpw__context__events.html#a34b60636aee5925696ca80cbbf63755e", null ],
    [ "free", "structpw__context__events.html#a9c874d491dfbdd13eb81c7b0b7561e87", null ],
    [ "check_access", "structpw__context__events.html#af3303a7f003c10bfbb454c0bbd13360c", null ],
    [ "global_added", "structpw__context__events.html#a15e3c312ad2339ed431059d76fea5a4d", null ],
    [ "global_removed", "structpw__context__events.html#a8b2b69a9c179e37c9185929535a047f0", null ],
    [ "driver_added", "structpw__context__events.html#af555de72a4d29b3d7c5074aa5e7ab6b0", null ],
    [ "driver_removed", "structpw__context__events.html#a7ff739c9ebd412efa10756ececc1a27c", null ]
];