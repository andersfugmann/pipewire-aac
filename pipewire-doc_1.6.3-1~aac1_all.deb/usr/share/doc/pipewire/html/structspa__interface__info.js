var structspa__interface__info =
[
    [ "type", "structspa__interface__info.html#acdbeeba8f234386bc1a937604c234e40", null ]
];