var structpw__session__methods =
[
    [ "version", "structpw__session__methods.html#a39a82c063c97d967e5ee82589c390c29", null ],
    [ "add_listener", "structpw__session__methods.html#afeb231bfac6c5539d258eb06b22e0acf", null ],
    [ "subscribe_params", "structpw__session__methods.html#a6720d4c6b23022393bc945c656ba5fe0", null ],
    [ "enum_params", "structpw__session__methods.html#a9311ff4c5e45bce0b1a56ee64e720b09", null ],
    [ "set_param", "structpw__session__methods.html#a66e604601841f9f2252db7c4a4466f6f", null ]
];