var structpw__proxy__events =
[
    [ "version", "structpw__proxy__events.html#a25e8553fd0ed2f729ffe61994f6973a2", null ],
    [ "destroy", "structpw__proxy__events.html#aaa8802aa5a62fdc422f8db0d606adac3", null ],
    [ "bound", "structpw__proxy__events.html#a8916a9be2fa3763221fdf64f79468d14", null ],
    [ "removed", "structpw__proxy__events.html#a8072b9d1ea7e1c91cce89de75d1c7e61", null ],
    [ "done", "structpw__proxy__events.html#a1d91d77027018205abcdfe5f25b0feb1", null ],
    [ "error", "structpw__proxy__events.html#af8e0510a58d92ddd0831293e1c42b867", null ],
    [ "bound_props", "structpw__proxy__events.html#a220d199c1f0a241f1e623686863e8158", null ]
];